# Looma

**A little room for a more organised day.**

A personalised boarding-school companion and operations demo, with original illustrated Loomas, a simulated assistant, homework and goals, room checks, reward chests, cosmetic customisation and individually animated pet personalities.

## Live demo

[Open Looma](https://notypenolife.github.io/Looma/)

The public demo uses entirely fictional student/staff information. All progress stays in the visitor’s browser. Nothing is sent to teachers, no real money is involved, and there is no live AI endpoint, account system or database. The role switcher is demonstration navigation, not authentication.

## Explore

- **Student:** today’s timetable, uniform and notices; simulated chat; editable homework; personal goals and instantly accepted demo reward missions.
- **Companions:** original SVG characters with individual first-person dialogue, articulated jumping/sleeping/eating, colours, fitted accessories and a character studio.
- **Rewards:** Dewdrops, streaks, cosmetic and Looma collections, eight earned-chest tiers, five-tap upgrades and prizes that jump out of the chest.
- **Staff:** room inspections and corrections, duties, notices, assignment receipts, staff-set reward missions and fictional detention administration. No automated discipline.
- **Settings:** reset the demo account and choose a starter again. Only Looma’s browser data is cleared.

## Develop

Built with Next.js App Router, React, TypeScript, Tailwind CSS, Radix Dialog and Lucide. Artwork is original SVG/CSS.

```sh
npm ci
npm run dev
```

Open http://localhost:3000/Looma/. Run `npm test`, `npm run typecheck` and `npm run build` for checks. `npm run build` exports the static demo to `out/`. The configuration uses `/Looma` as its base path for GitHub Pages; change that if you rename the repository or move to a root/custom domain.

A static host serves this demo without keeping a laptop or Node process running. Persistent link availability depends on keeping the repository and GitHub Pages enabled. Data is still browser-local and does not sync between devices.

## Publish

The GitHub Pages workflow builds and publishes on pushes to `main` and can also be run manually. In repository **Settings → Pages**, select **GitHub Actions** as the publishing source.

## Future production work

Add verified school membership and authentication, database/RLS policies, audited staff permissions and server transactions before handling real school records. The local demo acceptance adapter must be replaced by authorised evidence review. Balance, ownership, random rolls and reward grants must be validated server-side. Private companion conversations and approved memories stay separate from staff administration.

Live OpenAI integration requires authenticated server access, validation, rate limits, spending limits, sourced school information and age-appropriate safeguards. Do not put API keys in browser code. The public static build deliberately has no API route.

No license is granted for reuse of the original Looma characters or branding by publication alone. All rights reserved unless the owner adds a license.
