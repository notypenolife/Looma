import type { NextConfig } from "next";
const config: NextConfig = {
 output: "export",
 basePath: "/Looma",
 trailingSlash: true,
 images: {unoptimized: true},
 webpack(config) { config.cache = false; return config; },
};
export default config;
