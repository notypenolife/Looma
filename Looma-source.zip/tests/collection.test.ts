import test from "node:test";
import assert from "node:assert/strict";
import {
  initialCollection,
  purchaseCrate,
  rollCrate,
  rarityOdds,
  petReaction,
  validCollection,
} from "../src/lib/collection";

test("rarity odds total 100 and boundary rolls match the published chances", () => {
  assert.equal(
    rarityOdds.reduce((n, r) => n + r.chance, 0),
    100,
  );
  for (const kind of ["looma", "cosmetic"] as const) {
    for (const [roll, rarity] of [
      [0, "common"],
      [0.599999, "common"],
      [0.6, "rare"],
      [0.849999, "rare"],
      [0.85, "epic"],
      [0.969999, "epic"],
      [0.97, "legendary"],
      [0.999999, "legendary"],
    ] as const) {
      assert.equal(rollCrate(kind, roll, 0.5).rarity, rarity);
    }
  }
});
test("items are selected equally inside each rarity pool", () => {
  assert.equal(rollCrate("looma", 0.1, 0).item, "sprout");
  assert.equal(rollCrate("looma", 0.1, 0.34).item, "pebble");
  assert.equal(rollCrate("looma", 0.1, 0.99).item, "water");
  assert.equal(rollCrate("looma", 0.6, 0).item, "fire");
  assert.equal(rollCrate("looma", 0.6, 0.99).item, "electricity");
});
test("purchase deducts once, adds ownership and records the reveal", () => {
  const next = purchaseCrate(initialCollection, "looma", 0.97, 0, "find-1");
  assert.equal(next.balance, 350);
  assert.ok(next.forms.includes("fiend"));
  assert.equal(next.history[0].duplicate, false);
  assert.equal(next.history[0].id, "find-1");
  assert.equal(initialCollection.balance, 500);
});
test("duplicate refunds match the published amounts and ownership stays unique", () => {
  const looma = purchaseCrate(initialCollection, "looma", 0, 0, "repeat");
  assert.equal(looma.balance, 400);
  assert.equal(looma.history[0].refund, 50);
  assert.equal(looma.forms.filter((f) => f === "sprout").length, 1);
  const cosmetic = purchaseCrate(initialCollection, "cosmetic", 0, 0, "repeat");
  assert.equal(cosmetic.balance, 430);
  assert.equal(cosmetic.history[0].refund, 30);
});
test("insufficient funds make no purchase and bad rolls are rejected", () => {
  const state = { ...initialCollection, balance: 99 };
  assert.equal(purchaseCrate(state, "cosmetic", 0, 0, "none"), state);
  assert.throws(() => rollCrate("looma", 1, 0));
  assert.throws(() => rollCrate("looma", NaN, 0));
});
test("collection validation rejects damaged state", () => {
  assert.ok(validCollection(initialCollection));
  assert.equal(validCollection({ ...initialCollection, balance: -1 }), false);
  assert.equal(
    validCollection({ ...initialCollection, forms: ["unknown"] }),
    false,
  );
});
test("night owl and daytime personalities react differently without negative needs", () => {
  assert.equal(petReaction("shadow", "hello", 23).expression, "curious");
  assert.equal(petReaction("sprout", "hello", 23).expression, "sleepy");
  assert.notEqual(
    petReaction("pebble", "play", 12).line,
    petReaction("electricity", "play", 12).line,
  );
  assert.equal(petReaction("fire", "task", 12).expression, "celebrating");
});
