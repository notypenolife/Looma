import test from "node:test";
import assert from "node:assert/strict";
import {
  initialWorld,
  approveMission,
  reviewHandIn,
  completeCheck,
  claimMission,
  tapChest,
  practiceChest,
  chestTiers,
  rewardTables,
  multiplier,
  streakCount,
  settleDay,
  shiftDay,
  buySaver,
  requestRoom,
  reviewRoom,
  submitAssignment,
  occurrence,
  saveMission,
  aucklandDay,
  validWorld,
  type WorldState,
  type ChestTier,
} from "../src/lib/journey";
import {
  crateItems,
  halloweenOdds,
  rollCrate,
  purchaseCrate,
  species,
  cosmetics,
} from "../src/lib/collection";
const rolls = [0.99, 0.99, 0.99, 0.99, 0.99, 0.2];
function fresh() {
  return structuredClone(initialWorld);
}
function open(tier: ChestTier, seed = rolls) {
  let w = practiceChest(fresh(), tier, seed);
  const id = w.journey.chests[0].id;
  for (let i = 1; i <= 5; i++) w = tapChest(w, id, i * 500);
  return w;
}
function finishGym(w: WorldState) {
  const done = completeCheck(
    completeCheck(w, "move-and-make", "gym"),
    "move-and-make",
    "social",
  );
  return approveMission(
    done,
    "move-and-make",
    done.journey.day,
    "approved",
    "Reviewed in demo",
    "staff",
  );
}

test("a grouped mission requires every step and gives one chest, never immediate currency", () => {
  const w = fresh(),
    part = completeCheck(w, "move-and-make", "gym");
  assert.equal(part.journey.qualifiedDays.length, 0);
  assert.equal(
    claimMission(part, "move-and-make", part.journey.day, rolls),
    part,
  );
  const done = finishGym(w);
  assert.deepEqual(done.journey.qualifiedDays, [done.journey.day]);
  assert.equal(done.collection.balance, 500);
  const claimed = claimMission(done, "move-and-make", done.journey.day, rolls);
  assert.equal(claimed.journey.chests[0].tier, "silver");
  assert.equal(claimed.collection.balance, 500);
  assert.equal(
    claimMission(claimed, "move-and-make", done.journey.day, rolls),
    claimed,
  );
});
test("each tap persists and rapid or repeated taps do not advance or pay again", () => {
  let w = practiceChest(fresh(), "silver", rolls);
  const id = w.journey.chests[0].id;
  w = tapChest(w, id, 1000);
  assert.equal(w.journey.chests[0].taps, 1);
  assert.equal(tapChest(w, id, 1100), w);
  w = JSON.parse(JSON.stringify(w));
  assert.ok(validWorld(w));
  assert.equal(w.journey.chests[0].taps, 1);
  for (let i = 2; i <= 5; i++) w = tapChest(w, id, 1000 + i * 500);
  assert.equal(w.collection.balance, 600);
  assert.equal(tapChest(w, id, 99999), w);
  assert.equal(w.journey.chests[0].taps, 5);
});
test("all eight tiers upgrade at 10 percent, including the fifth tap, with a Void cap", () => {
  for (let index = 0; index < chestTiers.length; index++) {
    const tier = chestTiers[index],
      w = open(tier, [0.99, 0.99, 0.99, 0.99, 0.099999, 0.2]);
    assert.equal(w.journey.chests[0].tier, chestTiers[Math.min(index + 1, 7)]);
    assert.equal(
      open(tier, [0.1, 0.1, 0.1, 0.1, 0.1, 0.2]).journey.chests[0].tier,
      tier,
    );
  }
  assert.equal(
    open("wood", [0, 0, 0, 0, 0, 0.2]).journey.chests[0].tier,
    "ruby",
  );
  assert.equal(
    open("ruby", [0, 0, 0, 0, 0, 0.2]).journey.chests[0].tier,
    "void",
  );
});
test("every reward table totals 100 percent and Ruby boundaries match published outcomes", () => {
  for (const tier of chestTiers)
    assert.equal(
      rewardTables[tier].reduce((sum, r) => sum + r.chance, 0),
      100,
      tier,
    );
  assert.equal(
    open("ruby", [0.99, 0.99, 0.99, 0.99, 0.99, 0.699999]).journey.chests[0]
      .reward?.amount,
    500,
  );
  assert.equal(
    open("ruby", [0.99, 0.99, 0.99, 0.99, 0.99, 0.7]).journey.chests[0].reward
      ?.item,
    "rubytiara",
  );
  assert.equal(
    open("ruby", [0.99, 0.99, 0.99, 0.99, 0.99, 0.9]).journey.chests[0].reward
      ?.item,
    "rubio",
  );
});
test("earned collectible duplicates receive documented compensation exactly once", () => {
  let w = open("ruby", [0.99, 0.99, 0.99, 0.99, 0.99, 0.95]);
  assert.ok(w.collection.forms.includes("rubio"));
  assert.equal(w.collection.balance, 500);
  w = settleDay(w, shiftDay(w.journey.day, 1), "demo");
  w = practiceChest(w, "ruby", [0.99, 0.99, 0.99, 0.99, 0.99, 0.95]);
  const id = w.journey.chests[0].id;
  for (let i = 1; i <= 5; i++) w = tapChest(w, id, 10000 + i * 500);
  assert.equal(w.journey.chests[0].reward?.compensation, 150);
  assert.equal(w.collection.balance, 650);
  assert.equal(w.collection.forms.filter((f) => f === "rubio").length, 1);
  assert.equal(tapChest(w, id, 999999), w);
});
test("streak multipliers progress and automatic savers preserve without adding a day", () => {
  let w = finishGym(fresh());
  assert.equal(streakCount(w.journey), 1);
  w = buySaver(w);
  assert.equal(w.collection.balance, 380);
  w = settleDay(w, "2026-10-26", "demo");
  assert.equal(w.journey.savers, 0);
  assert.deepEqual(w.journey.protectedDays, ["2026-10-25"]);
  assert.equal(streakCount(w.journey), 1);
  assert.equal(settleDay(w, "2026-10-26", "demo"), w);
  w = settleDay(w, "2026-10-27", "demo");
  assert.equal(streakCount(w.journey), 0);
  for (const [count, factor] of [
    [0, 1],
    [2, 1],
    [3, 1.1],
    [7, 1.25],
    [14, 1.5],
    [30, 2],
  ])
    assert.equal(multiplier(count), factor);
});
test("multipliers raise expected rewards and currency payouts preserve their value", () => {
  let w = finishGym(fresh());
  w.journey.qualifiedDays = ["2026-10-22", "2026-10-23", "2026-10-24"];
  w = claimMission(w, "move-and-make", w.journey.day, rolls);
  assert.equal(w.journey.chests[0].expected, 110);
  const id = w.journey.chests[0].id;
  for (let i = 1; i <= 5; i++) w = tapChest(w, id, i * 500);
  assert.equal(w.collection.balance, 610);
});
test("a saver is not wasted before any streak and insufficient funds cannot buy one", () => {
  let w = fresh();
  w.journey.savers = 1;
  w = settleDay(w, "2026-10-26", "demo");
  assert.equal(w.journey.savers, 1);
  w.collection.balance = 0;
  assert.equal(buySaver(w), w);
});
test("days follow Auckland, including UTC date rollover", () => {
  assert.equal(aucklandDay(new Date("2026-10-24T11:30:00Z")), "2026-10-25");
  assert.equal(aucklandDay(new Date("2026-06-01T11:30:00Z")), "2026-06-01");
  assert.equal(shiftDay("2026-12-31", 1), "2027-01-01");
});
test("demo submissions complete the intended step, store metadata, and cannot be submitted twice", () => {
  const w = fresh(),
    m = w.journey.missions.find((m) => m.id === "hand-it-in")!;
  const data = {
    id: "s1",
    occurrence: occurrence(m, w.journey.day),
    stepId: "submit",
    day: w.journey.day,
    title: "A fictional report",
    subject: "Social Studies",
    teacher: "Ms Wren",
    summary: "Sample",
    status: "submitted" as const,
    staffNote: "",
    attachment: { name: "sample.txt", size: 100, type: "text/plain" },
  };
  const next = submitAssignment(w, data);
  assert.equal(next.journey.submissions.length, 1);
  assert.equal(next.journey.qualifiedDays.length, 0);
  assert.equal(
    reviewHandIn(next, "s1", "reviewed", "Reviewed", "staff").journey
      .qualifiedDays.length,
    1,
  );
  assert.equal(next.collection.balance, 500);
  assert.equal(submitAssignment(next, { ...data, id: "s2" }), next);
  assert.equal(completeCheck(w, "hand-it-in", "submit"), w);
});
test("room missions wait for staff approval, allow re-ready after follow-up, and cannot double grant", () => {
  let w = requestRoom(fresh(), "room-ready", "room");
  const id = w.journey.rooms[0].id;
  assert.equal(w.journey.qualifiedDays.length, 0);
  assert.equal(requestRoom(w, "room-ready", "room"), w);
  w = reviewRoom(w, id, "follow-up", "Fold the towel.", "staff");
  assert.equal(w.journey.qualifiedDays.length, 0);
  w = requestRoom(w, "room-ready", "room");
  assert.equal(w.journey.rooms[0].status, "ready");
  w = reviewRoom(w, id, "passed", "All tidy.", "staff");
  assert.equal(w.journey.qualifiedDays.length, 1);
  assert.equal(reviewRoom(w, id, "passed", "Again", "staff"), w);
  w = claimMission(w, "room-ready", w.journey.day, rolls);
  assert.equal(w.journey.chests.length, 1);
});
test("missions can be created and edited before starting; claim history survives later days", () => {
  let w = fresh();
  const m = {
    ...w.journey.missions[0],
    id: "custom",
    kind: "goal" as const,
    reward: 0,
    authorisedBy: undefined,
    preset: undefined,
    title: "A custom plan",
    repeat: false,
  };
  w = saveMission(w, m);
  assert.equal(w.journey.missions.length, 4);
  w = saveMission(w, { ...m, title: "An edited plan" });
  assert.equal(w.journey.missions[3].title, "An edited plan");
  w = finishGym(w);
  w = claimMission(w, "move-and-make", w.journey.day, rolls);
  w = settleDay(w, "2026-10-25", "demo");
  w = settleDay(w, "2026-10-24", "demo");
  assert.equal(claimMission(w, "move-and-make", w.journey.day, rolls), w);
});
test("Halloween has all five rarity tiers while earned-exclusive items never enter shop pools", () => {
  assert.equal(
    halloweenOdds.reduce((n, r) => n + r.chance, 0),
    100,
  );
  for (const kind of ["halloween-looma", "halloween-cosmetic"] as const) {
    assert.equal(crateItems(kind).length, 5);
    assert.equal(rollCrate(kind, 0.9999, 0).rarity, "mythical");
  }
  for (const kind of [
    "looma",
    "cosmetic",
    "halloween-looma",
    "halloween-cosmetic",
  ] as const)
    for (const item of crateItems(kind)) assert.notEqual(item.source, "reward");
  assert.ok(species.some((s) => s.id === "void" && s.source === "reward"));
  assert.ok(
    cosmetics.some((c) => c.id === "rubytiara" && c.source === "reward"),
  );
  let c = initialWorld.collection;
  c = purchaseCrate(c, "halloween-looma", 0.9999, 0, "once");
  assert.ok(c.forms.includes("eclipse"));
  assert.equal(purchaseCrate(c, "halloween-looma", 0.9999, 0, "once"), c);
});
test("corrupted state and incomplete chest outcomes are rejected", () => {
  assert.equal(validWorld(null), false);
  assert.equal(
    validWorld({
      ...initialWorld,
      journey: { ...initialWorld.journey, savers: -1 },
    }),
    false,
  );
  const w = practiceChest(fresh(), "ruby", rolls);
  w.journey.chests[0].taps = 5;
  assert.equal(validWorld(w), false);
});
