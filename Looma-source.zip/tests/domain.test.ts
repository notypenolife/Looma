import { test } from "node:test";
import assert from "node:assert/strict";
import { demoReply } from "../src/lib/chat";
import {
  initialStudent,
  initialStaff,
  defaultPet,
  timetable,
} from "../src/lib/data/mock";
import { dueLabel, roomSummary, openTasks } from "../src/lib/utils";
test("room completion counts follow-ups as checked, without changing disciplinary records", () => {
  const s = roomSummary(initialStaff.rooms);
  assert.deepEqual(s, {
    total: 12,
    passed: 5,
    followUp: 2,
    unchecked: 5,
    checked: 7,
  });
  const detentionCount = initialStaff.detentions.length;
  const rooms = initialStaff.rooms.map((r) => ({
    ...r,
    status: "passed" as const,
  }));
  assert.equal(roomSummary(rooms).checked, 12);
  assert.equal(initialStaff.detentions.length, detentionCount);
});
test("due dates use the fixed demo day rather than host time", () => {
  assert.equal(dueLabel("2026-10-14"), "Today");
  assert.equal(dueLabel("2026-10-15"), "Tomorrow");
  assert.equal(dueLabel("2026-10-13"), "Overdue");
});
test("homework replies follow live task state, including completion", () => {
  const reply = demoReply(
    "Do I have homework due?",
    initialStudent,
    defaultPet,
  );
  assert.match(reply, /4 things/);
  const done = {
    ...initialStudent,
    tasks: initialStudent.tasks.map((t) => ({ ...t, complete: true })),
  };
  assert.match(demoReply("homework", done, defaultPet), /Everything.*complete/);
  assert.equal(openTasks(done.tasks).length, 0);
});
test("deleted memories cannot appear in future replies", () => {
  assert.match(
    demoReply("Do you remember my sport?", initialStudent, defaultPet),
    /hockey/,
  );
  const cleared = { ...initialStudent, memories: [] };
  assert.doesNotMatch(
    demoReply("Do you remember my sport?", cleared, defaultPet),
    /hockey/,
  );
});
test("unrecognised questions do not fabricate authoritative school facts", () => {
  assert.match(
    demoReply(
      "What is the real school leave policy?",
      initialStudent,
      defaultPet,
    ),
    /don’t have a verified source/,
  );
  assert.match(
    demoReply("What uniform do I wear?", initialStudent, defaultPet),
    /not a verified school requirement/,
  );
});
test("weekday timetable changes and stays well formed", () => {
  assert.notEqual(timetable(0)[0].subject, timetable(1)[0].subject);
  assert.equal(timetable(2)[0].subject, "Mathematics");
  assert.equal(timetable(2).length, 5);
});
