import { test } from "node:test";
import assert from "node:assert/strict";
import {
  acceptDemoCompletion,
  demoApprovalNote,
} from "../src/lib/demo-acceptance";
import {
  initialWorld,
  completeCheck,
  requestRoom,
  submitAssignment,
  occurrence,
  saveMission,
} from "../src/lib/journey";
import { clearLoomaStorage } from "../src/lib/reset-demo";
import { presence, eventPerformance } from "../src/lib/embodiment";
import { performances } from "../src/lib/behaviours";
import type { PetForm } from "../src/lib/types";
const rolls = [0.99, 0.99, 0.99, 0.99, 0.99, 0.5];
const fresh = () => structuredClone(initialWorld);
test("demo accepts all completed evidence, issues one chest and leaves balance untouched until opening", () => {
  let w = fresh();
  w = completeCheck(w, "move-and-make", "gym");
  assert.equal(
    acceptDemoCompletion(w, "move-and-make", rolls).journey.chests.length,
    0,
  );
  w = acceptDemoCompletion(
    completeCheck(w, "move-and-make", "social"),
    "move-and-make",
    rolls,
  );
  assert.equal(w.journey.chests.length, 1);
  assert.equal(w.collection.balance, 500);
  assert.equal(
    w.journey.approvals?.[occurrence(w.journey.missions[0], w.journey.day)]
      .note,
    demoApprovalNote,
  );
  assert.equal(
    acceptDemoCompletion(w, "move-and-make", rolls).journey.chests.length,
    1,
  );
});
test("demo room and assignment acceptance updates evidence and cannot issue duplicate rewards", () => {
  let w = fresh();
  w = acceptDemoCompletion(
    requestRoom(w, "room-ready", "room"),
    "room-ready",
    rolls,
  );
  assert.equal(w.journey.rooms[0].status, "passed");
  assert.equal(w.journey.chests.length, 1);
  w = acceptDemoCompletion(
    requestRoom(w, "room-ready", "room"),
    "room-ready",
    rolls,
  );
  assert.equal(w.journey.chests.length, 1);
  const m = w.journey.missions.find((m) => m.id === "hand-it-in")!;
  const sub = {
    id: "test",
    occurrence: occurrence(m, w.journey.day),
    stepId: "submit",
    day: w.journey.day,
    title: "Demo essay",
    teacher: "Ms Finch",
    subject: "English",
    summary: "Local test",
    status: "submitted" as const,
    staffNote: "",
  };
  w = acceptDemoCompletion(submitAssignment(w, sub), m.id, rolls);
  assert.equal(w.journey.submissions[0].status, "reviewed");
  assert.equal(w.journey.chests.length, 2);
  w = acceptDemoCompletion(submitAssignment(w, sub), m.id, rolls);
  assert.equal(w.journey.chests.length, 2);
});
test("the demo adapter cannot turn a personal goal into currency", () => {
  const goal = {
    ...initialWorld.journey.missions[0],
    id: "goal",
    kind: "goal" as const,
    reward: 0,
    authorisedBy: undefined,
    preset: undefined,
  };
  let w = saveMission(fresh(), goal);
  for (const s of goal.steps) w = completeCheck(w, goal.id, s.id);
  assert.equal(acceptDemoCompletion(w, goal.id, rolls), w);
});
test("reset removes only Looma namespaced keys, including old versions", () => {
  const values = new Map([
    ["looma:v1:student", "old"],
    ["looma:v2:world", "old"],
    ["looma:chat", "old"],
    ["other-site", "keep"],
    ["looma-other", "keep"],
  ]);
  clearLoomaStorage({
    get length() {
      return values.size;
    },
    key: (i) => [...values.keys()][i] ?? null,
    removeItem: (k) => {
      values.delete(k);
    },
  });
  assert.deepEqual([...values.keys()], ["other-site", "looma-other"]);
});
test("every companion speaks in first person and actions are distinct physical sequences", () => {
  for (const form of Object.keys(presence) as PetForm[]) {
    const actions = performances(form);
    assert.ok(
      actions.every((a) => /\bI[’'m\s]/.test(a.line)),
      form,
    );
    const events = ["play", "snack", "focus", "rest"] as const;
    const poses = events.map((e) => eventPerformance(form, e, 0, actions));
    assert.deepEqual(
      poses.map((p) => p.motion),
      ["hop", "eat", "read", "doze"],
    );
    assert.equal(new Set(poses.map((p) => p.line)).size, 4);
    assert.equal(poses[3].expression, "sleepy");
  }
  assert.notEqual(presence.fiend.play, presence.shadow.play);
});
