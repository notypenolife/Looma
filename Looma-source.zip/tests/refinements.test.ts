import test from "node:test";
import assert from "node:assert/strict";
import {
  initialWorld,
  saveMission,
  completeCheck,
  claimMission,
  approveMission,
  requestApproval,
  rewardReady,
  submitAssignment,
  reviewHandIn,
  requestRoom,
  reviewRoom,
  migrateWorld,
  practiceChest,
  tapChest,
  rewardTables,
  exclusiveByTier,
  chestTiers,
  type Mission,
} from "../src/lib/journey";
import {
  species,
  legacyPip,
  cosmetics,
  crateItems,
} from "../src/lib/collection";
import {
  characterSheets,
  performances,
  choosePerformance,
} from "../src/lib/behaviours";
import { petRigs } from "../src/lib/pet-rig";
const fresh = () => structuredClone(initialWorld),
  rolls = [0.99, 0.99, 0.99, 0.99, 0.99, 0.95];
function done(w = fresh()) {
  return completeCheck(
    completeCheck(w, "move-and-make", "gym"),
    "move-and-make",
    "social",
  );
}
function goal(): Mission {
  return {
    ...initialWorld.journey.missions[0],
    id: "my-goal",
    title: "A personal plan",
    kind: "goal",
    reward: 0,
    authorisedBy: undefined,
    preset: undefined,
  };
}
test("student goals cannot assign currency, impersonate staff or claim chests", () => {
  const w = fresh();
  assert.equal(saveMission(w, { ...goal(), reward: 100 }), w);
  assert.equal(
    saveMission(w, {
      ...goal(),
      kind: "reward",
      authorisedBy: "Fake",
      reward: 100,
    }),
    w,
  );
  assert.equal(saveMission(w, { ...w.journey.missions[0], reward: 1200 }), w);
  let next = saveMission(w, goal());
  next = completeCheck(
    completeCheck(next, "my-goal", "gym"),
    "my-goal",
    "social",
  );
  assert.equal(next.journey.qualifiedDays.length, 0);
  assert.equal(claimMission(next, "my-goal", next.journey.day, rolls), next);
  assert.equal(requestApproval(next, "my-goal"), next);
  assert.equal(next.collection.balance, 500);
});
test("staff rewards use presets; student steps alone cannot approve or qualify a day", () => {
  const w = done();
  assert.equal(w.journey.qualifiedDays.length, 0);
  assert.equal(rewardReady(w.journey, w.journey.missions[0]), false);
  assert.equal(claimMission(w, "move-and-make", w.journey.day, rolls), w);
  assert.equal(
    approveMission(w, "move-and-make", w.journey.day, "approved", "self"),
    w,
  );
  const approved = approveMission(
    requestApproval(w, "move-and-make"),
    "move-and-make",
    w.journey.day,
    "approved",
    "Housemaster reviewed",
    "staff",
  );
  assert.equal(approved.journey.qualifiedDays.length, 1);
  const claimed = claimMission(approved, "move-and-make", w.journey.day, rolls);
  assert.equal(claimed.journey.chests.length, 1);
  assert.equal(
    claimMission(claimed, "move-and-make", w.journey.day, rolls),
    claimed,
  );
  assert.equal(
    saveMission(
      w,
      {
        ...goal(),
        kind: "reward",
        authorisedBy: "Teacher",
        preset: "room",
        reward: 100,
      },
      "staff",
    ),
    w,
  );
  assert.equal(
    saveMission(
      w,
      {
        ...goal(),
        kind: "reward",
        authorisedBy: "Teacher",
        preset: "room",
        reward: 25,
      },
      "staff",
    ).journey.missions.length,
    4,
  );
});
test("students cannot submit already-reviewed evidence or pass their own room", () => {
  let w = fresh();
  w = submitAssignment(w, {
    id: "fake-review",
    occurrence: `${w.journey.day}/hand-it-in`,
    stepId: "submit",
    day: w.journey.day,
    title: "Demo work",
    teacher: "Ms Wren",
    subject: "Social Studies",
    summary: "",
    staffNote: "Self-approved",
    status: "reviewed",
  });
  assert.equal(w.journey.submissions[0].status, "submitted");
  assert.equal(w.journey.submissions[0].staffNote, "");
  assert.equal(reviewHandIn(w, "fake-review", "reviewed", "self"), w);
  assert.equal(w.journey.qualifiedDays.length, 0);
  w = reviewHandIn(w, "fake-review", "reviewed", "Teacher reviewed", "staff");
  assert.equal(w.journey.qualifiedDays.length, 1);
  w = requestRoom(w, "room-ready", "room");
  const id = w.journey.rooms[0].id;
  assert.equal(reviewRoom(w, id, "passed", "self"), w);
  const checked = reviewRoom(w, id, "passed", "Staff reviewed", "staff");
  assert.equal(checked.journey.rooms[0].status, "passed");
});
test("migration converts untrusted legacy missions to zero-reward goals and preserves inventory and saved odds", () => {
  const old = fresh();
  delete old.schema;
  old.journey.missions.push({ ...goal(), kind: undefined, reward: 1200 });
  old.journey.missions[0].reward = 1200;
  old.collection.forms.push("rubio");
  const withChest = practiceChest(old, "wood", rolls);
  delete withChest.journey.chests[0].tableVersion;
  const next = migrateWorld(withChest);
  assert.equal(next.schema, 3);
  assert.equal(
    next.journey.missions.find((m) => m.id === "my-goal")?.reward,
    0,
  );
  assert.equal(next.journey.missions[0].kind, "goal");
  assert.ok(next.collection.forms.includes("rubio"));
  assert.equal(next.journey.chests[0].tableVersion, 1);
  const id = next.journey.chests[0].id;
  let opened = next;
  for (let i = 1; i <= 5; i++) opened = tapChest(opened, id, i * 500);
  assert.equal(opened.journey.chests[0].reward?.kind, "currency");
  assert.equal(migrateWorld(next), next);
});
test("every new tier has exactly its own exclusive Looma and a table totalling 100 percent", () => {
  const companions = new Set<string>();
  for (const tier of chestTiers) {
    const table = rewardTables[tier];
    assert.equal(
      table.reduce((n, r) => n + r.chance, 0),
      100,
    );
    const entries = table.filter((r) => r.kind === "looma");
    assert.equal(entries.length, 1);
    assert.equal(entries[0].item, exclusiveByTier[tier]);
    companions.add(entries[0].item!);
    let w = practiceChest(fresh(), tier, rolls);
    for (let i = 1; i <= 5; i++)
      w = tapChest(w, w.journey.chests[0].id, i * 500);
    assert.equal(w.journey.chests[0].reward?.item, exclusiveByTier[tier]);
  }
  assert.equal(companions.size, 8);
  for (const kind of [
    "looma",
    "cosmetic",
    "halloween-looma",
    "halloween-cosmetic",
  ] as const)
    assert.ok(crateItems(kind).every((i) => i.source !== "reward"));
});
test("all named characters have individual voices and complete, uniquely identified performance sets", () => {
  const all = [...species, legacyPip];
  assert.equal(
    new Set(all.map((s) => characterSheets[s.id].phrase)).size,
    all.length,
  );
  for (const s of all) {
    const actions = performances(s.id);
    assert.equal(actions.length, 16, s.name);
    for (const [category, count] of [
      ["entrance", 3],
      ["idle", 6],
      ["achievement", 3],
      ["surprise", 2],
      ["focus", 2],
    ])
      assert.equal(
        actions.filter((p) => p.category === category).length,
        count,
        s.name,
      );
    assert.equal(new Set(actions.map((p) => p.id)).size, 16);
    assert.ok(actions.every((p) => p.line && p.label && p.duration > 0));
    assert.ok(petRigs[s.id].neckY > 178);
    assert.ok(petRigs[s.id].headWidth >= 85);
  }
  assert.ok(
    performances("shadow")
      .filter((p) => p.category === "idle")
      .some((p) => p.prop === "book"),
  );
  assert.ok(performances("fiend").some((p) => p.motion === "sneak"));
  assert.notDeepEqual(
    performances("fiend")
      .filter((p) => p.category === "achievement")
      .map((p) => p.motion),
    performances("shadow")
      .filter((p) => p.category === "achievement")
      .map((p) => p.motion),
  );
  assert.equal(cosmetics.length, 19);
});
test("weighted behaviour selection respects cooldowns and avoids immediate repeats", () => {
  const first = choosePerformance("shadow", "idle", 1000, {}, undefined, 0.1)!;
  const next = choosePerformance(
    "shadow",
    "idle",
    2000,
    { [first.id]: 1000 },
    first.id,
    0.1,
  )!;
  assert.notEqual(next.id, first.id);
  const recent = Object.fromEntries(
    performances("shadow")
      .filter((p) => p.category === "idle")
      .map((p) => [p.id, 1000]),
  );
  assert.equal(
    choosePerformance("shadow", "idle", 2000, recent, first.id, 0.5),
    null,
  );
  assert.ok(choosePerformance("shadow", "idle", 100000, recent, first.id, 0.5));
});
