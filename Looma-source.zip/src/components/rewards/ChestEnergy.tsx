import type { CSSProperties } from "react";
import type { ChestTier } from "@/lib/journey";
import { chestTiers } from "@/lib/journey";
export function ChestEnergy({
  tier,
  taps,
  phase,
}: {
  tier: ChestTier;
  taps: number;
  phase: "tap" | "charge" | "open" | "rest";
}) {
  const count = 6 + chestTiers.indexOf(tier) * 2;
  return (
    <div
      className={`chest-energy energy-${tier} energy-${phase}`}
      style={{ "--charge": taps / 5 } as CSSProperties}
      aria-hidden="true"
    >
      <span className="energy-reservoir" />
      <span className="energy-ring ring-inner" />
      <span className="energy-ring ring-outer" />
      <span className="energy-seam" />
      {Array.from({ length: count }, (_, i) => {
        const angle = (i / count) * Math.PI * 2 + (taps % 3) * 0.24;
        return (
          <i
            key={i}
            className={`energy-grain grain-${i % 4}`}
            style={
              {
                "--energy-x": `${Math.cos(angle) * (60 + taps * 12 + (i % 3) * 12)}px`,
                "--energy-y": `${Math.sin(angle) * (50 + taps * 9) - 20}px`,
                "--energy-angle": `${i * 41}deg`,
                "--energy-delay": `${(i % 5) * 45}ms`,
                "--energy-size": `${3 + (i % 4) * 2}px`,
              } as CSSProperties
            }
          />
        );
      })}
      {phase === "open" && <span className="energy-opening-core" />}
    </div>
  );
}
