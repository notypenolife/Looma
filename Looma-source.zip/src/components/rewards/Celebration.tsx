"use client";
import { useEffect } from "react";
import * as Dialog from "@radix-ui/react-dialog";
import { useDemo } from "@/lib/store";
import { personalityReaction } from "@/lib/personality";
import { LoomaPet } from "../pets/LoomaPet";
export function Celebration() {
  const { celebration, dismissCelebration, pet } = useDemo();
  const id = celebration?.id;
  useEffect(() => {
    if (!id) return;
    const timer = setTimeout(dismissCelebration, 5500);
    return () => clearTimeout(timer);
  }, [id, dismissCelebration]);
  const reaction = personalityReaction(
    pet.form,
    celebration?.event ?? "task",
    12,
    id ? Array.from(id).reduce((n, c) => n + c.charCodeAt(0), 0) : 0,
  );
  return (
    <Dialog.Root
      open={!!celebration}
      onOpenChange={(open) => {
        if (!open) dismissCelebration();
      }}
    >
      <Dialog.Portal>
        <Dialog.Overlay className="celebration-overlay" />
        <Dialog.Content
          className="celebration-dialog"
          aria-describedby="celebration-line"
        >
          <Dialog.Close className="celebration-skip">
            Skip celebration →
          </Dialog.Close>
          <span className="eyebrow">A VERY SMALL STANDING OVATION</span>
          <div className={`celebration-stage pet-action-${reaction.animation}`}>
            <span className="celebration-confetti confetti-one" />
            <span className="celebration-confetti confetti-two" />
            <LoomaPet {...pet} expression="celebrating" />
          </div>
          <Dialog.Title>{celebration?.title}</Dialog.Title>
          <Dialog.Description id="celebration-line">
            “{reaction.line}”
          </Dialog.Description>
          <p className="celebration-signature">
            — {pet.name}, your tiny cheering section
          </p>
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog.Root>
  );
}
