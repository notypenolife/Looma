import { Droplets } from "lucide-react";
import type { ChestReward } from "@/lib/journey";
import type { PetPreferences, PetForm, Accessory } from "@/lib/types";
import { getSpecies } from "@/lib/collection";
import { LoomaPet } from "../pets/LoomaPet";

/** Visual only: the persisted chest outcome is already granted exactly once. */
export function RewardEjection({
  reward,
  pet,
}: {
  reward: ChestReward;
  pet: PetPreferences;
}) {
  return (
    <div
      className={`reward-ejection reward-ejection-${reward.kind}`}
      aria-hidden="true"
    >
      <span className="reward-flight-trail" />
      <div className="reward-flight-object">
        {reward.kind === "currency" ? (
          <div className="flying-dewdrops">
            <span className="flying-coin coin-left">
              <Droplets />
            </span>
            <span className="flying-coin coin-right">
              <Droplets />
            </span>
            <span className="flying-coin coin-main">
              <Droplets />
            </span>
            <strong>+{reward.amount?.toLocaleString()}</strong>
          </div>
        ) : (
          <>
            <LoomaPet
              form={
                reward.kind === "looma" ? (reward.item as PetForm) : pet.form
              }
              colour={
                reward.kind === "looma"
                  ? getSpecies(reward.item as PetForm).colour
                  : pet.colour
              }
              accessory={
                reward.kind === "cosmetic" ? (reward.item as Accessory) : "none"
              }
              expression="celebrating"
              animate={false}
            />
            <span className="flying-reward-label">{reward.label}</span>
          </>
        )}
      </div>
    </div>
  );
}
