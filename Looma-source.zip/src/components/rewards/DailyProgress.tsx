"use client";
import Link from "next/link";
import { Flag, Gift, ArrowUpRight } from "lucide-react";
import { useDemo } from "@/lib/store";
import { finished, isScheduled, streakCount, multiplier } from "@/lib/journey";
export function DailyProgress() {
  const { journey } = useDemo();
  const missions = journey.missions.filter((m) => isScheduled(m, journey.day));
  return (
    <div className="daily-progress-links">
      <Link href="/student/missions">
        <Flag size={19} />
        <div>
          <strong>
            {missions.filter((m) => finished(journey, m)).length} of{" "}
            {missions.length} missions finished
          </strong>
          <span>
            {multiplier(streakCount(journey))}× multiplier · a little progress
            at a time
          </span>
        </div>
        <ArrowUpRight size={16} />
      </Link>
      <Link href="/student/chests">
        <Gift size={20} />
        <div>
          <strong>
            {journey.chests.filter((c) => c.taps < 5).length} earned chests
            waiting
          </strong>
          <span>Five little taps. A small surprise.</span>
        </div>
        <ArrowUpRight size={16} />
      </Link>
    </div>
  );
}
