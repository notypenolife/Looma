"use client";
import { useState, type CSSProperties } from "react";
import type { Performance } from "@/lib/behaviours";
import { useDemo } from "@/lib/store";
import { personalityReaction } from "@/lib/personality";
import { LoomaPet } from "../pets/LoomaPet";
export function ParticleBurst() {
  return (
    <span className="local-particle-burst" aria-hidden="true">
      {Array.from({ length: 12 }, (_, i) => (
        <i
          key={i}
          style={
            {
              "--particle-x": `${Math.cos((i / 12) * Math.PI * 2) * (35 + (i % 3) * 13)}px`,
              "--particle-y": `${Math.sin((i / 12) * Math.PI * 2) * (30 + (i % 4) * 10) - 12}px`,
              "--particle-rotation": `${i * 33}deg`,
              "--particle-delay": `${(i % 3) * 35}ms`,
            } as CSSProperties
          }
        />
      ))}
    </span>
  );
}
export function InlineCompanion() {
  const { pet, feedback } = useDemo();
  const [acting, setActing] = useState<Performance | null>(null);
  const variant = feedback
    ? Array.from(feedback.id).reduce((n, c) => n + c.charCodeAt(0), 0)
    : 0;
  const reaction = personalityReaction(
    pet.form,
    feedback?.event ?? "hello",
    12,
    variant,
  );
  return (
    <aside className="inline-companion">
      <div className="inline-companion-pet">
        <LoomaPet
          {...pet}
          cue={feedback ?? undefined}
          onPerformance={setActing}
        />
      </div>
      <div>
        <strong>{pet.name}’s little corner</strong>
        <p role="status">
          {feedback
            ? `${feedback.title} “${acting?.line ?? reaction.line}”`
            : (acting?.line ?? reaction.line)}
        </p>
      </div>
    </aside>
  );
}
