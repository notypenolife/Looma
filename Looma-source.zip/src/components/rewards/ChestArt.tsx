import type { CSSProperties } from "react";
import type { ChestTier } from "@/lib/journey";
export const chestPaint: Record<
  ChestTier,
  {
    body: string;
    side: string;
    lid: string;
    metal: string;
    gem: string;
    glow: string;
  }
> = {
  wood: {
    body: "#C7A17B",
    side: "#A7805C",
    lid: "#E0BD95",
    metal: "#8B7052",
    gem: "#E1CAA5",
    glow: "#EBD4AA",
  },
  bronze: {
    body: "#BF906D",
    side: "#9A6B4B",
    lid: "#DDB38E",
    metal: "#E2B780",
    gem: "#F9DDA2",
    glow: "#F4CB92",
  },
  silver: {
    body: "#B7C6CE",
    side: "#8FABB9",
    lid: "#DCE6E9",
    metal: "#F3F3E9",
    gem: "#8EAEBE",
    glow: "#D4EAF1",
  },
  platinum: {
    body: "#A9C9C5",
    side: "#7DAAA7",
    lid: "#D1E5DC",
    metal: "#EBF5E9",
    gem: "#87C3B4",
    glow: "#BDE3D1",
  },
  gold: {
    body: "#D5B568",
    side: "#B49448",
    lid: "#F0D998",
    metal: "#F7E9BB",
    gem: "#A7BA8C",
    glow: "#F7DC83",
  },
  ruby: {
    body: "#B8787E",
    side: "#98525F",
    lid: "#DB9E9E",
    metal: "#EBC88A",
    gem: "#AA3F5D",
    glow: "#F5ACB7",
  },
  diamond: {
    body: "#ACBFDE",
    side: "#7E9DC5",
    lid: "#D8E4F1",
    metal: "#F0E9F4",
    gem: "#CBF0F1",
    glow: "#C0EAF9",
  },
  void: {
    body: "#343239",
    side: "#25242B",
    lid: "#4F4549",
    metal: "#CFB86F",
    gem: "#B45D54",
    glow: "#E0BC63",
  },
};
export function ChestArt({
  tier,
  opened = false,
  className = "",
}: {
  tier: ChestTier;
  opened?: boolean;
  className?: string;
}) {
  const p = chestPaint[tier];
  return (
    <svg
      viewBox="0 0 360 280"
      role="img"
      aria-label={`${tier} reward chest${opened ? ", opened" : ""}`}
      className={`earned-chest-art ${opened ? "chest-art-open" : ""} ${className}`}
      style={{ "--chest-glow": p.glow } as CSSProperties}
    >
      <ellipse cx="180" cy="251" rx="108" ry="12" fill={p.side} opacity=".12" />
      {opened && (
        <g className="chest-rays" stroke={p.glow} strokeLinecap="round">
          <path
            d="M178 142V27M144 144L93 43M215 143L267 47M127 165L47 106M235 162L316 105"
            strokeWidth="8"
            opacity=".6"
          />
          <path d="M165 140L143 18M198 141L223 19" strokeWidth="3" />
        </g>
      )}
      <g
        stroke={tier === "void" ? "#C4A765" : "#5B5B50"}
        strokeWidth="2.6"
        strokeLinejoin="round"
        strokeLinecap="round"
      >
        {tier === "void" && (
          <>
            <path
              d="M92 106Q61 79 73 42Q83 69 113 72M246 76Q274 68 285 44Q295 81 266 105"
              fill={p.body}
            />
            <path
              d="M89 172Q33 220 86 238M274 174Q328 210 278 235"
              fill="none"
              stroke={p.metal}
              strokeWidth="5"
            />
          </>
        )}
        <path d="M70 135L182 170L290 135V214L182 250L70 214Z" fill={p.body} />
        <path d="M182 170L290 135V214L182 250Z" fill={p.side} />
        <path
          d="M79 171L174 202M79 194L174 225M199 200L278 174M199 223L278 197"
          fill="none"
          stroke={p.side}
          opacity=".4"
        />
        <path
          d="M94 144L110 149V226L94 221ZM151 162L166 166V244L151 240"
          fill={p.metal}
        />
        <path
          d="M214 159L228 154V235L214 240M265 143L279 138V218L265 223"
          fill={p.metal}
        />
        <g className="earned-chest-lid">
          <path
            d="M66 127Q64 76 115 65L184 48L248 66Q295 80 294 127L183 164Z"
            fill={p.lid}
          />
          <path d="M184 48V164L294 127Q297 84 248 66Z" fill={p.body} />
          <path d="M66 127V145L183 181L294 144V127L183 164Z" fill={p.metal} />
          <path
            d="M95 77Q104 72 115 70L115 142L97 136ZM151 59L168 54V159L151 154"
            fill={p.metal}
          />
          <path
            d="M217 57L234 62V147L217 153M267 77Q278 83 284 95L284 131L268 137Z"
            fill={p.metal}
          />
        </g>
        <path
          d="M160 158L183 165L202 158V188L182 206L161 186Z"
          fill={p.metal}
        />
        <path d="M172 176L182 168L193 177L182 191Z" fill={p.gem} />
        {tier !== "wood" && tier !== "bronze" && (
          <>
            <path d="M121 186L132 175L143 192L132 207Z" fill={p.gem} />
            <circle cx="245" cy="192" r="6" fill={p.gem} />
          </>
        )}
        {tier === "void" && (
          <g fill="none" stroke={p.metal} strokeWidth="3">
            <ellipse
              cx="87"
              cy="177"
              rx="9"
              ry="14"
              transform="rotate(35 87 177)"
            />
            <ellipse
              cx="76"
              cy="195"
              rx="9"
              ry="14"
              transform="rotate(35 76 195)"
            />
            <ellipse cx="76" cy="217" rx="9" ry="14" />
            <ellipse cx="94" cy="232" rx="13" ry="8" />
            <ellipse
              cx="284"
              cy="176"
              rx="9"
              ry="14"
              transform="rotate(-35 284 176)"
            />
            <ellipse cx="295" cy="197" rx="9" ry="14" />
            <ellipse
              cx="289"
              cy="220"
              rx="9"
              ry="14"
              transform="rotate(35 289 220)"
            />
          </g>
        )}
      </g>
    </svg>
  );
}
