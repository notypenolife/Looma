"use client";
import { useRouter } from "next/navigation";
import { useState } from "react";
import Link from "next/link";
import {
  Bell,
  Moon,
  ShieldCheck,
  ArrowLeftRight,
  RotateCcw,
  ArrowUpRight,
  LockKeyhole,
  Leaf,
  Download,
  Check,
} from "lucide-react";
import { useDemo } from "@/lib/store";
import { PageHeading, Badge, Modal } from "./ui/shared";
export function Settings({ role }: { role: "student" | "staff" }) {
  const {
    preferences,
    setPreferences,
    reset,
    pet,
    student,
    staff,
    collection,
    journey,
  } = useDemo();
  const router = useRouter();
  const [confirm, setConfirm] = useState(false);
  const [status, setStatus] = useState("");
  function exportData() {
    const data =
      role === "student"
        ? { companion: pet, collection, journey, student, preferences }
        : { staff };
    const blob = new Blob([JSON.stringify(data, null, 2)], {
      type: "application/json",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `looma-${role}-demo.json`;
    a.click();
    URL.revokeObjectURL(url);
    setStatus("Demo data exported.");
  }
  return (
    <>
      <PageHeading
        eyebrow="MAKE A LITTLE ROOM FOR YOURSELF"
        title="Just the way you like it."
        description="Your preferences, your information, your choices."
      />
      <div className="settings-layout">
        <section className="panel settings-section">
          <div className="settings-title">
            <Bell size={23} />
            <div>
              <h2>A gentle heads-up.</h2>
              <p>Saved preferences for future notifications.</p>
            </div>
            <Badge>Simulated</Badge>
          </div>
          {[
            {
              key: "homework",
              title: "Homework reminders",
              detail: "A little nudge before something is due.",
            },
            {
              key: "boarding",
              title: "Boarding notices",
              detail: "Updates from around the house.",
            },
            {
              key: "quiet",
              title: "Quiet evenings",
              detail: "Keep 21:00–07:00 free from notifications.",
            },
          ].map(({ key, title, detail }) => (
            <div className="setting-row" key={key}>
              <div>
                <h3>{title}</h3>
                <p>{detail}</p>
              </div>
              <button
                className={`toggle ${preferences[key as keyof typeof preferences] ? "on" : ""}`}
                role="switch"
                aria-checked={preferences[key as keyof typeof preferences]}
                aria-label={title}
                onClick={() => {
                  setPreferences((p) => ({
                    ...p,
                    [key]: !p[key as keyof typeof p],
                  }));
                  setStatus("Preference saved in this browser.");
                }}
              >
                <span />
              </button>
            </div>
          ))}
          <div className="panel-foot">
            <Moon size={14} />
            No push notifications are sent in this prototype.
          </div>
        </section>
        <section className="panel settings-section">
          <div className="settings-title">
            <ShieldCheck size={23} />
            <div>
              <h2>Your little space.</h2>
              <p>Clear boundaries, by design.</p>
            </div>
          </div>
          <div className="setting-row">
            <div>
              <h3>
                {role === "student" ? "Approved memories" : "Staff records"}
              </h3>
              <p>
                {role === "student"
                  ? "View, edit, or remove what Looma remembers."
                  : "Fictional records, kept separate from companion data."}
              </p>
            </div>
            <Link
              href={
                role === "student"
                  ? "/student/looma#memories"
                  : "/staff/inspections"
              }
              className="button button-outline button-small"
            >
              Manage
              <ArrowUpRight size={15} />
            </Link>
          </div>
          <div className="setting-row">
            <div>
              <h3>Export demo data</h3>
              <p>Download your {role} demo as a JSON file.</p>
            </div>
            <button
              className="button button-outline button-small"
              onClick={exportData}
            >
              <Download size={15} />
              Export
            </button>
          </div>
          <div className="setting-row">
            <div>
              <h3>Start fresh</h3>
              <p>
                Reset all fictional student, pet, collection, currency, and
                staff data in this browser.
              </p>
            </div>
            <button
              className="button button-outline button-small"
              onClick={() => setConfirm(true)}
            >
              <RotateCcw size={15} />
              Reset demo account
            </button>
          </div>
        </section>
        <section className="panel settings-section">
          <div className="settings-title">
            <ArrowLeftRight size={23} />
            <div>
              <h2>See the other side.</h2>
              <p>Two perspectives on a calmer boarding day.</p>
            </div>
          </div>
          <div className="role-cards">
            <Link
              href="/student"
              className={role === "student" ? "selected" : ""}
            >
              <Leaf size={21} />
              <strong>Student demo</strong>
              <p>Alex Rivers · Year 11</p>
              {role === "student" ? (
                <Badge tone="sage">You’re here</Badge>
              ) : (
                <span className="text-link">
                  Explore
                  <ArrowUpRight size={14} />
                </span>
              )}
            </Link>
            <Link href="/staff" className={role === "staff" ? "selected" : ""}>
              <ShieldCheck size={21} />
              <strong>Staff demo</strong>
              <p>Morgan Thompson · Duty staff</p>
              {role === "staff" ? (
                <Badge tone="sage">You’re here</Badge>
              ) : (
                <span className="text-link">
                  Explore
                  <ArrowUpRight size={14} />
                </span>
              )}
            </Link>
          </div>
          <p className="source-note">
            This switch changes the fictional demo view. It does not grant real
            staff access.
          </p>
        </section>
        <section className="account-note">
          <LockKeyhole size={24} />
          <div>
            <h3>A prototype, with care.</h3>
            <p>
              No real accounts are connected. Sign-in, school memberships, and
              secure staff permissions will arrive with Supabase Auth. Nothing
              here is a real school record.
            </p>
            <Badge tone="sage">Local browser storage only</Badge>
          </div>
        </section>
      </div>
      <p className="save-status" role="status">
        {status}
      </p>
      <Modal
        open={confirm}
        onOpenChange={setConfirm}
        title="A fresh page for the demo?"
        description="Reset currency, inventory, missions, homework, streaks, chests, conversations, memories, companion preferences and fictional staff changes. Only Looma data in this browser is cleared. You’ll choose a starter again. Unrelated browser data is kept."
      >
        <div className="dialog-actions">
          <button
            className="button button-outline"
            onClick={() => setConfirm(false)}
          >
            Keep my changes
          </button>
          <button
            className="button button-danger"
            onClick={() => {
              reset();
              setConfirm(false);
              router.push("/student/looma#starter-selection");
            }}
          >
            <Check size={16} />
            Reset all demo data
          </button>
        </div>
      </Modal>
    </>
  );
}
