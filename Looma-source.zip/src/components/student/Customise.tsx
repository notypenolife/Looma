"use client";
import { useState } from "react";
import {
  Check,
  Leaf,
  Glasses,
  Pencil,
  Trash2,
  Plus,
  LockKeyhole,
  Heart,
  Backpack,
} from "lucide-react";
import { useDemo } from "@/lib/store";
import { LoomaPet, petPalettes } from "../pets/LoomaPet";
import { Badge, PageHeading, Modal, EmptyState } from "../ui/shared";
import type {
  PetPreferences,
  PetColour,
  Accessory,
  Expression,
  Memory,
} from "@/lib/types";
import Link from "next/link";
import { species, cosmetics, legacyPip, sourceLabel } from "@/lib/collection";
import { uid } from "@/lib/utils";
const accessories: { id: Accessory; name: string; icon: typeof Leaf }[] = [
  { id: "none", name: "Just me", icon: Heart },
  { id: "scarf", name: "Cosy scarf", icon: Leaf },
  { id: "glasses", name: "Round specs", icon: Glasses },
  { id: "satchel", name: "Little satchel", icon: Backpack },
  ...cosmetics
    .filter((c) => !["scarf", "glasses", "satchel"].includes(c.id))
    .map((c) => ({ id: c.id, name: c.name, icon: Leaf })),
];
function CustomiseEditor() {
  const {
    pet,
    setPet,
    student,
    setStudent,
    collection,
    resetNotice,
    acknowledgeReset,
  } = useDemo();
  const forms = pet.form === "pip" ? [...species, legacyPip] : species;
  const [draft, setDraft] = useState<PetPreferences>(pet);
  const [expression, setExpression] = useState<Expression>("happy");
  const [toast, setToast] = useState("");
  const [memoryOpen, setMemoryOpen] = useState(false);
  const [editingMemory, setEditingMemory] = useState<Memory | null>(null);
  const [deleteMemory, setDeleteMemory] = useState<Memory | null>(null);
  const dirty = JSON.stringify(draft) !== JSON.stringify(pet);
  function savePet() {
    if (!draft.name.trim()) return;
    setPet({ ...draft, name: draft.name.trim() });
    setDraft({ ...draft, name: draft.name.trim() });
    acknowledgeReset();
    setToast("Your Looma is saved in this browser.");
  }
  function saveMemory(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const text = String(new FormData(e.currentTarget).get("memory")).trim();
    if (!text) return;
    const memory = {
      id: editingMemory?.id || uid(),
      text,
      approvedAt: new Date().toISOString(),
    };
    setStudent((s) => ({
      ...s,
      memories: editingMemory
        ? s.memories.map((m) => (m.id === editingMemory.id ? memory : m))
        : [...s.memories, memory],
    }));
    setMemoryOpen(false);
    setToast("Preference approved and saved in this browser.");
  }
  return (
    <>
      <PageHeading
        eyebrow="YOURS, IN THE LITTLE DETAILS"
        title="A Looma of your own."
        description="Find their shape. Add a little character. Make them yours."
        action={
          <button
            className="button button-dark"
            disabled={!dirty || !draft.name.trim()}
            onClick={savePet}
          >
            <Check size={17} />
            Save my Looma
          </button>
        }
      />
      {resetNotice && (
        <p role="status" className="reset-success">
          Demo account reset. Your starting Dewdrops and sample records are
          restored. Choose your starter below.
        </p>
      )}
      <Link className="text-link studio-entry-link" href="/student/studio">
        Meet every personality & preview accessory fits →
      </Link>
      <div className="customise-layout">
        <aside className="customise-preview">
          <div className="preview-top">
            <Badge tone="sage">YOUR COMPANION</Badge>
            <span>{dirty ? "Unsaved preview" : "All settled in"}</span>
          </div>
          <div className="customise-scene">
            <div className="scene-circle" />
            <span className="scene-leaf">
              <Leaf size={32} />
            </span>
            <LoomaPet {...draft} expression={expression} />
            <span className="scene-seed seed-one" />
            <span className="scene-seed seed-two" />
          </div>
          <h2>{draft.name.trim() || "Your Looma"}</h2>
          <p>A little company. A little clarity.</p>
          <div className="expression-picker" aria-label="Preview expression">
            {(
              [
                "happy",
                "curious",
                "thinking",
                "sleepy",
                "celebrating",
              ] as Expression[]
            ).map((exp) => (
              <button
                key={exp}
                className={expression === exp ? "selected" : ""}
                aria-pressed={expression === exp}
                onClick={() => setExpression(exp)}
              >
                {exp}
              </button>
            ))}
          </div>
          <div className="preview-care">
            <Heart size={15} />
            <p>Always happy to see you. No attention to earn.</p>
          </div>
        </aside>
        <div className="customise-controls">
          <section className="customise-section">
            <div className="step-heading">
              <span>01</span>
              <div>
                <h2>Say their name.</h2>
                <p>Something that feels like them.</p>
              </div>
            </div>
            <label className="form-label" htmlFor="pet-name">
              Looma name
            </label>
            <input
              id="pet-name"
              className="pet-name-input"
              maxLength={24}
              value={draft.name}
              onChange={(e) =>
                setDraft((d) => ({ ...d, name: e.target.value }))
              }
            />
            <small className="input-hint">
              Up to 24 characters. Change it whenever you like.
            </small>
          </section>
          <section className="customise-section">
            <div className="step-heading">
              <span>02</span>
              <div>
                <h2>Find their form.</h2>
                <p>
                  Three free starters. More little personalities in the shop.
                </p>
              </div>
            </div>
            <div className="form-picker" id="starter-selection">
              {forms.map((f) => (
                <button
                  key={f.id}
                  className={`form-option ${draft.form === f.id ? "selected" : ""}`}
                  aria-pressed={draft.form === f.id}
                  disabled={!f.starter && !collection.forms.includes(f.id)}
                  onClick={() =>
                    setDraft((d) => ({ ...d, form: f.id, colour: f.colour }))
                  }
                >
                  {draft.form === f.id && (
                    <span className="selection-check">
                      <Check size={12} />
                    </span>
                  )}
                  <LoomaPet form={f.id} colour={f.colour} animate={false} />
                  <strong>{f.name}</strong>
                  <span className="wardrobe-item-source">
                    {f.starter ? "Free starter" : sourceLabel(f.source)}
                  </span>
                  <small>
                    {!f.starter && !collection.forms.includes(f.id)
                      ? sourceLabel(f.source)
                      : f.personality}
                  </small>
                </button>
              ))}
            </div>
          </section>
          <Link className="text-link wardrobe-shop-link" href="/student/shop">
            Visit the little shop for more Loomas & accessories →
          </Link>
          <section className="customise-section">
            <div className="step-heading">
              <span>03</span>
              <div>
                <h2>A colour, a little detail.</h2>
                <p>A considered palette and a few favourite things.</p>
              </div>
            </div>
            <div className="colour-picker">
              {(Object.keys(petPalettes) as PetColour[]).map((colour) => (
                <button
                  key={colour}
                  className={draft.colour === colour ? "selected" : ""}
                  aria-pressed={draft.colour === colour}
                  onClick={() => setDraft((d) => ({ ...d, colour }))}
                >
                  <span style={{ background: petPalettes[colour].body }}>
                    {draft.colour === colour && <Check size={19} />}
                  </span>
                  <small>{colour}</small>
                </button>
              ))}
            </div>
            <div className="accessory-picker">
              {accessories.map(({ id, name, icon: Icon }) => (
                <button
                  key={id}
                  aria-pressed={draft.accessory === id}
                  disabled={!collection.accessories.includes(id)}
                  className={draft.accessory === id ? "selected" : ""}
                  onClick={() => setDraft((d) => ({ ...d, accessory: id }))}
                >
                  <Icon size={20} strokeWidth={1.5} />
                  <span>
                    {name}
                    {!collection.accessories.includes(id) && (
                      <LockKeyhole size={12} />
                    )}
                  </span>
                  <small className="wardrobe-item-source">
                    {id === "none"
                      ? "Always available"
                      : sourceLabel(cosmetics.find((c) => c.id === id)?.source)}
                  </small>
                </button>
              ))}
            </div>
          </section>
          <section className="customise-section">
            <div className="step-heading">
              <span>04</span>
              <div>
                <h2>Your kind of conversation.</h2>
                <p>How would you like Looma to sound?</p>
              </div>
            </div>
            <div className="tone-picker">
              {[
                {
                  id: "warm",
                  title: "Warm & calm",
                  detail: "A gentle nudge, with room to think.",
                },
                {
                  id: "concise",
                  title: "Keep it brief",
                  detail: "The useful bits, a little quicker.",
                },
                {
                  id: "playful",
                  title: "Lightly playful",
                  detail: "A little personality along the way.",
                },
              ].map((t) => (
                <button
                  key={t.id}
                  aria-pressed={draft.tone === t.id}
                  className={draft.tone === t.id ? "selected" : ""}
                  onClick={() =>
                    setDraft((d) => ({
                      ...d,
                      tone: t.id as PetPreferences["tone"],
                    }))
                  }
                >
                  <span className="radio-dot" />
                  <span>
                    <strong>{t.title}</strong>
                    <small>{t.detail}</small>
                  </span>
                </button>
              ))}
            </div>
          </section>
          <div className="customise-save">
            <p role="status">
              {toast ||
                (dirty
                  ? "A few little changes to save."
                  : "Looking like themselves.")}
            </p>
            <button
              className="button button-dark"
              disabled={!dirty || !draft.name.trim()}
              onClick={savePet}
            >
              Save my Looma
              <Check size={17} />
            </button>
          </div>
        </div>
      </div>
      <section className="memory-section" id="memories">
        <div className="section-heading">
          <div>
            <p className="eyebrow">ONLY WHAT YOU CHOOSE</p>
            <h2>A little about you.</h2>
            <p>
              Approved personal preferences. You’re in charge of what stays.
            </p>
          </div>
          <button
            className="button button-outline"
            onClick={() => {
              setEditingMemory(null);
              setMemoryOpen(true);
            }}
          >
            <Plus size={17} />
            Add a memory
          </button>
        </div>
        <div className="memory-list">
          {student.memories.map((m) => (
            <article key={m.id}>
              <span className="memory-icon">
                <Leaf size={19} />
              </span>
              <div>
                <h3>{m.text}</h3>
                <p>Approved by you · Sample memory</p>
              </div>
              <button
                className="icon-button"
                aria-label={`Edit memory: ${m.text}`}
                onClick={() => {
                  setEditingMemory(m);
                  setMemoryOpen(true);
                }}
              >
                <Pencil size={16} />
              </button>
              <button
                className="icon-button"
                aria-label={`Delete memory: ${m.text}`}
                onClick={() => setDeleteMemory(m)}
              >
                <Trash2 size={16} />
              </button>
            </article>
          ))}
          {student.memories.length === 0 && (
            <EmptyState title="A fresh page.">
              No approved memories. Add a simple preference if you’d like.
            </EmptyState>
          )}
        </div>
        <p className="memory-privacy">
          <LockKeyhole size={14} />
          No automatic storage of conversations. These preferences are separate
          from staff records.
        </p>
      </section>
      <Modal
        open={memoryOpen}
        onOpenChange={setMemoryOpen}
        title={
          editingMemory
            ? "Update a little detail."
            : "Something you’d like remembered."
        }
        description="Add a simple preference, such as your favourite sport. Please use fictional information in this demo."
      >
        <form className="form-stack" onSubmit={saveMemory}>
          <label>
            Approved preference
            <textarea
              autoFocus
              name="memory"
              rows={3}
              required
              maxLength={200}
              defaultValue={editingMemory?.text}
              placeholder="I like to…"
            />
          </label>
          <p className="input-hint">
            Adding this explicitly approves it for sample chat responses. You
            can delete it anytime.
          </p>
          <button className="button button-dark" type="submit">
            Approve & save
            <Check size={16} />
          </button>
        </form>
      </Modal>
      <Modal
        open={!!deleteMemory}
        onOpenChange={() => setDeleteMemory(null)}
        title="Let this little detail go?"
        description="It will be removed from approved memories and future sample replies."
      >
        <p className="delete-detail">{deleteMemory?.text}</p>
        <div className="dialog-actions">
          <button
            className="button button-outline"
            onClick={() => setDeleteMemory(null)}
          >
            Keep memory
          </button>
          <button
            className="button button-danger"
            onClick={() => {
              setStudent((s) => ({
                ...s,
                memories: s.memories.filter((m) => m.id !== deleteMemory?.id),
              }));
              setDeleteMemory(null);
              setToast("Memory removed from this browser.");
            }}
          >
            Delete memory
            <Trash2 size={16} />
          </button>
        </div>
      </Modal>
    </>
  );
}

export function Customise() {
  const { pet } = useDemo();
  return <CustomiseEditor key={JSON.stringify(pet)} />;
}
