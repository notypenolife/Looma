"use client";
import { useRef, useState, useEffect, type CSSProperties } from "react";
import { useSearchParams } from "next/navigation";
import Link from "next/link";
import {
  ArrowUpRight,
  Check,
  Droplets,
  LockKeyhole,
  PackageOpen,
} from "lucide-react";
import { useDemo } from "@/lib/store";
import {
  chestTiers,
  chestTable,
  exclusiveByTier,
  tierRarity,
  type ChestTier,
} from "@/lib/journey";
import { getSpecies } from "@/lib/collection";
import type { PetForm, Accessory } from "@/lib/types";
import { ChestArt, chestPaint } from "../rewards/ChestArt";
import { PageHeading, Badge } from "../ui/shared";
import { Dewdrop } from "./Shop";
import { RewardEjection } from "../rewards/RewardEjection";
import { ChestEnergy } from "../rewards/ChestEnergy";
import { InlineCompanion } from "../rewards/LocalFeedback";
import { LoomaPet } from "../pets/LoomaPet";

export function Chests() {
  const {
    journey,
    collection,
    pet,
    setPet,
    tapEarnedChest,
    addPracticeChest,
    celebrateMythical,
  } = useDemo();
  const search = useSearchParams();
  const [selectedId, setSelectedId] = useState<string | null>(null),
    [busy, setBusy] = useState(false),
    [oddsTier, setOddsTier] = useState<ChestTier | null>(null),
    [notice, setNotice] = useState("");
  const [reveal, setReveal] = useState<{
    id: string;
    phase: "charge" | "open";
  } | null>(null);
  const revealTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const lock = useRef(false),
    timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  useEffect(
    () => () => {
      if (timer.current) clearTimeout(timer.current);
      if (revealTimer.current) clearTimeout(revealTimer.current);
    },
    [],
  );
  const pending = journey.chests.filter((c) => c.taps < 5),
    opened = journey.chests.filter((c) => c.taps === 5);
  const selected =
    journey.chests.find((c) => c.id === (selectedId ?? search.get("chest"))) ??
    pending[0] ??
    opened[0];
  const odds = oddsTier ?? selected?.tier ?? "silver";
  function tap() {
    if (!selected || lock.current || selected.taps >= 5) return;
    lock.current = true;
    setBusy(true);
    const last = selected.taps === 4,
      id = selected.id;
    if (last) {
      setReveal({ id, phase: "charge" });
      revealTimer.current = setTimeout(
        () => setReveal({ id, phase: "open" }),
        550,
      );
    }
    tapEarnedChest(id);
    timer.current = setTimeout(
      () => {
        lock.current = false;
        setBusy(false);
        if (last) {
          setReveal(null);
          celebrateMythical(id);
        }
      },
      last ? 1550 : 500,
    );
  }
  const activeReveal = selected && reveal?.id === selected.id ? reveal : null;
  const revealReady = !!selected?.reward && !activeReveal;
  function equip() {
    const reward = selected?.reward;
    if (!reward || reward.kind === "currency") return;
    if (
      reward.kind === "looma" &&
      collection.forms.includes(reward.item as PetForm)
    ) {
      const s = getSpecies(reward.item as PetForm);
      setPet((p) => ({ ...p, form: s.id, colour: s.colour }));
    } else if (
      reward.kind === "cosmetic" &&
      collection.accessories.includes(reward.item as Accessory)
    )
      setPet((p) => ({ ...p, accessory: reward.item as Accessory }));
    setNotice("Equipped. A little treasure, ready for the day.");
  }
  return (
    <>
      <PageHeading
        eyebrow="YOUR EFFORT, TUCKED INTO A LITTLE BOX"
        title="A little treasure, earned."
        description="Five taps. A little suspense. Something lovely at the end."
        action={<Dewdrop amount={collection.balance} />}
      />
      <div className="chest-page-links">
        <Link className="text-link" href="/student/missions">
          ← Back to missions
        </Link>
        <Link className="text-link" href="/student/shop">
          Browse shop crates <ArrowUpRight size={14} />
        </Link>
      </div>
      <InlineCompanion />
      {selected ? (
        <div className="chest-opening-layout">
          <section
            className={`chest-opening-panel tier-${selected.tier}`}
            style={
              {
                "--reward-light": chestPaint[selected.tier].glow,
              } as CSSProperties
            }
          >
            <div className="chest-panel-heading">
              <Badge>
                {selected.practice ? "DEMO SAMPLE" : "EARNED THROUGH A MISSION"}
              </Badge>
              <span className={`rarity rarity-${tierRarity[selected.tier]}`}>
                {selected.tier === "void"
                  ? "mythical"
                  : tierRarity[selected.tier]}
              </span>
            </div>
            <p className="chest-origin">{selected.title}</p>
            <h2 className="chest-tier-heading">{selected.tier} chest</h2>
            <div
              className={`chest-reveal-scene ${selected.reward ? "reward-light-on" : ""}`}
            >
              <ChestEnergy
                key={`${selected.id}-${selected.taps}-${activeReveal?.phase ?? "tap"}`}
                tier={selected.tier}
                taps={selected.taps}
                phase={
                  activeReveal?.phase ??
                  (selected.reward
                    ? "rest"
                    : selected.taps > 0
                      ? "tap"
                      : "rest")
                }
              />
              <span className="chest-reveal-light" />
              {activeReveal?.phase === "open" && selected.reward && (
                <RewardEjection reward={selected.reward} pet={pet} />
              )}
              {selected.reward ? (
                <ChestArt
                  tier={selected.tier}
                  opened={activeReveal?.phase !== "charge"}
                  className={
                    activeReveal?.phase === "charge" ? "chest-final-charge" : ""
                  }
                />
              ) : (
                <button
                  className="chest-tap-target"
                  disabled={busy}
                  onClick={tap}
                  aria-label={`Tap chest · ${selected.taps} of 5 taps`}
                >
                  <ChestArt
                    key={`${selected.id}-${selected.taps}`}
                    tier={selected.tier}
                    className={
                      selected.taps > 0 ? "chest-tap-shake" : "chest-arrive"
                    }
                  />
                </button>
              )}
            </div>
            <div
              className="chest-tap-progress"
              aria-label={`${selected.taps} of 5 taps complete`}
            >
              {[1, 2, 3, 4, 5].map((n) => (
                <span key={n} className={selected.taps >= n ? "tap-done" : ""}>
                  {selected.taps >= n ? <Check size={13} /> : n}
                </span>
              ))}
            </div>
            <p className="chest-tap-status" role="status">
              {activeReveal
                ? activeReveal.phase === "open"
                  ? "Out pops your little treasure!"
                  : "A little energy, gathering…"
                : selected.reward
                  ? "Unwrapped and saved. This reward can only be granted once."
                  : selected.taps === 0
                    ? "Tap the chest to begin. Five little taps to unwrap."
                    : selected.upgradeRolls[selected.taps - 1] < 0.1 &&
                        selected.initialTier !== "void"
                      ? `A little upgrade! ${selected.tier} · ${selected.taps} of 5 taps`
                      : `A little rustle… ${selected.taps} of 5 taps`}
            </p>
            {!selected.reward && (
              <p className="chest-upgrade-hint">
                Each tap has a separate 10% chance to upgrade one tier.
                <br />
                The fifth tap can upgrade too. Void is the highest tier.
              </p>
            )}
            {selected.reward && revealReady && (
              <div className="earned-reward-result">
                <span className="eyebrow">YOUR LITTLE FIND</span>
                {selected.reward.kind === "currency" ? (
                  <div className="currency-reward">
                    <Droplets size={30} />
                    <strong>{selected.reward.amount?.toLocaleString()}</strong>
                    <span>Dewdrops</span>
                  </div>
                ) : (
                  <>
                    <LoomaPet
                      form={
                        selected.reward.kind === "looma"
                          ? (selected.reward.item as PetForm)
                          : pet.form
                      }
                      colour={
                        selected.reward.kind === "looma"
                          ? getSpecies(selected.reward.item as PetForm).colour
                          : pet.colour
                      }
                      accessory={
                        selected.reward.kind === "cosmetic"
                          ? (selected.reward.item as Accessory)
                          : "none"
                      }
                      expression="celebrating"
                    />
                    <h3>{selected.reward.label}</h3>
                    <p>
                      {selected.reward.duplicate
                        ? `Already in your collection · +${selected.reward.compensation} Dewdrops returned.`
                        : "Added to your collection."}
                    </p>
                    <button className="button button-dark" onClick={equip}>
                      Equip{" "}
                      {selected.reward.kind === "looma" ? "Looma" : "accessory"}
                      <Check size={15} />
                    </button>
                  </>
                )}
                <Link className="text-link" href="/student/missions">
                  A little more progress? <ArrowUpRight size={14} />
                </Link>
              </div>
            )}
          </section>
          <aside className="chest-explainer">
            <section>
              <p className="eyebrow">THE LITTLE RECEIPT</p>
              <h2>
                {selected.practice
                  ? "A sample for exploring."
                  : "A mission, well finished."}
              </h2>
              <div className="chest-math">
                <span>
                  Base reward<strong>{selected.base} Dewdrops</strong>
                </span>
                <span>
                  Streak multiplier<strong>{selected.multiplier}×</strong>
                </span>
                <span>
                  Reward value<strong>{selected.expected} Dewdrops</strong>
                </span>
                <span>
                  Starting tier
                  <strong className="chest-tier-label">
                    {selected.initialTier}
                  </strong>
                </span>
              </div>
              <p className="chest-fine-print">
                Your multiplier raises the starting tier and protects the
                minimum currency outcome. If you find a collectible, it replaces
                the currency reward.
              </p>
            </section>
            <section className="chest-odds">
              <div className="section-heading">
                <h2>What’s inside?</h2>
                <label>
                  <span className="sr-only">Reward odds tier</span>
                  <select
                    value={odds}
                    onChange={(e) => setOddsTier(e.target.value as ChestTier)}
                  >
                    {chestTiers.map((t) => (
                      <option key={t} value={t}>
                        {t} chest
                      </option>
                    ))}
                  </select>
                </label>
              </div>
              <p>
                Exactly one reward. Odds below apply after your fifth tap, using
                the final chest tier.
              </p>
              <p className="exclusive-chest-note">
                {selected.tableVersion === 1
                  ? "Legacy chest: its original table is preserved."
                  : `Exclusive companion: ${getSpecies(exclusiveByTier[odds]).name}. Higher tiers do not contain earlier companions.`}
              </p>
              {chestTable(selected, odds).map((r) => (
                <div key={r.label}>
                  <span>
                    {r.kind === "currency"
                      ? `${Math.max(r.amount!, selected.expected).toLocaleString()} Dewdrops`
                      : r.label}
                    {r.kind !== "currency" && (
                      <small>{r.kind === "looma" ? "Looma" : "Cosmetic"}</small>
                    )}
                  </span>
                  <strong>{r.chance}%</strong>
                </div>
              ))}
              <p className="chest-fine-print">
                Duplicate earned cosmetics return 75 Dewdrops; duplicate earned
                Loomas return 150. Rolls are saved when the chest is earned.
                Refreshing never rerolls it.
              </p>
            </section>
          </aside>
        </div>
      ) : (
        <section className="chest-empty">
          <ChestArt tier="silver" />
          <h2>A little room for your first treasure.</h2>
          <p>
            Finish a mission, collect its chest, then come back for five little
            taps.
          </p>
          <Link href="/student/missions" className="button button-dark">
            Find a mission
            <ArrowUpRight size={16} />
          </Link>
        </section>
      )}
      <section className="chest-queue">
        <div className="section-heading">
          <h2>Waiting to be unwrapped</h2>
          <span className="small-muted">{pending.length} CHESTS</span>
        </div>
        <div className="chest-queue-grid">
          {pending.map((c) => (
            <button
              key={c.id}
              className={c.id === selected?.id ? "selected" : ""}
              onClick={() => {
                setSelectedId(c.id);
                setOddsTier(null);
                setNotice("");
              }}
            >
              <ChestArt tier={c.tier} />
              <strong>{c.tier} chest</strong>
              <span>
                {c.taps}/5 taps · {c.practice ? "Demo sample" : c.day}
              </span>
            </button>
          ))}
        </div>
        {pending.length === 0 && (
          <p className="journey-muted">
            No waiting chests. Your next small start is in Missions.
          </p>
        )}
      </section>
      {opened.length > 0 && (
        <section className="chest-history">
          <div className="section-heading">
            <h2>Little treasures, kept.</h2>
            <span className="small-muted">YOUR UNWRAPPED CHESTS</span>
          </div>
          {opened.map((c) => (
            <button
              key={c.id}
              onClick={() => {
                setSelectedId(c.id);
                setOddsTier(null);
              }}
            >
              <PackageOpen size={18} />
              <div>
                <strong>{c.reward?.label}</strong>
                <small>
                  {c.tier} chest · {c.day}
                  {c.reward?.duplicate
                    ? ` · duplicate +${c.reward.compensation}`
                    : ""}
                </small>
              </div>
              <Badge>{c.practice ? "Demo" : "Earned"}</Badge>
              <ArrowUpRight size={15} />
            </button>
          ))}
        </section>
      )}
      <details className="demo-chest-cabinet">
        <summary>
          <LockKeyhole size={15} />
          Demo chest cabinet · try any tier
        </summary>
        <p>
          One free sample of each tier per demo day. These are clearly labelled
          samples, separate from mission rewards. Their drops use the same real
          probabilities; there is no guaranteed collectible.
        </p>
        <div>
          {chestTiers.map((t) => {
            const id = `practice:${journey.day}:${t}`,
              exists = journey.chests.some((c) => c.id === id);
            return (
              <button
                className="button button-outline button-small"
                key={t}
                onClick={() => {
                  if (!exists) addPracticeChest(t);
                  setSelectedId(id);
                  setOddsTier(null);
                  setNotice(
                    exists
                      ? "Reopened your saved sample. Taps and rewards stay the same."
                      : "A free demo sample was added.",
                  );
                }}
              >
                {exists ? "View" : "Try"} {t}
              </button>
            );
          })}
        </div>
        <Link className="text-link" href="/student/missions">
          Advance the demo day in Missions <ArrowUpRight size={14} />
        </Link>
      </details>
      <p className="save-status" role="status">
        {notice}
      </p>
    </>
  );
}
