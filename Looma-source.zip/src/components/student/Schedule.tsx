"use client";
import { useState } from "react";
import {
  CalendarDays,
  Shirt,
  Clock3,
  Leaf,
  MapPin,
  BookOpen,
} from "lucide-react";
import { PageHeading, Badge } from "../ui/shared";
import { facts, routines, timetable, weekdays } from "@/lib/data/mock";
export function Schedule() {
  const [day, setDay] = useState(2);
  const [tab, setTab] = useState("Timetable");
  return (
    <>
      <PageHeading
        eyebrow="A PLACE FOR EVERYTHING"
        title="The shape of your day."
        description="Classes, boarding rhythms, and the little things to know."
        action={
          <span className="day-tag">
            <CalendarDays size={17} />
            12–16 October · Demo week
          </span>
        }
      />
      <div className="schedule-tabs segmented">
        {["Timetable", "School information"].map((t) => (
          <button
            key={t}
            aria-pressed={tab === t}
            className={tab === t ? "selected" : ""}
            onClick={() => setTab(t)}
          >
            {t}
          </button>
        ))}
      </div>
      {tab === "Timetable" ? (
        <div className="schedule-layout">
          <section className="panel">
            <div className="weekday-picker" aria-label="Timetable day">
              {weekdays.map((d, i) => (
                <button
                  key={d}
                  className={day === i ? "selected" : ""}
                  onClick={() => setDay(i)}
                  aria-pressed={day === i}
                >
                  <span>{d.slice(0, 3)}</span>
                  <strong>{12 + i}</strong>
                  {i === 2 && <span className="today-marker" />}
                </button>
              ))}
            </div>
            <div className="schedule-day-heading">
              <h2>{weekdays[day]}</h2>
              <Badge tone="sage">
                {day === 2 ? "Demo today" : "Sample timetable"}
              </Badge>
            </div>
            <div className="full-timetable">
              {timetable(day).map((l, i) => (
                <div key={l.time}>
                  <article className="lesson">
                    <div className="lesson-time">
                      <strong>{l.time}</strong>
                      <small>{l.end}</small>
                    </div>
                    <div className={`lesson-details ${l.colour}`}>
                      <span className="task-subject">PERIOD {i + 1}</span>
                      <h3>{l.subject}</h3>
                      <p>
                        <MapPin size={14} />
                        {l.room}
                        <span>·</span>
                        {l.teacher}
                      </p>
                    </div>
                  </article>
                  {i === 1 && (
                    <div className="schedule-break">
                      <span>10:25</span>Morning break · A little breathing room
                    </div>
                  )}
                  {i === 3 && (
                    <div className="schedule-break">
                      <span>12:55</span>Lunch · Dining hall
                    </div>
                  )}
                </div>
              ))}
            </div>
            <div className="panel-foot">
              Source: fictional demo timetable · Updated 12 Oct 2026
            </div>
          </section>
          <aside>
            <section className="boarding-routine">
              <span className="routine-icon">
                <Clock3 size={23} />
              </span>
              <h2>Beyond the classroom.</h2>
              <p>Your sample boarding rhythm.</p>
              <div className="routine-list">
                {routines
                  .filter((r) => day === 2 || r.title !== "Hockey training")
                  .map((r) => (
                    <div key={r.time}>
                      <time>{r.time}</time>
                      <div>
                        <strong>{r.title}</strong>
                        <small>{r.place}</small>
                      </div>
                    </div>
                  ))}
              </div>
              <p className="source-note">
                Fictional demo boarding handbook
                <br />
                Updated 12 Oct 2026
              </p>
            </section>
            <section className="schedule-uniform">
              <Shirt size={25} />
              <h3>A little uniform reminder</h3>
              <p>{facts[0].content}</p>
              <Badge tone="apricot">Unverified sample guide</Badge>
            </section>
          </aside>
        </div>
      ) : (
        <div className="information-grid">
          {facts.map((fact, i) => (
            <article className="information-card" key={fact.id}>
              <span
                className={`essential-icon ${["apricot", "blue", "sage", "gold"][i]}`}
              >
                {i === 0 ? (
                  <Shirt size={25} />
                ) : i === 1 ? (
                  <Clock3 size={25} />
                ) : i === 2 ? (
                  <CalendarDays size={25} />
                ) : (
                  <Leaf size={25} />
                )}
              </span>
              <Badge>Fictional information</Badge>
              <h2>{fact.title}</h2>
              <p>{fact.content}</p>
              <div className="fact-source">
                <BookOpen size={14} />
                <span>
                  {fact.source}
                  <br />
                  Updated{" "}
                  {new Intl.DateTimeFormat("en-NZ", {
                    day: "numeric",
                    month: "short",
                    year: "numeric",
                    timeZone: "Pacific/Auckland",
                  }).format(new Date(fact.updatedAt))}
                </span>
              </div>
            </article>
          ))}
        </div>
      )}
      <div className="tip-banner">
        <Leaf size={20} />
        <p>
          These are sample routines and notices. For real school requirements,
          use current information from authorised staff.
        </p>
      </div>
    </>
  );
}
