"use client";
import { useState } from "react";
import {
  Plus,
  Check,
  Pencil,
  Trash2,
  BookOpen,
  ArrowUpRight,
} from "lucide-react";
import Link from "next/link";
import { useDemo } from "@/lib/store";
import { PageHeading, Badge, Modal, EmptyState } from "../ui/shared";
import { dueLabel, uid } from "@/lib/utils";
import { DEMO_DATE } from "@/lib/data/mock";
import type { Task } from "@/lib/types";
export const subjects = [
  "Personal",
  "English",
  "Mathematics",
  "Biology",
  "History",
  "Art",
];
export function Homework() {
  const { student, setStudent, celebrate } = useDemo();
  const [subject, setSubject] = useState("All subjects");
  const [status, setStatus] = useState("To do");
  const [editing, setEditing] = useState<Task | null>(null);
  const [open, setOpen] = useState(false);
  const [toast, setToast] = useState("");
  const filtered = student.tasks
    .filter(
      (t) =>
        (subject === "All subjects" || t.subject === subject) &&
        (status === "All" || (status === "Done" ? t.complete : !t.complete)),
    )
    .sort((a, b) => a.due.localeCompare(b.due));
  function start(task?: Task) {
    setEditing(task || null);
    setOpen(true);
  }
  function save(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const data = new FormData(e.currentTarget);
    const title = String(data.get("title")).trim();
    if (!title) return;
    const task: Task = {
      id: editing?.id || uid(),
      title,
      subject: String(data.get("subject")),
      due: String(data.get("due")),
      notes: String(data.get("notes")).trim(),
      complete: editing?.complete || false,
    };
    setStudent((s) => ({
      ...s,
      tasks: editing
        ? s.tasks.map((t) => (t.id === editing.id ? task : t))
        : [...s.tasks, task],
    }));
    setOpen(false);
    setToast(
      editing ? "Task updated in this browser." : "Task added in this browser.",
    );
  }
  return (
    <>
      <PageHeading
        eyebrow="ONE SMALL STEP AT A TIME"
        title="Make room for what’s due."
        description="Your schoolwork and little life admin, together."
        action={
          <button className="button button-dark" onClick={() => start()}>
            <Plus size={17} />
            Add a task
          </button>
        }
      />
      <div className="task-summary">
        <div>
          <span className="summary-icon blue">
            <BookOpen size={21} />
          </span>
          <div>
            <strong>{student.tasks.filter((t) => !t.complete).length}</strong>
            <span>Things to do</span>
          </div>
        </div>
        <div>
          <span className="summary-icon apricot">
            <ClockIcon />
          </span>
          <div>
            <strong>
              {
                student.tasks.filter((t) => !t.complete && t.due <= DEMO_DATE)
                  .length
              }
            </strong>
            <span>Due today or earlier</span>
          </div>
        </div>
        <div>
          <span className="summary-icon sage">
            <Check size={21} />
          </span>
          <div>
            <strong>{student.tasks.filter((t) => t.complete).length}</strong>
            <span>Already done</span>
          </div>
        </div>
      </div>
      <section className="panel task-panel">
        <div className="list-toolbar">
          <div className="segmented" aria-label="Task status">
            {["To do", "Done", "All"].map((s) => (
              <button
                key={s}
                className={status === s ? "selected" : ""}
                onClick={() => setStatus(s)}
                aria-pressed={status === s}
              >
                {s}
              </button>
            ))}
          </div>
          <label className="filter-label">
            Subject
            <select
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
            >
              <option>All subjects</option>
              {subjects.map((s) => (
                <option key={s}>{s}</option>
              ))}
            </select>
          </label>
        </div>
        <div className="task-list-header">
          <span>ASSIGNMENT / TASK</span>
          <span>DUE DATE</span>
        </div>
        {filtered.map((t) => (
          <article
            className={`homework-item ${t.complete ? "completed" : ""}`}
            key={t.id}
          >
            <button
              className={`check-button ${t.complete ? "checked" : ""}`}
              aria-label={`${t.complete ? "Reopen" : "Complete"} ${t.title}`}
              aria-pressed={t.complete}
              onClick={() => {
                if (!t.complete) celebrate("One less thing on your list.");
                setStudent((s) => ({
                  ...s,
                  tasks: s.tasks.map((x) =>
                    x.id === t.id ? { ...x, complete: !x.complete } : x,
                  ),
                }));
                setToast(
                  t.complete
                    ? "Task reopened."
                    : "A little more breathing room. Task complete.",
                );
              }}
            >
              <Check size={15} />
            </button>
            <div className="homework-item-copy">
              <span className="task-subject">{t.subject}</span>
              <h3>{t.title}</h3>
              {t.notes && <p>{t.notes}</p>}
            </div>
            <Badge
              tone={t.due <= DEMO_DATE && !t.complete ? "apricot" : "neutral"}
            >
              {dueLabel(t.due)}
            </Badge>
            <button
              className="icon-button"
              aria-label={`Edit ${t.title}`}
              onClick={() => start(t)}
            >
              <Pencil size={17} />
            </button>
          </article>
        ))}
        {filtered.length === 0 && (
          <EmptyState
            title={
              status === "Done" ? "A fresh start." : "A little breathing room."
            }
          >
            {status === "Done"
              ? "Completed tasks will appear here."
              : "No tasks match this view. Try another subject or add something new."}
          </EmptyState>
        )}
        <div className="panel-foot">
          Dates are relative to the demo day: Wednesday, 14 October.
        </div>
      </section>
      <div className="tip-banner">
        <span>✳</span>
        <p>
          <strong>Big assignment? Start small.</strong> Looma can help you find
          a manageable first step.
        </p>
        <Link href="/student/chat" className="text-link">
          Make a plan <ArrowUpRight size={17} />
        </Link>
      </div>
      <p role="status" className="save-status">
        {toast}
      </p>
      <Modal
        open={open}
        onOpenChange={setOpen}
        title={editing ? "A little adjustment." : "One thing to remember."}
        description="Saved to your task list in this browser. Nothing is sent to school."
      >
        <form onSubmit={save} className="form-stack">
          <label>
            Task name
            <input
              name="title"
              required
              maxLength={120}
              defaultValue={editing?.title}
              placeholder="What needs doing?"
              autoFocus
            />
          </label>
          <div className="form-two">
            <label>
              Subject
              <select
                name="subject"
                defaultValue={editing?.subject || "Personal"}
              >
                {subjects.map((s) => (
                  <option key={s}>{s}</option>
                ))}
              </select>
            </label>
            <label>
              Due date
              <input
                type="date"
                name="due"
                required
                min="2020-01-01"
                max="2100-12-31"
                defaultValue={editing?.due || DEMO_DATE}
              />
            </label>
          </div>
          <label>
            Notes <span className="optional">optional</span>
            <textarea
              name="notes"
              rows={3}
              maxLength={500}
              defaultValue={editing?.notes}
              placeholder="A detail that will help later…"
            />
          </label>
          <div className="dialog-actions">
            {editing && (
              <button
                type="button"
                className="button button-danger"
                onClick={() => {
                  setStudent((s) => ({
                    ...s,
                    tasks: s.tasks.filter((t) => t.id !== editing.id),
                  }));
                  setOpen(false);
                  setToast("Task deleted from this browser.");
                }}
              >
                <Trash2 size={16} />
                Delete
              </button>
            )}
            <button type="submit" className="button button-dark">
              {editing ? "Save changes" : "Add task"}
              <Check size={16} />
            </button>
          </div>
        </form>
      </Modal>
    </>
  );
}
function ClockIcon() {
  return (
    <svg
      width="21"
      height="21"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.8"
    >
      <circle cx="12" cy="12" r="9" />
      <path d="M12 7v5l3 2" />
    </svg>
  );
}
