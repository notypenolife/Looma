"use client";
import { useState } from "react";
import Link from "next/link";
import {
  Check,
  Plus,
  Pencil,
  Clock3,
  ArrowUpRight,
  Flame,
  ShieldCheck,
  Send,
  ClipboardCheck,
  CalendarDays,
  Gift,
} from "lucide-react";
import { useDemo } from "@/lib/store";
import {
  finished,
  rewardReady,
  occurrence,
  isScheduled,
  multiplier,
  streakCount,
  multipliers,
  prettyDay,
  shiftDay,
  aucklandDay,
  tierFor,
  saverPrice,
  type Mission,
  type MissionStep,
  type Submission,
} from "@/lib/journey";
import { PageHeading, Badge, Modal } from "../ui/shared";
import { InlineCompanion, ParticleBurst } from "../rewards/LocalFeedback";
import { ChestArt } from "../rewards/ChestArt";

export function Missions() {
  const {
    journey,
    collection,
    completeMissionStep,
    claimMissionChest,
    saveMission,
    submitDemo,
    requestRoom,
    buySaver,
    setJourneyDay,
    requestMissionReview,
    feedback,
  } = useDemo();
  const [filter, setFilter] = useState("today"),
    [editing, setEditing] = useState<Mission | null>(null),
    [editorOpen, setEditorOpen] = useState(false);
  const [submissionFor, setSubmissionFor] = useState<{
      mission: Mission;
      step: MissionStep;
    } | null>(null),
    [attachment, setAttachment] = useState<Submission["attachment"]>(),
    [filePreview, setFilePreview] = useState("");
  const [notice, setNotice] = useState("");
  const count = streakCount(journey),
    factor = multiplier(count),
    next = multipliers.find((m) => m.factor > factor);
  const todayMissions = journey.missions.filter(
    (m) => isScheduled(m, journey.day) && m.kind === "reward",
  );
  const completed = todayMissions.filter((m) => rewardReady(journey, m)).length;
  const list = journey.missions.filter((m) =>
    filter === "today"
      ? isScheduled(m, journey.day)
      : filter === "upcoming"
        ? m.date > journey.day
        : true,
  );
  function openEditor(mission: Mission | null) {
    setEditing(mission);
    setEditorOpen(true);
  }
  function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!submissionFor) return;
    const data = new FormData(e.currentTarget);
    submitDemo({
      id: crypto.randomUUID(),
      occurrence: occurrence(submissionFor.mission, journey.day),
      stepId: submissionFor.step.id,
      day: journey.day,
      title: String(data.get("title")).trim(),
      subject: String(data.get("subject")).trim(),
      teacher: String(data.get("teacher")),
      summary: String(data.get("summary")).trim(),
      attachment,
      status: "submitted",
      staffNote: "",
    });
    setSubmissionFor(null);
    setNotice(
      "Demo submission — nothing was sent. Your sample receipt is below.",
    );
  }
  return (
    <>
      <PageHeading
        eyebrow="A LITTLE INTENTION, EVERY DAY"
        title="Small plans. Lovely progress."
        description="Make room for study, movement and the little things in between."
        action={
          <button
            className="button button-dark"
            onClick={() => openEditor(null)}
          >
            <Plus size={17} />
            New personal goal
          </button>
        }
      />
      <div className="mission-daybar">
        <span>
          <CalendarDays size={17} />
          {prettyDay(journey.day)}
          <Badge>
            {journey.clock === "demo" ? "Demo clock" : "Auckland time"}
          </Badge>
        </span>
        <div>
          <button
            onClick={() => {
              setJourneyDay(shiftDay(journey.day, 1));
              setNotice(
                "Moved forward one demo day. Missed days are settled once; savers are used automatically.",
              );
            }}
          >
            Next demo day →
          </button>
          {journey.clock === "demo" && (
            <button
              onClick={() => setJourneyDay(aucklandDay(new Date()), "live")}
            >
              Return to Auckland today
            </button>
          )}
        </div>
      </div>
      <p className="demo-acceptance-note">
        Demo auto-approval is on. Hand-ins and room-ready checks are simulated
        instantly; nothing is sent. Real rewards will require verified staff
        authorisation.
      </p>
      <InlineCompanion />
      <section className="mission-hero">
        <div className="mission-hero-copy">
          <Badge tone="sage">THE EVERYDAY QUEST</Badge>
          <h2>
            A little effort.
            <br />A box of possibilities.
          </h2>
          <p>
            Complete a staff-set mission to receive its chest instantly in this
            demo. Your own goals are yours to plan, with no currency attached.
          </p>
          <div className="mission-progress-label">
            <strong>
              {completed} / {todayMissions.length} missions finished
            </strong>
            <span>
              {journey.qualifiedDays.includes(journey.day)
                ? "Today is qualified ✓"
                : "One approved reward mission qualifies today"}
            </span>
          </div>
          <div className="mission-progress-track">
            <span
              style={{
                width: `${todayMissions.length ? (completed / todayMissions.length) * 100 : 0}%`,
              }}
            />
          </div>
        </div>
        <Link href="/student/chests" className="mission-hero-chest">
          <ChestArt tier="silver" />
          <span>
            Your earned chests <ArrowUpRight size={15} />
          </span>
        </Link>
      </section>
      <section className="streak-strip" aria-label="Daily streak">
        <div>
          <span className="streak-symbol">
            <Flame size={23} />
          </span>
          <div>
            <strong>
              {count} <small>day{count === 1 ? "" : "s"} of progress</small>
            </strong>
            <p>
              {journey.qualifiedDays.includes(journey.day)
                ? "A little victory recorded today."
                : "Your next small start is welcome here."}
            </p>
          </div>
        </div>
        <div>
          <strong>
            {factor}× <small>Dewdrop multiplier</small>
          </strong>
          <p>
            {next
              ? `${Math.max(0, next.days - count)} more qualifying days to ${next.factor}×`
              : "Your full 2× multiplier is unlocked."}
          </p>
          <div className="streak-milestones">
            {multipliers.map((m) => (
              <span
                key={m.days}
                className={count >= m.days ? "milestone-active" : ""}
              >
                {m.days}d · {m.factor}×
              </span>
            ))}
          </div>
        </div>
        <div>
          <span className="streak-symbol saver-symbol">
            <ShieldCheck size={22} />
          </span>
          <div>
            <strong>
              {journey.savers} <small>streak savers</small>
            </strong>
            <button
              className="text-link"
              disabled={collection.balance < saverPrice || journey.savers >= 99}
              onClick={() => {
                buySaver();
                setNotice(
                  "Streak saver added. It automatically protects one missed day after a streak starts.",
                );
              }}
            >
              Buy saver · {saverPrice} Dewdrops
            </button>
            {collection.balance < saverPrice && (
              <p>More Dewdrops are available in the shop.</p>
            )}
          </div>
        </div>
      </section>
      <details className="journey-details">
        <summary>How streaks and rewards work</summary>
        <p>
          Finish every step in a staff-set reward mission and receive approval
          to qualify the day. Personal goals do not award currency, chests or
          streak credit. Days use Pacific/Auckland time. A saver is
          automatically consumed once when a missed day closes, only if you
          already have a streak. Protected days preserve your streak without
          increasing it. No saver? Your next completed day simply starts a fresh
          streak.
        </p>
        <p>
          Mission rewards become chests, not instant currency. Your base reward
          × streak multiplier determines the starting chest tier and minimum
          currency outcome. A chest contains one currency reward or one item.
          Collectibles replace the currency outcome. Nothing costs real money.
        </p>
        <p>
          Demo controls change only the mission clock. Moving back to today
          preserves your reward and protection history; it never resets claims.
        </p>
      </details>
      <div className="mission-section-bar">
        <div className="collection-tabs" role="group" aria-label="Mission view">
          {["today", "upcoming", "all"].map((f) => (
            <button
              key={f}
              aria-pressed={filter === f}
              onClick={() => setFilter(f)}
            >
              {f === "today"
                ? "Today’s missions"
                : f === "upcoming"
                  ? "Upcoming"
                  : "All missions"}
            </button>
          ))}
        </div>
        <Link className="text-link" href="/student/chests">
          <Gift size={16} />
          {journey.chests.filter((c) => c.taps < 5).length} waiting chests
        </Link>
      </div>
      <div className="mission-list">
        {list.map((m) => {
          const key = occurrence(m, journey.day),
            done = journey.completedSteps[key] ?? [],
            ready = rewardReady(journey, m),
            stepsFinished = finished(journey, m),
            approval = journey.approvals?.[key],
            chest = journey.chests.find((c) => c.occurrence === key),
            amount = Math.round(m.reward * factor),
            tier = tierFor(amount),
            scheduled = isScheduled(m, journey.day);
          return (
            <article
              className={`mission-card ${stepsFinished ? "mission-finished" : ""}`}
              key={m.id}
            >
              {feedback?.target === m.id && <ParticleBurst key={feedback.id} />}
              <div className="mission-time">
                <Clock3 size={17} />
                <strong>{m.time}</strong>
                <span>{m.minutes} min</span>
              </div>
              <div className="mission-card-body">
                <div className="mission-card-top">
                  <div>
                    <span className="mission-category">
                      {m.kind === "reward"
                        ? `Staff-set · ${m.authorisedBy}`
                        : "Personal goal · no currency"}
                      <br />
                      {m.category} ·{" "}
                      {m.repeat ? "Daily demo routine" : prettyDay(m.date)}
                    </span>
                    <h2>{m.title}</h2>
                  </div>
                  <button
                    className="icon-button"
                    aria-label={`Edit mission ${m.title}`}
                    disabled={m.kind === "reward" || done.length > 0 || !!chest}
                    onClick={() => openEditor(m)}
                  >
                    <Pencil size={16} />
                  </button>
                </div>
                <div className="mission-steps">
                  {m.steps.map((step) => {
                    const stepDone = done.includes(step.id),
                      room = journey.rooms.find(
                        (r) => r.occurrence === key && r.stepId === step.id,
                      ),
                      submission = journey.submissions.find(
                        (s) => s.occurrence === key && s.stepId === step.id,
                      );
                    return (
                      <div
                        className={`mission-step ${stepDone ? "step-complete" : ""}`}
                        key={step.id}
                      >
                        <span className="mission-step-check">
                          {stepDone ? (
                            <Check size={14} />
                          ) : step.kind === "submission" ? (
                            <Send size={13} />
                          ) : step.kind === "room" ? (
                            <ClipboardCheck size={14} />
                          ) : (
                            <span />
                          )}
                        </span>
                        <div>
                          <strong>{step.title}</strong>
                          {room && (
                            <small>
                              {room.status === "ready"
                                ? "Ready for staff review"
                                : room.status === "passed"
                                  ? "Passed by fictional staff"
                                  : `Follow-up: ${room.note}`}
                            </small>
                          )}
                          {submission && (
                            <small>
                              Demo submission ·{" "}
                              {submission.status.replace("-", " ")}
                              {submission.staffNote
                                ? ` · ${submission.staffNote}`
                                : ""}
                            </small>
                          )}
                        </div>
                        {!stepDone &&
                          scheduled &&
                          (step.kind === "check" ? (
                            <button
                              onClick={() => completeMissionStep(m.id, step.id)}
                              className="step-button"
                              aria-label={`Complete ${step.title}`}
                            >
                              Mark done
                            </button>
                          ) : step.kind === "submission" ? (
                            <button
                              className="step-button"
                              onClick={() => {
                                setSubmissionFor({ mission: m, step });
                                setAttachment(undefined);
                                setFilePreview("");
                              }}
                            >
                              Hand in demo
                            </button>
                          ) : (
                            <button
                              className="step-button"
                              disabled={room?.status === "ready"}
                              onClick={() => {
                                requestRoom(m.id, step.id);
                                setNotice(
                                  "Room 101 marked ready. Demo auto-approved; your chest is ready.",
                                );
                              }}
                            >
                              {room?.status === "ready"
                                ? "Awaiting review"
                                : room?.status === "follow-up"
                                  ? "Ready again"
                                  : "Room is ready"}
                            </button>
                          ))}
                      </div>
                    );
                  })}
                </div>
                <div className="mission-card-footer">
                  {m.kind !== "reward" ? (
                    <>
                      <span>Personal goal · no currency or chest reward</span>
                      {stepsFinished && (
                        <Badge tone="sage">A little goal, finished ✓</Badge>
                      )}
                    </>
                  ) : (
                    <>
                      <span>
                        <Gift size={15} />
                        {chest
                          ? `${chest.base} × ${chest.multiplier} = ${chest.expected}`
                          : `${m.reward} × ${factor} = ${amount}`}{" "}
                        Dewdrops →{" "}
                        <strong className="chest-tier-label">
                          {chest?.initialTier ?? tier} chest
                        </strong>
                      </span>
                      {chest ? (
                        <Link
                          className="text-link"
                          href={`/student/chests?chest=${encodeURIComponent(chest.id)}`}
                        >
                          {chest.taps === 5 ? "View reward" : "Open chest"}
                          <ArrowUpRight size={14} />
                        </Link>
                      ) : ready ? (
                        <button
                          className="button button-dark button-small"
                          onClick={() => claimMissionChest(m.id)}
                        >
                          Collect {tier} chest
                        </button>
                      ) : stepsFinished ? (
                        <button
                          className="button button-outline button-small"
                          disabled={false}
                          onClick={() => requestMissionReview(m.id)}
                        >
                          {approval?.status === "pending"
                            ? "Accept demo completion"
                            : approval?.status === "follow-up"
                              ? "Accept demo completion"
                              : "Accept demo completion"}
                        </button>
                      ) : (
                        <Badge>Demo auto-acceptance</Badge>
                      )}
                      {approval?.note && (
                        <p className="mission-approval-note">
                          {approval.status}: {approval.note}
                        </p>
                      )}
                    </>
                  )}
                </div>
              </div>
            </article>
          );
        })}
        {list.length === 0 && (
          <div className="journey-empty">
            <CalendarDays size={28} />
            <h2>A little room in your day.</h2>
            <p>Add a mission, or switch back to today’s plans.</p>
            <button
              className="button button-outline"
              onClick={() => openEditor(null)}
            >
              Create a personal goal
            </button>
          </div>
        )}
      </div>
      {journey.submissions.length > 0 && (
        <section className="submission-receipts">
          <div className="section-heading">
            <h2>Your hand-in receipts</h2>
            <Link href="/staff/submissions" className="text-link">
              Explore fictional teacher review <ArrowUpRight size={14} />
            </Link>
          </div>
          {journey.submissions.slice(0, 6).map((s) => (
            <article key={s.id}>
              <Send size={18} />
              <div>
                <h3>{s.title}</h3>
                <p>
                  {s.subject} · {s.teacher} · {s.day}
                  {s.attachment ? ` · ${s.attachment.name}` : ""}
                </p>
                <small>Demo submission — nothing was sent.</small>
                {s.staffNote && <p>Fictional teacher note: {s.staffNote}</p>}
              </div>
              <Badge>{s.status.replace("-", " ")}</Badge>
            </article>
          ))}
        </section>
      )}
      <p className="save-status" role="status">
        {notice}
      </p>
      <MissionEditor
        key={editing?.id ?? `new-${editorOpen}`}
        open={editorOpen}
        onOpenChange={setEditorOpen}
        mission={editing}
        day={journey.day}
        onSave={(mission) => {
          saveMission(mission);
          setEditorOpen(false);
          setNotice("Personal goal saved. No reward amount is assigned.");
        }}
      />
      <Modal
        open={!!submissionFor}
        onOpenChange={(open) => {
          if (!open) setSubmissionFor(null);
        }}
        title="A little work, handed in."
        description="Demo submission — nothing was sent. Use fictional information. Only a sample receipt and attachment metadata are saved."
      >
        <form className="form-stack" onSubmit={submit}>
          <label>
            Assignment title
            <input
              required
              name="title"
              maxLength={100}
              defaultValue="Social Studies · Harbour Bay communities"
            />
          </label>
          <div className="mission-form-pair">
            <label>
              Subject
              <input
                required
                name="subject"
                maxLength={60}
                defaultValue="Social Studies"
              />
            </label>
            <label>
              Fictional teacher
              <select name="teacher">
                <option>Ms Wren · Demo teacher</option>
                <option>Mr Alder · Demo teacher</option>
                <option>Dr Finch · Demo teacher</option>
              </select>
            </label>
          </div>
          <label>
            Attachment preview{" "}
            <span className="optional">optional · local only</span>
            <input
              type="file"
              accept=".txt,.pdf,.png,.jpg,.jpeg"
              onChange={async (e) => {
                const file = e.target.files?.[0];
                if (!file) {
                  setAttachment(undefined);
                  setFilePreview("");
                  return;
                }
                setAttachment({
                  name: file.name,
                  size: file.size,
                  type: file.type,
                });
                setFilePreview(
                  file.type === "text/plain"
                    ? await file.slice(0, 2000).text()
                    : `${file.name} · ${Math.ceil(file.size / 1024)} KB · metadata preview only`,
                );
              }}
            />
          </label>
          {filePreview && (
            <pre className="attachment-preview">{filePreview}</pre>
          )}
          <label>
            Short summary <span className="optional">optional</span>
            <textarea
              name="summary"
              rows={3}
              maxLength={500}
              placeholder="A fictional summary of your work…"
            />
          </label>
          <button type="submit" className="button button-dark">
            <Send size={16} />
            Hand in demo assignment
          </button>
        </form>
      </Modal>
    </>
  );
}
function MissionEditor({
  open,
  onOpenChange,
  mission,
  day,
  onSave,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  mission: Mission | null;
  day: string;
  onSave: (m: Mission) => void;
}) {
  const [steps, setSteps] = useState<MissionStep[]>(
    mission?.steps ?? [{ id: "step-1", title: "", kind: "check" }],
  );
  function save(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const data = new FormData(e.currentTarget);
    onSave({
      id: mission?.id ?? crypto.randomUUID(),
      title: String(data.get("title")).trim(),
      category: String(data.get("category")) as Mission["category"],
      date: String(data.get("date")),
      time: String(data.get("time")),
      minutes: Number(data.get("minutes")),
      repeat: data.get("repeat") === "on",
      reward: 0,
      kind: "goal",
      steps: steps.map((s) => ({ ...s, title: s.title.trim() })),
    });
  }
  return (
    <Modal
      open={open}
      onOpenChange={onOpenChange}
      title={
        mission ? "A little change of plan." : "A small plan to start with."
      }
      description="Personal goals are for your own plans. They have no currency or chest reward. Reward missions are set and reviewed in the fictional staff demo."
    >
      <form className="form-stack" onSubmit={save}>
        <label>
          Goal name
          <input
            required
            name="title"
            maxLength={100}
            defaultValue={mission?.title}
            placeholder="Move a little, make a little progress"
          />
        </label>
        <div className="mission-form-pair">
          <label>
            Category
            <select name="category" defaultValue={mission?.category ?? "Study"}>
              {["Study", "Activity", "Boarding", "Mixed"].map((c) => (
                <option key={c}>{c}</option>
              ))}
            </select>
          </label>
        </div>
        <div className="mission-form-pair">
          <label>
            Scheduled date
            <input
              type="date"
              name="date"
              required
              min={mission?.repeat ? mission.date : day}
              defaultValue={mission?.date ?? day}
            />
          </label>
          <label>
            Start time
            <input
              type="time"
              name="time"
              required
              defaultValue={mission?.time ?? "16:30"}
            />
          </label>
        </div>
        <label>
          Duration in minutes
          <input
            name="minutes"
            type="number"
            required
            min={5}
            max={480}
            defaultValue={mission?.minutes ?? 30}
          />
        </label>
        <label className="mission-repeat">
          <input
            name="repeat"
            type="checkbox"
            defaultChecked={mission?.repeat ?? false}
          />
          Repeat this demo routine daily
        </label>
        <fieldset className="mission-editor-steps">
          <legend>Steps to complete</legend>
          {steps.map((step, i) => (
            <div key={step.id}>
              <label>
                <span className="sr-only">Step {i + 1} title</span>
                <input
                  required
                  maxLength={120}
                  placeholder={`Step ${i + 1}`}
                  value={step.title}
                  onChange={(e) =>
                    setSteps((s) =>
                      s.map((x) =>
                        x.id === step.id ? { ...x, title: e.target.value } : x,
                      ),
                    )
                  }
                />
              </label>
              <label>
                <span className="sr-only">Step {i + 1} type</span>
                <select
                  value={step.kind}
                  onChange={(e) =>
                    setSteps((s) =>
                      s.map((x) =>
                        x.id === step.id
                          ? {
                              ...x,
                              kind: e.target.value as MissionStep["kind"],
                            }
                          : x,
                      ),
                    )
                  }
                >
                  <option value="check">Self-check</option>
                  <option value="submission">Demo hand-in</option>
                  <option value="room">Room review</option>
                </select>
              </label>
              {steps.length > 1 && (
                <button
                  type="button"
                  aria-label={`Remove step ${i + 1}`}
                  onClick={() =>
                    setSteps((s) => s.filter((x) => x.id !== step.id))
                  }
                >
                  ×
                </button>
              )}
            </div>
          ))}
        </fieldset>
        <button
          type="button"
          className="text-link"
          disabled={steps.length >= 8}
          onClick={() =>
            setSteps((s) => [
              ...s,
              { id: crypto.randomUUID(), title: "", kind: "check" },
            ])
          }
        >
          <Plus size={15} />
          Add another step
        </button>
        <button type="submit" className="button button-dark">
          Save mission
          <Check size={16} />
        </button>
      </form>
    </Modal>
  );
}
