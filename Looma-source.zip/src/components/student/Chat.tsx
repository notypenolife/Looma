"use client";
import { useState, useRef, useEffect } from "react";
import {
  ArrowUp,
  BookOpen,
  CalendarDays,
  Shirt,
  Leaf,
  Trash2,
  LockKeyhole,
  ArrowUpRight,
} from "lucide-react";
import Link from "next/link";
import { useDemo } from "@/lib/store";
import { getSpecies } from "@/lib/collection";
import { personalityReaction } from "@/lib/personality";
import { UhOh } from "../ui/UhOh";
import { demoReply } from "@/lib/chat";
import { LoomaPet } from "../pets/LoomaPet";
import { Badge, PageHeading } from "../ui/shared";
interface Message {
  id: number;
  role: "assistant" | "user";
  text: string;
  time: string;
}
const prompts = [
  "What’s happening today?",
  "What uniform do I wear?",
  "Do I have any homework due?",
  "What do I need to do tonight?",
  "Can you help me organise my assignments?",
  "Do you remember what sport I like?",
];
function time() {
  return new Intl.DateTimeFormat("en-NZ", {
    hour: "numeric",
    minute: "2-digit",
    timeZone: "Pacific/Auckland",
  }).format(new Date());
}
export function Chat() {
  const { pet, student } = useDemo();
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 0,
      role: "assistant",
      text: "Morning, Alex. Want to get a feel for today, or untangle something on your list? We can take it one thing at a time.",
      time: "8:00 am",
    },
  ]);
  const [failed, setFailed] = useState(false);
  const personality = getSpecies(pet.form);
  const [input, setInput] = useState("");
  const [thinking, setThinking] = useState(false);
  const bottom = useRef<HTMLDivElement>(null);
  const timeout = useRef<ReturnType<typeof setTimeout> | null>(null);
  const lock = useRef(false);
  useEffect(() => {
    bottom.current?.scrollIntoView({ behavior: "instant", block: "nearest" });
  }, [messages, thinking]);
  useEffect(
    () => () => {
      if (timeout.current) clearTimeout(timeout.current);
    },
    [],
  );
  function send(text: string) {
    if (!text.trim() || lock.current) return;
    lock.current = true;
    setMessages((m) => [
      ...m,
      {
        id: Date.now(),
        role: "user",
        text: text.trim().slice(0, 1000),
        time: time(),
      },
    ]);
    setInput("");
    setThinking(true);
    timeout.current = setTimeout(() => {
      try {
        const reply = demoReply(text, student, pet);
        setMessages((m) => [
          ...m,
          {
            id: Date.now() + 1,
            role: "assistant",
            text: reply,
            time: time(),
          },
        ]);
      } catch {
        setFailed(true);
      } finally {
        setThinking(false);
        lock.current = false;
      }
    }, 900);
  }
  if (failed) return <UhOh retry={() => setFailed(false)} />;
  return (
    <>
      <PageHeading
        eyebrow="A LITTLE SPACE TO THINK"
        title={`Talk to ${pet.name}.`}
        description="A clearer plan, a quick question, or a small start."
      />
      <div className="chat-layout">
        <section className="chat-panel">
          <header className="chat-header">
            <span className="chat-pet-avatar">
              <LoomaPet
                {...pet}
                expression={thinking ? "thinking" : "happy"}
                animate={false}
              />
            </span>
            <div>
              <strong>{pet.name}</strong>
              <small>
                <span className="online-dot" />
                {personality.personality} · Simulated chat
              </small>
            </div>
            <button
              className="icon-button"
              disabled={thinking || messages.length < 2}
              aria-label="Clear conversation"
              onClick={() => setMessages((m) => m.slice(0, 1))}
            >
              <Trash2 size={17} />
            </button>
          </header>
          <div
            className="chat-scroll"
            role="log"
            aria-label="Conversation"
            aria-live="polite"
          >
            <div className="chat-date">YOUR DEMO WEDNESDAY</div>
            {messages.map((m) => (
              <article key={m.id} className={`message message-${m.role}`}>
                {m.role === "assistant" && (
                  <span className="message-avatar">
                    <Leaf size={16} />
                  </span>
                )}
                <div>
                  <div className="message-bubble">
                    {m.id === 0
                      ? `${personalityReaction(pet.form, "hello", 12).line} Want to look at your day, or untangle something on your list?`
                      : m.text}
                  </div>
                  <span className="message-time">
                    {m.role === "assistant" ? pet.name : "You"} · {m.time}
                  </span>
                </div>
              </article>
            ))}
            {thinking && (
              <div className="message message-assistant">
                <span className="message-avatar">
                  <Leaf size={16} />
                </span>
                <div
                  className="thinking-bubble"
                  role="status"
                  aria-label={`${pet.name} is thinking`}
                >
                  <span />
                  <span />
                  <span />
                  <small>Finding a little clarity…</small>
                </div>
              </div>
            )}
            <div ref={bottom} />
          </div>
          <div className="chat-composer">
            <div className="quick-prompts">
              {prompts.slice(0, 3).map((p) => (
                <button key={p} disabled={thinking} onClick={() => send(p)}>
                  {p}
                </button>
              ))}
            </div>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                send(input);
              }}
            >
              <label className="sr-only" htmlFor="chat-message">
                Message {pet.name}
              </label>
              <textarea
                id="chat-message"
                rows={1}
                maxLength={1000}
                placeholder={`Ask ${pet.name} something…`}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && !e.shiftKey) {
                    e.preventDefault();
                    send(input);
                  }
                }}
              />
              <button
                className="send-button"
                type="submit"
                disabled={thinking || !input.trim()}
                aria-label="Send message"
              >
                <ArrowUp size={20} />
              </button>
            </form>
            <p>
              <LockKeyhole size={12} />
              This conversation stays in this tab. No automatic memories.
            </p>
          </div>
        </section>
        <aside className="chat-context">
          <div className="chat-context-pet">
            <LoomaPet {...pet} expression={thinking ? "thinking" : "curious"} />
            <p>
              <strong>
                {personality.name} · {personality.element}
              </strong>
              <br />
              <em>
                {
                  personalityReaction(
                    pet.form,
                    thinking ? "focus" : "hello",
                    12,
                  ).line
                }
              </em>
            </p>
          </div>
          <section className="context-panel">
            <h2>A little context</h2>
            <Link href="/student/schedule">
              <CalendarDays size={18} />
              <span>Wednesday’s timetable</span>
              <ArrowUpRight size={14} />
            </Link>
            <Link href="/student/homework">
              <BookOpen size={18} />
              <span>
                {student.tasks.filter((t) => !t.complete).length} open tasks
              </span>
              <ArrowUpRight size={14} />
            </Link>
            <Link href="/student/schedule">
              <Shirt size={18} />
              <span>Summer uniform guide</span>
              <ArrowUpRight size={14} />
            </Link>
          </section>
          <section className="context-prompts">
            <h2>Something to ask</h2>
            {prompts.slice(3).map((p) => (
              <button key={p} disabled={thinking} onClick={() => send(p)}>
                {p}
                <ArrowUpRight size={14} />
              </button>
            ))}
          </section>
          <div className="chat-disclosure">
            <Badge tone="sage">Demo mode</Badge>
            <p>
              Replies use sample information, not live AI. School details are
              fictional and should be checked with staff.
            </p>
          </div>
        </aside>
      </div>
    </>
  );
}
