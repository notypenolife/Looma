"use client";
import { presence } from "@/lib/embodiment";
import { useState, useMemo } from "react";
import { species, legacyPip, cosmetics, getSpecies } from "@/lib/collection";
import {
  characterSheets,
  performances,
  type Performance,
  type BehaviourCategory,
} from "@/lib/behaviours";
import type { Accessory, PetForm } from "@/lib/types";
import { LoomaPet } from "../pets/LoomaPet";
import { PageHeading, Badge } from "../ui/shared";
export function CharacterStudio() {
  const [form, setForm] = useState<PetForm>("shadow"),
    [accessory, setAccessory] = useState<Accessory>("none"),
    [category, setCategory] = useState<BehaviourCategory>("entrance"),
    [selected, setSelected] = useState<string | null>(null),
    [take, setTake] = useState(0),
    [auto, setAuto] = useState(false);
  const [live, setLive] = useState<Performance | null>(null);
  const all = useMemo(() => performances(form), [form]);
  const s = getSpecies(form),
    sheet = characterSheets[form],
    action =
      all.find((p) => p.id === selected) ??
      all.find((p) => p.category === category)!;
  return (
    <>
      <PageHeading
        eyebrow="DEMO AUDITION ROOM · NO ITEMS ARE UNLOCKED HERE"
        title="Little characters. Their own ways."
        description="Meet the personalities, audition every routine and check how accessories wrap each silhouette."
      />
      <div className="studio-layout">
        <section className="studio-stage">
          <Badge>
            {auto
              ? "Autonomous · visibility & cooldowns active"
              : action.category}
          </Badge>
          <LoomaPet
            key={`${form}-${take}-${auto}`}
            form={form}
            colour={s.colour}
            accessory={accessory}
            performance={auto ? undefined : action}
            onPerformance={setLive}
          />
          <h2>{s.name}</h2>
          <p>
            {auto ? (live?.line ?? presence[form].hello) : `“${action.line}”`}
          </p>
          <small>
            {auto
              ? "Entrances vary; idle moments appear after a quiet pause. Switch tabs to pause."
              : action.label}
          </small>
          <dl className="character-note">
            <dt>Temperament</dt>
            <dd>{sheet.temperament}</dd>
            <dt>Voice</dt>
            <dd>{sheet.voice}</dd>
            <dt>Signature phrase</dt>
            <dd>{sheet.phrase}</dd>
          </dl>
        </section>
        <section className="studio-controls">
          <label htmlFor="studio-character">
            Character
            <select
              id="studio-character"
              aria-label="Character"
              value={form}
              onChange={(e) => {
                setForm(e.target.value as PetForm);
                setSelected(null);
                setTake((n) => n + 1);
              }}
            >
              {[...species, legacyPip].map((s) => (
                <option value={s.id} key={s.id}>
                  {s.name} · {s.element}
                </option>
              ))}
            </select>
          </label>
          <label>
            Accessory fit
            <select
              value={accessory}
              onChange={(e) => setAccessory(e.target.value as Accessory)}
            >
              <option value="none">No accessory</option>
              {cosmetics.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </label>
          <label>
            Behaviour category
            <select
              value={category}
              onChange={(e) => {
                setCategory(e.target.value as BehaviourCategory);
                setSelected(null);
                setAuto(false);
              }}
            >
              {["entrance", "idle", "achievement", "surprise", "focus"].map(
                (c) => (
                  <option key={c}>{c}</option>
                ),
              )}
            </select>
          </label>
          <div className="studio-mode">
            <button
              className="button button-outline button-small"
              aria-pressed={auto}
              onClick={() => {
                setAuto(!auto);
                setTake((n) => n + 1);
              }}
            >
              {auto ? "Use audition poses" : "Run autonomous behaviours"}
            </button>
            <button className="text-link" onClick={() => setTake((n) => n + 1)}>
              Replay this take →
            </button>
          </div>
          <div className="studio-poses">
            {all
              .filter((p) => p.category === category)
              .map((p) => (
                <button
                  key={p.id}
                  aria-pressed={!auto && p.id === action.id}
                  onClick={() => {
                    setSelected(p.id);
                    setAuto(false);
                    setTake((n) => n + 1);
                  }}
                >
                  {p.label}
                  <small>
                    {p.motion} ·{" "}
                    {p.prop === "none" ? "body & expression" : p.prop} ·{" "}
                    {(p.duration / 1000).toFixed(1)}s
                  </small>
                </button>
              ))}
          </div>
          <p className="journey-muted">
            Each character has 3 entrances, 6 idle activities, 3 achievement
            reactions, 2 surprises and 2 focus/rest routines. Weighted selection
            avoids immediate repeats and gives each action a cooldown.
          </p>
        </section>
      </div>
      <section className="fit-board">
        <div className="section-heading">
          <h2>One accessory, every silhouette.</h2>
          <span className="small-muted">
            STATIC FIT BOARD · ALL COSMETICS ARE SVG
          </span>
        </div>
        <p className="journey-muted">
          Choose an accessory above to inspect its authored head, shoulder and
          body fit. This preview never changes ownership or your active Looma.
        </p>
        <div className="fit-board-grid">
          {[...species, legacyPip].map((s) => (
            <article key={s.id} data-fit-character={s.id}>
              <LoomaPet
                form={s.id}
                colour={s.colour}
                accessory={accessory}
                animate={false}
              />
              <strong>{s.name}</strong>
            </article>
          ))}
        </div>
      </section>
    </>
  );
}
