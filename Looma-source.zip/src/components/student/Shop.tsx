"use client";
import { useEffect, useRef, useState } from "react";
import {
  ArrowUpRight,
  Check,
  Droplets,
  Gift,
  PackageOpen,
  Plus,
  LockKeyhole,
} from "lucide-react";
import Link from "next/link";
import { useDemo } from "@/lib/store";
import {
  cosmetics,
  species,
  oddsForCrate,
  crateItems,
  isLoomaCrate,
  sourceLabel,
  cratePrices,
  getSpecies,
  type CrateKind,
} from "@/lib/collection";
import { saverPrice } from "@/lib/journey";
import type { Accessory, PetForm } from "@/lib/types";
import { LoomaPet } from "../pets/LoomaPet";
import { Badge, Modal, PageHeading } from "../ui/shared";

export function Dewdrop({ amount }: { amount: number }) {
  return (
    <span className="dew-balance">
      <Droplets size={17} aria-hidden="true" />
      <strong>{amount.toLocaleString()}</strong>
      <span>Dewdrops</span>
    </span>
  );
}
export function CrateArt({
  kind,
  opening = false,
}: {
  kind: CrateKind;
  opening?: boolean;
}) {
  const looma = isLoomaCrate(kind);
  const seasonal = kind.startsWith("halloween");
  return (
    <svg
      viewBox="0 0 260 190"
      className={`crate-art ${opening ? "crate-opening" : ""}`}
      role="img"
      aria-label={
        seasonal
          ? "Halloween shop crate"
          : looma
            ? "Sage green Looma crate"
            : "Apricot cosmetic crate"
      }
    >
      <ellipse cx="130" cy="170" rx="77" ry="9" fill="#26342D" opacity=".06" />
      <g stroke="#526052" strokeWidth="2" strokeLinejoin="round">
        <path
          d="M54 76L130 99L207 75L207 145L132 171L54 145Z"
          fill={seasonal ? "#D5B8CE" : looma ? "#BFD5C0" : "#EAC6AA"}
        />
        <path
          d="M132 99V171L207 145V75Z"
          fill={seasonal ? "#AD8BAE" : looma ? "#A8C1AD" : "#DDB597"}
        />
        <g className="crate-lid">
          <path
            d="M48 64L126 40L212 63L134 90Z"
            fill={seasonal ? "#E9D3DE" : looma ? "#DCE9D6" : "#F5DFCC"}
          />
          <path
            d="M48 64V80L134 108L212 80V63L134 90Z"
            fill={looma ? "#C5D8BD" : "#ECCDB3"}
          />
          <path d="M112 45L195 69L181 74L98 49Z" fill="#FAF5E8" />
          <path d="M181 74V90L195 85V69" fill="#E9E4D4" />
        </g>
        <path d="M82 105L111 114V145L82 136Z" fill="#FAF7ED" stroke="none" />
        {looma ? (
          <path
            d="M96 132Q77 112 97 116Q111 105 101 128M96 122L98 137"
            fill="#87AE8C"
          />
        ) : (
          <path
            d="M96 116L99 122L106 125L101 129L101 136L95 132L89 132L91 125L89 119Z"
            fill="#DDA671"
            stroke="none"
          />
        )}
        <path d="M155 121L186 111M155 128L174 122" fill="none" opacity=".4" />
      </g>
    </svg>
  );
}
export function Shop() {
  const {
    collection,
    setCollection,
    openCrate,
    pet,
    setPet,
    journey,
    buySaver,
  } = useDemo();
  const [tab, setTab] = useState<CrateKind>("looma");
  const [odds, setOdds] = useState<CrateKind | null>(null);
  const [revealId, setRevealId] = useState<string | null>(null);
  const [ready, setReady] = useState(false);
  const [notice, setNotice] = useState("");
  const [preview, setPreview] = useState<string | null>(null);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const opening = useRef(false);
  useEffect(
    () => () => {
      if (timer.current) clearTimeout(timer.current);
    },
    [],
  );
  const result = collection.history.find((h) => h.id === revealId);
  const resultSpecies =
    result && isLoomaCrate(result.kind)
      ? getSpecies(result.item as PetForm)
      : null;
  const resultCosmetic =
    result && !isLoomaCrate(result.kind)
      ? cosmetics.find((c) => c.id === result.item)
      : null;
  function buy(kind: CrateKind) {
    if (opening.current || collection.balance < cratePrices[kind]) return;
    opening.current = true;
    const id = crypto.randomUUID();
    openCrate(kind, id);
    setRevealId(id);
    setReady(false);
    setNotice("");
    timer.current = setTimeout(() => {
      setReady(true);
      opening.current = false;
    }, 850);
  }
  function equip(kind: CrateKind, item: string) {
    if (isLoomaCrate(kind) && collection.forms.includes(item as PetForm)) {
      const s = getSpecies(item as PetForm);
      setPet((p) => ({ ...p, form: s.id, colour: s.colour }));
    } else if (
      !isLoomaCrate(kind) &&
      collection.accessories.includes(item as Accessory)
    ) {
      setPet((p) => ({ ...p, accessory: item as Accessory }));
    } else return;
    setNotice("Equipped! Your Looma is ready for a little adventure.");
    setRevealId(null);
    setPreview(null);
  }
  const selectedSpecies = species.find((s) => s.id === preview);
  const selectedCosmetic = cosmetics.find((c) => c.id === preview);
  const selected = selectedSpecies ?? selectedCosmetic;
  const owned = selectedSpecies
    ? collection.forms.includes(selectedSpecies.id)
    : selectedCosmetic
      ? collection.accessories.includes(selectedCosmetic.id)
      : false;
  return (
    <>
      <PageHeading
        eyebrow="SMALL TREASURES, NO BIG RUSH"
        title="The little shop."
        description="Meet a new little character. Find something that feels like them."
        action={<Dewdrop amount={collection.balance} />}
      />
      <section className="shop-intro">
        <div>
          <Badge tone="sage">THE DEWDROP COLLECTION</Badge>
          <h2>
            Good things come
            <br />
            in little boxes.
          </h2>
          <p>
            Three elemental friends to start. A few curious ones to discover.
            Every Looma is good company.
          </p>
          <details className="shop-demo-tools">
            <summary>Demo tools · free test currency</summary>{" "}
            <button
              className="text-link"
              onClick={() => {
                setCollection((c) => ({
                  ...c,
                  balance: Math.min(1000000, c.balance + 300),
                }));
                setNotice(
                  "300 free demo Dewdrops added. Have a little browse.",
                );
              }}
            >
              <Plus size={16} /> Add 300 free demo Dewdrops
            </button>
          </details>
        </div>
        <div
          className="shop-parade"
          aria-label="Sprout, Pebble and Ripple, your three starter Loomas"
        >
          <LoomaPet form="pebble" colour="apricot" expression="sleepy" />
          <LoomaPet form="sprout" colour="sage" />
          <LoomaPet form="water" colour="blue" expression="curious" />
        </div>
      </section>
      <div className="shop-notice" role="status">
        {notice ||
          "All currency is free and fictional. Nothing here costs real money. Purchases save only in this browser."}
      </div>
      <div className="shop-crates">
        {(
          [
            "cosmetic",
            "looma",
            "halloween-cosmetic",
            "halloween-looma",
          ] as const
        ).map((kind) => (
          <article className={`crate-card crate-${kind}`} key={kind}>
            <div className="crate-illustration">
              <CrateArt kind={kind} />
              <span className="crate-edition">
                {kind.startsWith("halloween")
                  ? "HALLOWEEN / THE LITTLE HAUNT"
                  : `VOL. 01 / ${isLoomaCrate(kind) ? "ELEMENTALS" : "LITTLE DETAILS"}`}
              </span>
            </div>
            <div className="crate-copy">
              <span className="eyebrow">
                ONE RANDOM {isLoomaCrate(kind) ? "COMPANION" : "ACCESSORY"}
              </span>
              <h2>
                {kind.startsWith("halloween")
                  ? isLoomaCrate(kind)
                    ? "Halloween Looma crate"
                    : "Halloween Cosmetic crate"
                  : isLoomaCrate(kind)
                    ? "Elemental Looma crate"
                    : "Cosmetic crate"}
              </h2>
              <p>
                {isLoomaCrate(kind)
                  ? "From a tiny leaf to a little bolt of lightning. Who will you meet?"
                  : "Scarves, moonlit pins, a crown of sunshine. A little something for your Looma."}
              </p>
              <div className="crate-rarities">
                {oddsForCrate(kind).map((r) => (
                  <span className={`rarity rarity-${r.rarity}`} key={r.rarity}>
                    {r.rarity} {r.chance}%
                  </span>
                ))}
              </div>
              <div className="crate-actions">
                <button
                  className="button button-dark"
                  disabled={
                    collection.balance < cratePrices[kind] || !!revealId
                  }
                  onClick={() => buy(kind)}
                >
                  <PackageOpen size={17} /> Open · {cratePrices[kind]}{" "}
                  <Droplets size={15} />
                </button>
                <button className="text-link" onClick={() => setOdds(kind)}>
                  View all odds <ArrowUpRight size={14} />
                </button>
              </div>
              {collection.balance < cratePrices[kind] && (
                <small>Add free demo Dewdrops above to open this crate.</small>
              )}
            </div>
          </article>
        ))}
      </div>
      <section className="shop-streak-saver">
        <div>
          <h2>A little room for a missed day.</h2>
          <p>
            {journey.savers} streak savers owned. Automatic protection, one
            missed day at a time.
          </p>
          <Link className="text-link" href="/student/missions">
            See streak rules →
          </Link>
        </div>
        <button
          className="button button-outline"
          disabled={collection.balance < saverPrice || journey.savers >= 99}
          onClick={() => {
            buySaver();
            setNotice("A streak saver is tucked away for a missed day.");
          }}
        >
          Buy streak saver · {saverPrice}
        </button>
      </section>
      <section className="earned-shop-link">
        <Gift size={20} />
        <p>
          Looking for Rubio or Vesper? Those little legends live in{" "}
          <Link href="/student/chests">earned reward chests</Link>, never in
          shop crates.
        </p>
      </section>
      <section className="collection-section">
        <div className="section-heading">
          <div>
            <p className="eyebrow">A LITTLE WORLD OF THEIR OWN</p>
            <h2>Your collection</h2>
            <p>
              {collection.forms.filter((f) => f !== "pip").length} of{" "}
              {species.length}
              Loomas ·{" "}
              {
                collection.accessories.filter((a) => a !== "none").length
              } of {cosmetics.length}
              accessories
            </p>
          </div>
          <Link className="text-link" href="/student/looma">
            Customise your Looma <ArrowUpRight size={16} />
          </Link>
        </div>
        <div
          className="collection-tabs"
          role="group"
          aria-label="Collection type"
        >
          <button
            aria-pressed={tab === "looma"}
            onClick={() => {
              setTab("looma");
              setPreview(null);
            }}
          >
            Loomas
          </button>
          <button
            aria-pressed={tab === "cosmetic"}
            onClick={() => {
              setTab("cosmetic");
              setPreview(null);
            }}
          >
            Cosmetics
          </button>
        </div>
        <div className="collection-grid">
          {tab === "looma"
            ? species.map((s) => {
                const unlocked = collection.forms.includes(s.id);
                return (
                  <button
                    key={s.id}
                    className={`collection-card ${!unlocked ? "collection-locked" : ""}`}
                    onClick={() => setPreview(s.id)}
                    aria-label={`View ${s.name}, ${s.rarity}, ${unlocked ? "owned" : "not yet collected"}`}
                  >
                    <div className="collection-card-top">
                      <span className={`rarity rarity-${s.rarity}`}>
                        {s.rarity}
                      </span>
                      {unlocked ? (
                        <Check size={15} />
                      ) : (
                        <LockKeyhole size={14} />
                      )}
                    </div>
                    <LoomaPet
                      form={s.id}
                      colour={s.colour}
                      expression={
                        s.id === "pebble"
                          ? "sleepy"
                          : s.id === "fiend"
                            ? "curious"
                            : "happy"
                      }
                    />
                    <h3>{s.name}</h3>
                    <span className="element-label">{s.element}</span>
                    <span className="item-origin">{sourceLabel(s.source)}</span>
                    <p>{s.personality}</p>
                    <small>
                      {pet.form === s.id
                        ? "Your active Looma"
                        : unlocked
                          ? "In your collection"
                          : sourceLabel(s.source)}
                    </small>
                  </button>
                );
              })
            : cosmetics.map((c) => (
                <button
                  key={c.id}
                  className="collection-card"
                  onClick={() => setPreview(c.id)}
                  aria-label={`View ${c.name}`}
                >
                  <div className="collection-card-top">
                    <span className={`rarity rarity-${c.rarity}`}>
                      {c.rarity}
                    </span>
                    {collection.accessories.includes(c.id) ? (
                      <Check size={15} />
                    ) : (
                      <LockKeyhole size={14} />
                    )}
                  </div>
                  <LoomaPet {...pet} accessory={c.id} animate={false} />
                  <h3>{c.name}</h3>
                  <span className="item-origin">{sourceLabel(c.source)}</span>
                  <p>{c.description}</p>
                  <small>
                    {pet.accessory === c.id
                      ? "Equipped"
                      : collection.accessories.includes(c.id)
                        ? "In your wardrobe"
                        : sourceLabel(c.source)}
                  </small>
                </button>
              ))}
        </div>
      </section>
      {collection.history.length > 0 && (
        <section className="shop-history">
          <div className="section-heading">
            <h2>Recently unwrapped</h2>
            <span className="small-muted">
              LAST {Math.min(6, collection.history.length)} FINDS
            </span>
          </div>
          {collection.history.slice(0, 6).map((h) => (
            <div className="shop-history-row" key={h.id}>
              <Gift size={17} />
              <strong>
                {isLoomaCrate(h.kind)
                  ? getSpecies(h.item as PetForm).name
                  : cosmetics.find((c) => c.id === h.item)?.name}
              </strong>
              <span className={`rarity rarity-${h.rarity}`}>{h.rarity}</span>
              <small>
                {h.duplicate
                  ? `Already owned · +${h.refund} Dewdrops`
                  : "Added to collection"}
              </small>
            </div>
          ))}
        </section>
      )}
      <p className="shop-footnote">
        Every crate contains one item. Duplicates return 30 Dewdrops for
        cosmetics or 50 for Loomas. No pity counter or changing odds. Your
        companion never needs purchases to stay happy.
      </p>
      <Modal
        open={!!odds}
        onOpenChange={() => setOdds(null)}
        title={`${odds?.startsWith("halloween") ? "Halloween" : odds === "looma" ? "Looma" : "Cosmetic"} crate odds`}
        description="Each opening is independent. First we choose a rarity, then an item equally within that rarity. These are the exact per-item chances."
      >
        <div className="odds-table">
          {oddsForCrate(odds ?? "looma").map((r) => {
            const items = crateItems(odds ?? "looma").filter(
              (i) => i.rarity === r.rarity,
            );
            return (
              <section key={r.rarity}>
                <div>
                  <span className={`rarity rarity-${r.rarity}`}>
                    {r.rarity}
                  </span>
                  <strong>{r.chance}% total</strong>
                </div>
                {items.map((i) => (
                  <p key={i.id}>
                    <span>{i.name}</span>
                    <strong>
                      {Number((r.chance / items.length).toFixed(2))}%
                    </strong>
                  </p>
                ))}
              </section>
            );
          })}
        </div>
      </Modal>
      <Modal
        open={!!revealId}
        onOpenChange={(open) => {
          if (!open) setRevealId(null);
        }}
        title={
          ready && result
            ? (resultSpecies?.name ??
              resultCosmetic?.name ??
              "A little treasure")
            : "A little rustle…"
        }
        description={
          ready && result
            ? result.duplicate
              ? `Already in your collection. ${result.refund} Dewdrops returned.`
              : "A new little treasure, saved to your collection."
            : "Opening your crate. Your item is already safely recorded in recent finds."
        }
      >
        {!ready || !result ? (
          <div className="crate-reveal">
            <CrateArt kind={result?.kind ?? "looma"} opening />
            <span role="status">Untying the ribbon…</span>
          </div>
        ) : (
          <div className="crate-reveal">
            <span className={`rarity rarity-${result.rarity}`}>
              {result.rarity}
            </span>
            <LoomaPet
              form={resultSpecies?.id ?? pet.form}
              colour={resultSpecies?.colour ?? pet.colour}
              accessory={resultCosmetic?.id ?? "none"}
              expression="celebrating"
            />
            <p>{resultSpecies?.description ?? resultCosmetic?.description}</p>
            <button
              className="button button-dark"
              onClick={() => equip(result.kind, result.item)}
            >
              {isLoomaCrate(result.kind)
                ? "Choose this Looma"
                : "Equip accessory"}
              <Check size={17} />
            </button>
            <button className="text-link" onClick={() => setRevealId(null)}>
              Keep browsing
            </button>
          </div>
        )}
      </Modal>
      <Modal
        open={!!preview}
        onOpenChange={() => setPreview(null)}
        title={selected?.name ?? "A little treasure"}
        description={
          selectedSpecies?.description ?? selectedCosmetic?.description ?? ""
        }
      >
        {selected && (
          <div className="crate-reveal">
            <span className={`rarity rarity-${selected.rarity}`}>
              {selected.rarity}
            </span>
            <LoomaPet
              form={selectedSpecies?.id ?? pet.form}
              colour={selectedSpecies?.colour ?? pet.colour}
              accessory={selectedCosmetic?.id ?? "none"}
            />
            {selectedSpecies && (
              <p>
                {selectedSpecies.element} · {selectedSpecies.personality}
              </p>
            )}
            {owned ? (
              <button
                className="button button-dark"
                onClick={() =>
                  equip(selectedSpecies ? "looma" : "cosmetic", selected.id)
                }
              >
                Equip <Check size={16} />
              </button>
            ) : (
              <p className="input-hint">
                Not collected yet. {sourceLabel(selected.source)}.
              </p>
            )}
          </div>
        )}
      </Modal>
    </>
  );
}
