"use client";
import Link from "next/link";
import {
  ArrowUpRight,
  Shirt,
  Clock3,
  MapPin,
  ArrowRight,
  Check,
  Sun,
  Leaf,
  Backpack,
} from "lucide-react";
import { useDemo } from "@/lib/store";
import { Badge, PageHeading, SectionHeading } from "../ui/shared";
import { openTasks, dueLabel } from "@/lib/utils";
import { timetable } from "@/lib/data/mock";
import { DailyProgress } from "../rewards/DailyProgress";
import { PetPlayground } from "../pets/PetPlayground";
export function StudentDashboard() {
  const { pet, student, setStudent } = useDemo();
  const tasks = openTasks(student.tasks);
  const lessons = timetable(2);
  return (
    <>
      <PageHeading
        eyebrow="WEDNESDAY, 14 OCTOBER 2026 · DEMO DAY"
        title="Morning, Alex."
        description="A fresh page. Here’s what today has in store."
        action={
          <span className="day-tag">
            <Sun size={18} />
            Week 1 · Term 4
          </span>
        }
      />
      <DailyProgress />
      <div className="student-grid">
        <PetPlayground />
        <div className="today-column">
          <section className="today-essentials">
            <div className="section-heading">
              <h2>Before you head out</h2>
              <span className="small-muted">THE LITTLE ESSENTIALS</span>
            </div>
            <div className="essentials-row">
              <span className="essential-icon apricot">
                <Shirt size={25} strokeWidth={1.5} />
              </span>
              <div>
                <h3>Summer uniform</h3>
                <p>Bring your blazer for assembly.</p>
                <span className="source-inline">Sample uniform guide</span>
              </div>
              <Link
                href="/student/schedule"
                className="icon-button"
                aria-label="View uniform details"
              >
                <ArrowUpRight size={19} />
              </Link>
            </div>
            <div className="essentials-row">
              <span className="essential-icon blue">
                <Backpack size={25} strokeWidth={1.5} />
              </span>
              <div>
                <h3>Hockey gear, water, mouthguard</h3>
                <p>Training at the turf · 15:45</p>
                <span className="source-inline">
                  Sample activities calendar
                </span>
              </div>
              <Link
                href="/student/schedule"
                className="icon-button"
                aria-label="View activity details"
              >
                <ArrowUpRight size={19} />
              </Link>
            </div>
          </section>
          <section className="timetable-card">
            <SectionHeading
              title="Your classes today"
              href="/student/schedule"
              label="Full timetable"
            />
            <div className="class-list">
              {lessons.slice(0, 3).map((l, i) => (
                <div key={l.time} className="class-row">
                  <span className="class-time">{l.time}</span>
                  <span className={`class-rule ${l.colour}`} />
                  <div>
                    <h3>{l.subject}</h3>
                    <p>
                      {l.room} <span>·</span> {l.teacher}
                    </p>
                  </div>
                  {i === 0 ? (
                    <Badge tone="blue">First up</Badge>
                  ) : (
                    <span className="class-duration">55 min</span>
                  )}
                </div>
              ))}
            </div>
            <p className="timetable-foot">
              <Clock3 size={13} />
              Two more classes after lunch.
            </p>
          </section>
        </div>
        <section className="homework-card">
          <SectionHeading
            title="A little to-do"
            href="/student/homework"
            label="All homework"
            detail={`${tasks.length} open tasks · make a small start`}
          />
          <div>
            {tasks.slice(0, 3).map((t) => (
              <div key={t.id} className="task-row">
                <button
                  className="check-button"
                  aria-label={`Complete ${t.title}`}
                  onClick={() =>
                    setStudent((s) => ({
                      ...s,
                      tasks: s.tasks.map((x) =>
                        x.id === t.id ? { ...x, complete: true } : x,
                      ),
                    }))
                  }
                >
                  <Check size={14} />
                </button>
                <div>
                  <span className="task-subject">{t.subject}</span>
                  <h3>{t.title}</h3>
                </div>
                <Badge tone={t.due === "2026-10-14" ? "apricot" : "neutral"}>
                  {dueLabel(t.due)}
                </Badge>
              </div>
            ))}
            {tasks.length === 0 && (
              <p className="quiet-message">
                Everything’s checked off. Enjoy the breathing room.
              </p>
            )}
          </div>
          <Link href="/student/homework" className="add-task-link">
            + Add a personal task
          </Link>
        </section>
        <section className="notice-card">
          <div className="notice-illustration">
            <Leaf size={35} strokeWidth={1.3} />
            <span>HOUSE NOTES</span>
          </div>
          <div>
            <Badge tone="gold">Around the house</Badge>
            <h2>A little time outdoors.</h2>
            <p>
              Plant spring seedlings in the community garden this Friday. No
              green thumb needed.
            </p>
            <div className="notice-meta">
              <span>
                <Clock3 size={14} />
                Fri · 16:00
              </span>
              <span>
                <MapPin size={14} />
                Community garden
              </span>
            </div>
            <Link href="/student/schedule" className="text-link">
              See what’s happening <ArrowRight size={16} />
            </Link>
          </div>
        </section>
        <div className="evening-banner">
          <span className="evening-icon">
            <Clock3 size={21} />
          </span>
          <div>
            <strong>A calmer evening starts now.</strong>
            <p>
              Dinner at 18:00. Prep at 19:00. A little plan goes a long way.
            </p>
          </div>
          <Link href="/student/chat" className="text-link">
            Plan with {pet.name} <ArrowUpRight size={17} />
          </Link>
        </div>
      </div>
    </>
  );
}
