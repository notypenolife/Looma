"use client";
import { useId, useRef, useEffect, type CSSProperties } from "react";
import type { Performance } from "@/lib/behaviours";
import type { PetEvent } from "@/lib/collection";
import { usePerformance } from "./usePerformance";
import { PerformanceProps } from "./PerformanceProps";
import { FittedAccessory } from "./FittedAccessory";
import { ChestExclusiveForm } from "./ChestExclusiveForms";
import type { Accessory, Expression, PetColour, PetForm } from "@/lib/types";
import { PetFace } from "./PetFace";
import { SpecialForm } from "./SpecialArtwork";
export const petPalettes = {
  sage: {
    body: "#B7D7B4",
    shade: "#86AE83",
    light: "#DCE9CB",
    leaf: "#537E54",
  },
  apricot: {
    body: "#EFBCA0",
    shade: "#CB8F78",
    light: "#F9DAC2",
    leaf: "#A86B54",
  },
  blue: {
    body: "#B3C9E3",
    shade: "#819DBD",
    light: "#DFE9F4",
    leaf: "#54748D",
  },
  gold: {
    body: "#E8CE88",
    shade: "#BBA05C",
    light: "#F7E8B8",
    leaf: "#8E773E",
  },
};
export function LoomaPet({
  form = "sprout",
  colour = "sage",
  accessory = "none",
  expression,
  className = "",
  animate = true,
  label,
  construction = false,
  cue,
  performance,
  onPerformance,
}: {
  form?: PetForm;
  colour?: PetColour;
  accessory?: Accessory;
  expression?: Expression;
  className?: string;
  animate?: boolean;
  label?: string;
  construction?: boolean;
  cue?: { id: string; event: PetEvent };
  performance?: Performance | null;
  onPerformance?: (action: Performance | null) => void;
}) {
  const uid = useId().replace(/[^a-zA-Z0-9]/g, "");
  const svgRef = useRef<SVGSVGElement>(null);
  const actor = usePerformance(
    svgRef,
    form,
    animate && !construction && performance === undefined,
    cue,
  );
  const active = performance === undefined ? actor.performance : performance;
  useEffect(() => {
    onPerformance?.(active);
  }, [active, onPerformance]);
  const feeling = expression ?? active?.expression ?? "happy";
  const winking = !!active && /wink|innocent/i.test(active.label);
  const base = petPalettes[colour] || petPalettes.sage;
  const p =
    form === "shadow" && colour === "blue"
      ? { body: "#ADA4C4", shade: "#827592", light: "#DAD2E8", leaf: "#6D617F" }
      : form === "fiend" && colour === "apricot"
        ? {
            body: "#E2A7AB",
            shade: "#BF7D8F",
            light: "#F8D3CD",
            leaf: "#93607C",
          }
        : base;
  const specialPalette =
    form === "void"
      ? {
          body: "#363239",
          shade: "#714C49",
          light: colour === "gold" ? "#DCC178" : base.light,
          leaf: "#B45D54",
        }
      : form === "rubio"
        ? {
            body: "#D19A9E",
            shade: "#AF6F83",
            light: "#E8C69F",
            leaf: "#99536B",
          }
        : form === "ghost"
          ? {
              body: "#E0E6E8",
              shade: "#B9CBD0",
              light: "#F8FAEF",
              leaf: "#859FA5",
            }
          : form === "bat"
            ? {
                body: "#B5A7C5",
                shade: "#8B7B9D",
                light: "#DDD4E4",
                leaf: "#776A88",
              }
            : p;
  const ink = form === "void" ? "#E6D298" : "#354638";
  return (
    <svg
      ref={svgRef}
      data-performance={active?.id ?? "resting"}
      data-character={form}
      style={
        {
          "--act-x": `${active?.amplitude ?? 3}px`,
          "--jump-height": `${form === "pebble" ? 12 : form === "sprout" ? 22 : form === "electricity" ? 28 : form === "void" ? 27 : 36}px`,
          "--act-tilt": `${active?.tilt ?? 4}deg`,
          "--act-duration": `${(active?.duration ?? 4000) / 1000}s`,
        } as CSSProperties
      }
      viewBox="0 0 280 280"
      role="img"
      aria-label={label || `${form} Looma, feeling ${feeling}`}
      className={`looma-pet ${animate ? "pet-animated" : ""} pet-species-${form} actor-managed embodied-pet ${actor.paused ? "actor-paused" : ""} pose-${active?.motion ?? "breathe"} ${className}`}
      xmlns="http://www.w3.org/2000/svg"
    >
      <ellipse
        key={`shadow-${active?.id ?? "quiet"}`}
        className="pet-ground-shadow"
        cx="140"
        cy="246"
        rx={form === "pip" ? 68 : 59}
        ry="9"
        fill="#344C32"
        opacity=".09"
      />
      <g className="pet-locomotion" key={active?.id ?? "quiet"}>
        <g
          className="pet-body"
          stroke={ink}
          strokeWidth="2.7"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <FittedAccessory
            form={form}
            accessory={accessory}
            layer="back"
            uid={uid}
          />
          {form === "sprout" && (
            <>
              <path
                className="pet-crest pet-crest-left"
                d="M137 83C121 64 118 45 121 28C151 33 163 55 145 82"
                fill={p.leaf}
              />
              <path
                className="pet-crest pet-crest-right"
                d="M142 82C150 49 176 43 196 49C193 70 177 89 147 88"
                fill={p.body}
              />
              <>
                <path
                  className="pet-crest pet-crest-left"
                  d="M135 45L143 79"
                  fill="none"
                  stroke={p.light}
                  strokeWidth="2"
                />
                <path
                  className="pet-crest pet-crest-right"
                  d="M178 59L146 85"
                  fill="none"
                  stroke={p.light}
                  strokeWidth="2"
                />
              </>
              <>
                <path
                  className="pet-foot pet-foot-left"
                  d="M91 211C79 221 76 238 90 240C105 242 114 224 114 220"
                  fill={p.shade}
                />
                <path
                  className="pet-foot pet-foot-right"
                  d="M165 222C170 240 184 244 191 235C199 226 183 214 181 212"
                  fill={p.shade}
                />
              </>
              <>
                <path
                  className="pet-arm pet-arm-left"
                  d="M88 169C62 174 57 195 72 198C84 200 99 185 101 180"
                  fill={p.body}
                />
                <path
                  className="pet-arm pet-arm-right"
                  d="M190 167C213 169 225 181 216 191C209 200 194 188 184 181"
                  fill={p.body}
                />
              </>
              <path
                className="pet-torso"
                d="M139 82C113 83 86 117 83 154C78 193 92 223 135 229C182 236 199 210 197 175C194 139 175 87 139 82Z"
                fill={p.body}
              />
              <path
                d="M94 187C104 217 126 222 146 219"
                fill="none"
                stroke={p.shade}
                strokeWidth="5"
              />
              <path
                d="M105 135C112 112 124 101 130 100"
                fill="none"
                stroke={p.light}
                strokeWidth="7"
              />
              <path
                d="M136 199C142 186 153 187 157 195C150 205 141 207 136 199Z"
                fill={p.light}
                stroke="none"
              />
            </>
          )}
          {form === "pebble" && (
            <>
              <>
                <path
                  className="pet-foot pet-foot-left"
                  d="M91 211C74 222 78 241 93 241C107 241 111 226 112 219"
                  fill={p.shade}
                />
                <path
                  className="pet-foot pet-foot-right"
                  d="M167 221C170 237 186 246 197 237C207 229 190 215 180 213"
                  fill={p.shade}
                />
              </>
              <>
                <path
                  className="pet-arm pet-arm-left"
                  d="M74 160C57 150 45 162 49 177C53 193 72 195 83 185"
                  fill={p.body}
                />
                <path
                  className="pet-arm pet-arm-right"
                  d="M206 164C222 152 235 165 230 181C227 195 209 194 199 185"
                  fill={p.body}
                />
              </>
              <path
                className="pet-torso"
                d="M71 164C64 134 78 108 105 96C119 76 154 77 164 95C197 101 213 135 208 169C205 214 178 232 138 233C97 234 74 210 71 164Z"
                fill={p.body}
              />
              <path
                d="M92 127C100 114 110 109 119 108"
                fill="none"
                stroke={p.light}
                strokeWidth="9"
              />
              <path
                className="pet-crest pet-crest-left"
                d="M153 92C164 83 165 70 159 64C142 70 141 82 146 91"
                fill={p.shade}
              />
              <path
                d="M84 194C94 216 111 221 128 221"
                stroke={p.shade}
                strokeWidth="5"
                fill="none"
              />
              <ellipse
                cx="144"
                cy="205"
                rx="24"
                ry="12"
                fill={p.light}
                stroke="none"
              />
            </>
          )}
          {form === "pip" && (
            <>
              <>
                <path
                  className="pet-foot pet-foot-left"
                  d="M119 212L116 235L102 239M116 235L127 239"
                  fill="none"
                  stroke="#AD8450"
                  strokeWidth="5"
                />
                <path
                  className="pet-foot pet-foot-right"
                  d="M161 215L164 235L179 239M164 235L153 240"
                  fill="none"
                  stroke="#AD8450"
                  strokeWidth="5"
                />
              </>
              <path
                className="pet-crest pet-crest-left"
                d="M109 89C93 75 97 54 109 53C120 63 121 74 120 83C124 63 137 58 144 64C145 74 138 83 136 86"
                fill={p.shade}
              />
              <path
                className="pet-arm pet-arm-left"
                d="M73 166C58 171 47 189 51 197C65 205 82 194 92 184"
                fill={p.shade}
              />
              <path
                className="pet-torso"
                d="M110 87C146 76 181 91 191 125C195 142 210 151 227 145C238 166 220 192 199 205C179 222 143 231 111 217C73 202 66 174 74 137C78 116 91 95 110 87Z"
                fill={p.body}
              />
              <path
                className="pet-arm pet-arm-right"
                d="M159 173C168 152 193 151 207 158C207 177 188 196 172 191"
                fill={p.shade}
              />
              <path
                d="M89 129C96 110 109 105 116 104"
                stroke={p.light}
                strokeWidth="8"
                fill="none"
              />
              <path
                d="M82 165C79 190 98 205 118 209"
                stroke={p.shade}
                strokeWidth="5"
                fill="none"
              />
            </>
          )}
          {form === "water" && (
            <>
              <>
                <path
                  className="pet-arm pet-arm-left"
                  d="M89 196Q57 182 65 167Q76 157 96 173"
                  fill={p.shade}
                />
                <path
                  className="pet-arm pet-arm-right"
                  d="M181 188Q211 178 216 191Q217 206 192 208"
                  fill={p.shade}
                />
              </>
              <path
                className="pet-torso"
                d="M139 55C149 88 196 109 199 160C204 204 178 232 137 233C95 233 74 209 79 172C85 130 116 113 139 55Z"
                fill={p.body}
              />
              <path
                d="M104 128Q119 111 128 95"
                stroke={p.light}
                strokeWidth="9"
                fill="none"
              />
              <path
                d="M98 205Q126 226 160 215"
                stroke={p.shade}
                strokeWidth="6"
                fill="none"
              />
              <>
                <path
                  className="pet-foot pet-foot-left"
                  d="M98 221Q85 238 103 240L122 230"
                  fill={p.shade}
                />
                <path
                  className="pet-foot pet-foot-right"
                  d="M164 230Q179 243 192 233L182 220"
                  fill={p.shade}
                />
              </>
              <circle cx="198" cy="102" r="8" fill={p.light} />
              <circle cx="213" cy="79" r="4" fill={p.body} />
            </>
          )}
          {form === "fire" && (
            <>
              <>
                <path
                  className="pet-foot pet-foot-left"
                  d="M90 217L81 237Q99 246 116 226"
                  fill={p.shade}
                />
                <path
                  className="pet-foot pet-foot-right"
                  d="M167 225Q183 245 197 235L184 215"
                  fill={p.shade}
                />
              </>
              <path
                className="pet-torso"
                d="M90 115Q93 83 115 68Q111 95 129 100Q156 85 149 44Q188 69 183 111Q211 140 203 179Q200 229 142 232Q83 230 78 184Q68 150 90 115Z"
                fill={p.body}
              />
              <path
                d="M114 108Q131 112 139 95Q143 118 161 117"
                fill={p.light}
                stroke="none"
              />
              <>
                <path
                  className="pet-arm pet-arm-left"
                  d="M87 175Q57 166 60 185Q65 202 88 199"
                  fill={p.body}
                />
                <path
                  className="pet-arm pet-arm-right"
                  d="M196 174Q226 164 224 183Q219 204 199 198"
                  fill={p.body}
                />
              </>
              <path
                d="M119 215Q108 197 130 185Q131 202 142 204Q153 193 149 179Q178 203 159 218"
                fill={p.light}
                stroke="none"
              />
            </>
          )}
          {form === "electricity" && (
            <>
              <>
                <path
                  className="pet-crest pet-crest-left"
                  d="M101 111L83 61L111 76L121 39L137 103"
                  fill={p.shade}
                />
                <path
                  className="pet-crest pet-crest-right"
                  d="M155 103L179 50L185 81L211 66L183 125"
                  fill={p.shade}
                />
              </>
              <path
                className="pet-tail"
                d="M196 183L225 171L215 153L247 138L232 177L242 192L204 209"
                fill={p.body}
              />
              <>
                <path
                  className="pet-foot pet-foot-left"
                  d="M96 213L86 235Q104 244 117 226"
                  fill={p.shade}
                />
                <path
                  className="pet-foot pet-foot-right"
                  d="M166 225Q183 244 195 234L184 211"
                  fill={p.shade}
                />
              </>
              <path
                className="pet-torso"
                d="M76 155Q75 103 126 98Q183 88 200 135Q220 193 184 220Q153 243 109 225Q74 214 76 155Z"
                fill={p.body}
              />
              <path
                d="M96 131Q106 116 122 116"
                fill="none"
                stroke={p.light}
                strokeWidth="8"
              />
              <path
                d="M137 191L121 207H136L132 223L154 202H140L149 191"
                fill={p.light}
                stroke="none"
              />
            </>
          )}
          {form === "shadow" && (
            <>
              <path
                className="pet-foot pet-foot-left"
                d="M96 215Q79 231 94 239L119 224"
                fill={p.shade}
              />
              <path
                className="pet-foot pet-foot-right"
                d="M167 224Q183 241 196 234L185 213"
                fill={p.shade}
              />
              <path
                className="pet-crest pet-crest-left"
                d="M83 142L91 70Q113 81 123 104L111 139Z"
                fill={p.body}
              />
              <path
                className="pet-crest pet-crest-right"
                d="M163 104Q180 72 200 70L194 142L177 139Z"
                fill={p.body}
              />
              <>
                <path
                  className="pet-arm pet-arm-left"
                  d="M89 159Q55 150 51 175Q63 169 72 185L93 190"
                  fill={p.shade}
                />
                <path
                  className="pet-arm pet-arm-right"
                  d="M185 164Q221 148 228 172Q214 167 207 187L186 195"
                  fill={p.shade}
                />
              </>
              <path
                className="pet-torso"
                d={
                  active?.motion === "inspect"
                    ? "M86 140Q91 104 135 103Q178 97 192 141Q205 198 181 225Q158 220 144 232Q127 223 109 229Q76 210 86 140Z"
                    : "M83 141Q86 102 128 103Q169 94 194 141Q212 194 192 226Q180 220 171 230Q158 219 144 232Q130 222 115 230Q100 219 88 223Q67 192 83 141Z"
                }
                fill={p.body}
              />
              <path
                d="M104 122Q108 113 119 112"
                fill="none"
                stroke={p.light}
                strokeWidth="8"
              />
              <path
                d="M141 187Q132 204 149 211Q134 215 126 201Q120 188 141 187"
                fill={p.light}
                stroke="none"
              />
            </>
          )}
          {form === "fiend" && (
            <>
              <path
                className="pet-tail"
                d="M194 208Q226 213 226 189L216 186L235 175L241 195L231 193Q232 230 190 222"
                fill={p.shade}
              />
              <>
                <path
                  className="pet-arm pet-arm-left"
                  d="M90 153Q54 122 44 151L58 155L52 171L72 170L76 190"
                  fill={p.shade}
                />
                <path
                  className="pet-arm pet-arm-right"
                  d="M185 153Q218 121 233 149L220 157L226 171L207 170L203 191"
                  fill={p.shade}
                />
              </>
              <>
                <path
                  className="pet-crest pet-crest-left"
                  d="M96 115Q84 91 98 66Q99 88 119 98"
                  fill="#EAD6BB"
                />
                <path
                  className="pet-crest pet-crest-right"
                  d="M159 98Q183 88 180 66Q198 88 187 117"
                  fill="#EAD6BB"
                />
              </>
              <>
                <path
                  className="pet-foot pet-foot-left"
                  d="M96 215L87 237Q104 243 118 226"
                  fill={p.shade}
                />
                <path
                  className="pet-foot pet-foot-right"
                  d="M165 226Q180 244 196 235L184 215"
                  fill={p.shade}
                />
              </>
              <path
                className="pet-torso"
                d="M77 151Q77 101 132 98Q190 94 203 145Q218 198 188 220Q149 244 108 226Q77 214 77 151Z"
                fill={p.body}
              />
              <path d="M99 125L111 119" stroke={p.light} strokeWidth="8" />
              <path
                d="M130 198L139 205L149 195L157 204L139 217L123 207Z"
                fill={p.light}
                stroke="none"
              />
            </>
          )}
          <SpecialForm form={form} p={specialPalette} />
          <ChestExclusiveForm form={form} />
          <g className="pet-head-rig">
            <PetFace
              form={form}
              expression={feeling}
              wink={winking}
              turn={["peek", "inspect", "sneak", "read"].includes(
                active?.motion ?? "",
              )}
              eating={active?.motion === "eat"}
            />
            <FittedAccessory
              form={form}
              accessory={accessory}
              layer="head"
              uid={uid}
            />
          </g>
          <FittedAccessory
            form={form}
            accessory={accessory}
            layer="torso"
            uid={uid}
          />
          <PerformanceProps performance={active} />
          {construction && (
            <g className="construction-outfit">
              <path
                d="M99 186L119 190L137 216L154 190L178 185L182 221Q139 238 97 220Z"
                fill="#EDA66E"
              />
              <path
                d="M108 191L110 224M168 191L165 225"
                stroke="#FFF4BD"
                strokeWidth="8"
              />
              <path d="M100 214H178" stroke="#FFF4BD" strokeWidth="6" />
              <path d="M91 115Q91 68 138 67Q186 67 186 115Z" fill="#F0CC70" />
              <path
                d="M130 70V108M145 70V108"
                fill="none"
                stroke="#D3AA48"
                strokeWidth="5"
              />
              <path d="M83 115Q136 105 193 115L192 125H84Z" fill="#F3D68C" />
              <g className="pet-wipe">
                <path
                  d="M190 184Q212 167 190 143L169 133"
                  fill="none"
                  stroke={p.shade}
                  strokeWidth="13"
                />
                <ellipse cx="170" cy="132" rx="13" ry="9" fill={p.body} />
              </g>
              <path
                className="pet-sweat"
                d="M202 123Q190 140 201 143Q214 142 202 123Z"
                fill="#A9CFDF"
                stroke="none"
              />
            </g>
          )}
        </g>
        {feeling === "celebrating" && (
          <g strokeWidth="3" strokeLinecap="round">
            <path d="M53 98L47 87M216 100L224 88" stroke="#CB916D" />
            <path d="M48 123L35 121M230 124L243 120" stroke="#88A68A" />
            <circle cx="65" cy="73" r="4" fill="#D7B963" />
            <circle cx="215" cy="65" r="4" fill="#9AAFCA" />
          </g>
        )}
      </g>
      {active?.motion === "doze" && (
        <g
          className="pet-sleep-sign"
          fill="none"
          stroke={ink}
          strokeWidth="2"
          opacity=".45"
        >
          <path d="M205 111h10l-10 10h10M221 95h7l-7 7h7" />
        </g>
      )}
    </svg>
  );
}
