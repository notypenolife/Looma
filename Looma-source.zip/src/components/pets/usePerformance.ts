"use client";
import { useEffect, useRef, useState, type RefObject } from "react";
import type { PetForm } from "@/lib/types";
import type { PetEvent } from "@/lib/collection";
import {
  choosePerformance,
  performances,
  type Performance,
  type BehaviourCategory,
} from "@/lib/behaviours";
import { eventPerformance } from "@/lib/embodiment";
export function usePerformance(
  ref: RefObject<SVGSVGElement | null>,
  form: PetForm,
  enabled: boolean,
  cue?: { id: string; event: PetEvent },
) {
  const history = useRef<Record<string, number>>({}),
    last = useRef<string | undefined>(undefined),
    manualCount = useRef(0);
  const cueId = cue?.id,
    cueEvent = cue?.event;
  const [performance, setPerformance] = useState<Performance | null>(null),
    [paused, setPaused] = useState(false);
  useEffect(() => {
    if (!enabled) return;
    let timer: ReturnType<typeof setTimeout> | undefined,
      visible = false,
      started = false,
      disposed = false,
      consumedCue = false;
    const media = window.matchMedia("(prefers-reduced-motion: reduce)");
    const random = () =>
      crypto.getRandomValues(new Uint32Array(1))[0] / 4294967296;
    const hour = () =>
      Number(
        new Intl.DateTimeFormat("en-NZ", {
          timeZone: "Pacific/Auckland",
          hour: "numeric",
          hourCycle: "h23",
        }).format(new Date()),
      );
    const cancel = () => {
      if (timer) clearTimeout(timer);
      timer = undefined;
    };
    const available = () => !disposed && visible && !document.hidden;
    function queue(category: BehaviourCategory, delay: number) {
      cancel();
      if (!available() || (media.matches && (!cueEvent || consumedCue))) return;
      timer = setTimeout(() => {
        if (!available()) return;
        let action = choosePerformance(
          form,
          category,
          Date.now(),
          history.current,
          last.current,
          random(),
          hour(),
        );
        const now = Date.now();
        if (cueEvent && !consumedCue) {
          action = eventPerformance(
            form,
            cueEvent,
            manualCount.current++,
            performances(form),
          );
          action = { ...action, id: `${action.id}:${cueId}` };
          consumedCue = true;
        }
        if (!action) {
          queue("idle", 5000);
          return;
        }
        history.current[action.id] = now;
        last.current = action.id;
        setPerformance(action);
        if (media.matches) return;
        timer = setTimeout(() => {
          setPerformance(null);
          queue("idle", 8000 + random() * 11000);
        }, action.duration);
      }, delay);
    }
    function resume() {
      cancel();
      const active = available();
      setPaused(!active);
      if (!active) {
        setPerformance(null);
        return;
      }
      queue(
        !started
          ? cueEvent
            ? cueEvent === "task" || cueEvent === "play"
              ? "achievement"
              : cueEvent === "crate"
                ? "surprise"
                : cueEvent === "focus" || cueEvent === "rest"
                  ? "focus"
                  : "entrance"
            : "entrance"
          : "idle",
        started ? 1000 : cueEvent ? 0 : 100,
      );
      started = true;
    }
    const observer = new IntersectionObserver(
      (entries) => {
        visible = entries.some((e) => e.isIntersecting);
        resume();
      },
      { threshold: 0.1 },
    );
    if (ref.current) observer.observe(ref.current);
    document.addEventListener("visibilitychange", resume);
    media.addEventListener("change", resume);
    return () => {
      disposed = true;
      cancel();
      observer.disconnect();
      document.removeEventListener("visibilitychange", resume);
      media.removeEventListener("change", resume);
    };
  }, [form, enabled, cueId, cueEvent, ref]);
  return { performance, paused };
}
