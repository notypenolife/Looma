import type { Accessory, PetForm } from "@/lib/types";
type Palette = { body: string; shade: string; light: string; leaf: string };
export function SpecialForm({ form, p }: { form: PetForm; p: Palette }) {
  if (form === "rubio")
    return (
      <>
        <>
          <path
            className="pet-foot pet-foot-left"
            d="M95 217L84 237Q103 246 119 226"
            fill={p.shade}
          />
          <path
            className="pet-foot pet-foot-right"
            d="M165 225Q181 244 196 235L185 213"
            fill={p.shade}
          />
        </>
        <path
          className="pet-torso"
          d="M78 150Q74 112 108 99L122 72L145 92L168 77L177 106Q208 125 203 173Q204 224 145 232Q82 237 78 188Z"
          fill={p.body}
        />
        <path
          className="pet-crest pet-crest-left"
          d="M119 98L122 73L145 92L169 78L158 108Z"
          fill={p.light}
        />
        <>
          <path
            className="pet-arm pet-arm-left"
            d="M96 173Q62 165 62 183Q67 203 88 198"
            fill={p.body}
          />
          <path
            className="pet-arm pet-arm-right"
            d="M197 175Q220 162 225 178Q229 193 203 201"
            fill={p.body}
          />
        </>
        <path d="M136 190L151 204L137 220L122 204Z" fill="#A84565" />
        <path
          d="M136 191L137 219M123 204H150"
          stroke="#E5ADAF"
          strokeWidth="1.5"
        />
        <path d="M97 128L110 119" stroke={p.light} strokeWidth="8" />
      </>
    );
  if (form === "void")
    return (
      <>
        <>
          <path
            className="pet-arm pet-arm-left"
            d="M83 158Q50 131 39 158L55 166L47 185L78 180"
            fill="#744B49"
          />
          <path
            className="pet-arm pet-arm-right"
            d="M195 158Q228 134 239 158L223 166L231 184L202 180"
            fill="#744B49"
          />
        </>
        <>
          <path
            className="pet-crest pet-crest-left"
            d="M103 101Q78 79 89 48Q101 74 119 79"
            fill="#C7B16F"
          />
          <path
            className="pet-crest pet-crest-right"
            d="M158 78Q181 75 191 49Q203 77 177 104"
            fill="#C7B16F"
          />
        </>
        <path
          className="pet-tail"
          d="M194 209Q228 219 231 198L221 193L240 182L246 204L237 202Q237 238 193 225"
          fill="#AD6055"
        />
        <>
          <path
            className="pet-foot pet-foot-left"
            d="M96 211L83 235Q103 244 118 225"
            fill="#6C4D49"
          />
          <path
            className="pet-foot pet-foot-right"
            d="M166 225Q182 244 196 234L183 211"
            fill="#6C4D49"
          />
        </>
        <path
          className="pet-torso"
          d="M77 151Q76 94 136 92Q194 91 204 145Q219 203 181 224Q140 245 100 222Q76 206 77 151Z"
          fill={p.body}
        />
        <path
          d="M97 128L108 120M167 118L177 126"
          stroke={p.light}
          strokeWidth="6"
        />
        <path
          d="M113 191L136 215L161 190L171 218Q142 237 106 216Z"
          fill="#8E4B49"
        />
        <path d="M134 193L141 186L149 195L141 203Z" fill={p.light} />
        <g
          className="void-floating-chain"
          fill="none"
          stroke={p.light}
          strokeWidth="3"
        >
          <ellipse
            cx="81"
            cy="177"
            rx="8"
            ry="12"
            transform="rotate(-30 81 177)"
          />
          <ellipse
            cx="92"
            cy="195"
            rx="8"
            ry="12"
            transform="rotate(-35 92 195)"
          />
          <ellipse cx="109" cy="208" rx="12" ry="8" />
          <ellipse cx="131" cy="212" rx="12" ry="8" />
          <ellipse cx="154" cy="209" rx="12" ry="8" />
          <ellipse
            cx="175"
            cy="197"
            rx="8"
            ry="12"
            transform="rotate(35 175 197)"
          />
          <ellipse
            cx="188"
            cy="179"
            rx="8"
            ry="12"
            transform="rotate(30 188 179)"
          />
        </g>
      </>
    );
  if (form === "pumpkin")
    return (
      <>
        <path
          className="pet-crest pet-crest-left"
          d="M131 92Q118 66 140 55L150 64Q132 71 145 93"
          fill="#72916A"
        />
        <path
          className="pet-crest pet-crest-left"
          d="M144 80Q166 54 181 72Q176 88 145 91"
          fill="#A8BF81"
        />
        <>
          <path
            className="pet-foot pet-foot-left"
            d="M100 215L92 237Q112 245 122 224"
            fill={p.shade}
          />
          <path
            className="pet-foot pet-foot-right"
            d="M165 223Q176 243 195 235L183 213"
            fill={p.shade}
          />
        </>
        <path
          className="pet-torso"
          d="M77 147Q71 109 108 103Q135 80 164 101Q203 99 210 143Q224 199 188 222Q146 244 101 222Q72 206 77 147Z"
          fill={p.body}
        />
        <path
          d="M112 108Q93 131 100 170Q102 209 118 223M159 104Q183 123 181 173Q179 208 162 224"
          fill="none"
          stroke={p.shade}
          strokeWidth="3"
        />
        <>
          <path
            className="pet-arm pet-arm-left"
            d="M81 174Q53 161 56 183Q62 200 84 197"
            fill={p.body}
          />
          <path
            className="pet-arm pet-arm-right"
            d="M206 173Q231 165 229 185Q224 199 206 196"
            fill={p.body}
          />
        </>
      </>
    );
  if (form === "ghost")
    return (
      <>
        <>
          <path
            className="pet-arm pet-arm-left"
            d="M82 163Q54 151 49 170Q58 189 82 191"
            fill={p.shade}
          />
          <path
            className="pet-arm pet-arm-right"
            d="M193 163Q220 152 231 174Q215 190 197 190"
            fill={p.shade}
          />
        </>
        <path
          className="pet-torso"
          d="M77 163Q78 87 137 84Q201 81 202 163L212 216L192 211L179 232L159 219L139 235L118 220L97 231L86 213L68 221Z"
          fill={p.body}
        />
        <path
          d="M100 122Q110 105 125 105"
          stroke={p.light}
          strokeWidth="9"
          fill="none"
        />
        <path
          d="M117 198Q136 210 157 197"
          fill="none"
          stroke={p.shade}
          strokeWidth="4"
        />
      </>
    );
  if (form === "bat")
    return (
      <>
        <>
          <path
            className="pet-arm pet-arm-left"
            d="M88 151Q51 95 27 131L39 147L30 169L52 168L57 190L88 181"
            fill={p.shade}
          />
          <path
            className="pet-arm pet-arm-right"
            d="M189 151Q228 96 253 131L240 146L248 169L227 168L221 188L192 181"
            fill={p.shade}
          />
        </>
        <>
          <path
            className="pet-crest pet-crest-left"
            d="M93 112L88 63L120 98"
            fill={p.body}
          />
          <path
            className="pet-crest pet-crest-right"
            d="M160 98L193 64L187 119"
            fill={p.body}
          />
        </>
        <>
          <path
            className="pet-foot pet-foot-left"
            d="M100 211L91 237L117 226"
            fill={p.shade}
          />
          <path
            className="pet-foot pet-foot-right"
            d="M163 224L188 237L183 213"
            fill={p.shade}
          />
        </>
        <path
          className="pet-torso"
          d="M79 154Q76 101 131 98Q194 92 201 152Q213 202 179 223Q138 242 103 219Q80 203 79 154Z"
          fill={p.body}
        />
        <path d="M105 120L113 115" stroke={p.light} strokeWidth="7" />
        <path
          d="M119 204Q140 218 160 201"
          fill="none"
          stroke={p.light}
          strokeWidth="9"
        />
      </>
    );
  if (form === "witch")
    return (
      <>
        <>
          <path
            className="pet-foot pet-foot-left"
            d="M93 213L84 236Q103 244 118 225"
            fill={p.shade}
          />
          <path
            className="pet-foot pet-foot-right"
            d="M164 223Q180 243 196 233L184 212"
            fill={p.shade}
          />
        </>
        <path
          className="pet-torso"
          d="M78 156Q75 105 131 101Q190 96 202 151Q216 201 179 225Q142 244 103 222Q77 203 78 156Z"
          fill={p.body}
        />
        <>
          <path
            className="pet-arm pet-arm-left"
            d="M79 172Q56 157 53 177Q59 199 82 198"
            fill={p.body}
          />
          <path
            className="pet-arm pet-arm-right"
            d="M202 172Q227 155 229 176Q225 196 202 195"
            fill={p.body}
          />
        </>
        <path d="M91 105L130 42L166 68L159 57L147 108Z" fill="#76677F" />
        <path
          d="M90 105Q137 89 183 108L180 118Q137 109 89 119Z"
          fill="#76677F"
        />
        <path d="M114 77L105 92L159 94L160 81Z" fill="#C6AC79" />
        <path d="M132 81L140 91L149 82L140 75Z" fill="#A0C6A5" />
        <path d="M122 205L140 193L157 205L140 217Z" fill={p.light} />
      </>
    );
  if (form === "eclipse")
    return (
      <>
        <>
          <path
            className="pet-arm pet-arm-left"
            d="M89 169Q57 157 53 178Q61 198 84 196"
            fill={p.shade}
          />
          <path
            className="pet-arm pet-arm-right"
            d="M200 167Q229 154 232 175Q225 193 204 196"
            fill={p.shade}
          />
        </>
        <>
          <path
            className="pet-foot pet-foot-left"
            d="M94 217L86 237Q108 243 119 226"
            fill={p.shade}
          />
          <path
            className="pet-foot pet-foot-right"
            d="M165 225Q181 243 196 233L184 211"
            fill={p.shade}
          />
        </>
        <path
          className="pet-torso"
          d="M77 156Q75 95 137 90Q204 89 207 151Q218 205 177 226Q137 246 101 222Q76 204 77 156Z"
          fill={p.body}
        />
        <path
          d="M155 94Q203 98 207 152Q215 203 177 226Q157 236 137 232Q169 214 171 177Q174 130 155 94Z"
          fill="#B7A8C9"
          stroke="none"
        />
        <path
          d="M100 120L105 103L110 120L126 125L110 130L105 145L100 130L85 125Z"
          fill="#FFF3CD"
          stroke="none"
        />
        <path
          d="M131 198L137 190L143 198L155 202L143 208L137 218L131 208L120 202Z"
          fill="#F6E6B7"
          stroke="none"
        />
      </>
    );
  return null;
}
export function SpecialAccessory({ accessory }: { accessory: Accessory }) {
  switch (accessory) {
    case "trailbow":
      return (
        <g fill="#91ADA5">
          <path d="M121 188Q97 170 101 193L124 200Q154 215 158 190L130 191Z" />
          <circle cx="126" cy="194" r="6" fill="#C6DBCC" />
        </g>
      );
    case "dewbadge":
      return (
        <g>
          <circle cx="174" cy="194" r="15" fill="#EBD997" />
          <path d="M174 183Q160 201 174 204Q188 201 174 183Z" fill="#91B6B1" />
        </g>
      );
    case "mooncloak":
    case "batcape":
      return (
        <>
          <path
            d="M95 182L79 234L112 226L140 240L166 227L197 236L179 182Q138 198 95 182Z"
            fill={accessory === "batcape" ? "#6F607C" : "#929CB4"}
          />
          <path
            d="M96 183Q139 198 178 183"
            fill="none"
            stroke="#DAC8A6"
            strokeWidth="5"
          />
          <circle cx="137" cy="196" r="6" fill="#E7D28C" />
        </>
      );
    case "rubytiara":
      return (
        <g>
          <path
            d="M95 106L93 81L115 95L137 70L158 95L180 81L177 107Z"
            fill="#E5C588"
          />
          <path d="M126 91L137 80L148 91L137 105Z" fill="#B65070" />
        </g>
      );
    case "diamondhalo":
      return (
        <g fill="none" stroke="#8EB0C6" strokeWidth="5">
          <ellipse cx="139" cy="70" rx="48" ry="12" />
          <path
            d="M108 66L115 60M158 75L164 70"
            stroke="#EAF5F2"
            strokeWidth="4"
          />
        </g>
      );
    case "voidchains":
      return (
        <g fill="none" stroke="#CEB367" strokeWidth="4">
          {[0, 1, 2, 3, 4].map((n) => (
            <ellipse
              key={n}
              cx={99 + n * 19}
              cy={190 + Math.sin((n / 4) * Math.PI) * 15}
              rx="12"
              ry="8"
              transform={`rotate(${(2 - n) * 12} ${99 + n * 19} ${190 + Math.sin((n / 4) * Math.PI) * 15})`}
            />
          ))}
        </g>
      );
    case "pumpkinhat":
      return (
        <g>
          <path d="M96 107Q97 76 132 74Q174 70 182 107Z" fill="#E5AE77" />
          <path
            d="M118 79Q110 90 114 105M146 77Q160 92 158 105"
            stroke="#BB8759"
            fill="none"
          />
          <path d="M134 74L130 59L141 55L144 75" fill="#72916A" />
        </g>
      );
    case "stitchbow":
      return (
        <g fill="#AE96B4">
          <path d="M137 108Q96 80 103 112L134 119Q168 137 175 105L143 109Z" />
          <circle cx="139" cy="113" r="7" fill="#E5BC91" />
          <path
            d="M109 105L121 112M114 101L112 109M119 106L117 114M153 116L167 111"
            stroke="#F4D5B3"
            strokeWidth="2"
          />
        </g>
      );
    case "candlehat":
      return (
        <g>
          <ellipse cx="138" cy="109" rx="37" ry="8" fill="#A7AAA0" />
          <path d="M122 105V67Q137 60 151 67V106Z" fill="#F1DDAC" />
          <path
            d="M122 72Q128 66 133 78Q140 70 151 73"
            fill="none"
            stroke="#D8BD7E"
          />
          <path
            className="candle-flame"
            d="M137 42Q119 62 137 64Q155 62 137 42Z"
            fill="#EDB275"
          />
        </g>
      );
    case "mooncrown":
      return (
        <g>
          <path
            d="M97 108L91 81L114 96L139 69L161 96L183 81L177 108Z"
            fill="#D7BA76"
          />
          <path d="M140 70L161 96L183 81L177 108H140Z" fill="#A497BE" />
          <path
            d="M137 88Q127 103 142 102Q130 111 126 99Q125 91 137 88Z"
            fill="#FBEDBA"
            stroke="none"
          />
        </g>
      );
    default:
      return null;
  }
}
export function SecretBook() {
  return (
    <g className="pet-secret-book">
      <path
        d="M105 182Q119 176 137 186Q154 175 170 182L167 213Q151 208 137 220Q120 207 105 214Z"
        fill="#765660"
      />
      <path
        d="M110 186Q124 181 137 190Q152 180 165 186L163 207Q150 203 137 214Q122 202 110 208Z"
        fill="#E9D8B5"
      />
      <path
        d="M137 190V215M114 190L127 192M114 197L125 199M147 193L159 189M147 201L159 197"
        stroke="#9A8263"
        fill="none"
        strokeWidth="1.5"
      />
      <path
        d="M91 190Q101 179 113 188M162 187Q179 180 186 192"
        fill="none"
        stroke="#8D786F"
        strokeWidth="8"
      />
    </g>
  );
}
