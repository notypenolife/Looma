"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import {
  ArrowUpRight,
  MessageCircle,
  Hand,
  Cookie,
  Music2,
  Moon,
  BookOpen,
} from "lucide-react";
import { useDemo } from "@/lib/store";
import { getSpecies, type PetEvent } from "@/lib/collection";
import type { Performance } from "@/lib/behaviours";
import { personalityReaction } from "@/lib/personality";
import { LoomaPet } from "./LoomaPet";
import { Badge } from "../ui/shared";
function localHour() {
  return Number(
    new Intl.DateTimeFormat("en-NZ", {
      timeZone: "Pacific/Auckland",
      hour: "numeric",
      hourCycle: "h23",
    }).format(new Date()),
  );
}
export function PetPlayground() {
  const { pet, student, feedback } = useDemo();
  const [event, setEvent] = useState<PetEvent>("hello");
  const [hour, setHour] = useState(12);
  const [motion, setMotion] = useState(0);
  const [seenFeedback, setSeenFeedback] = useState(feedback?.id);
  if (feedback?.id !== seenFeedback) {
    setSeenFeedback(feedback?.id);
    if (feedback) {
      setEvent(feedback.event);
      setMotion((n) => n + 1);
    }
  }
  const [acting, setActing] = useState<Performance | null>(null);
  const complete = student.tasks.filter((t) => t.complete).length;
  const [seenComplete, setSeenComplete] = useState(complete);
  // React to a task finished in this session, without coupling collection state to school records.
  if (complete !== seenComplete) {
    setSeenComplete(complete);
    if (complete > seenComplete) {
      setEvent("task");
      setMotion((m) => m + 1);
    }
  }
  useEffect(() => {
    const update = () => setHour(localHour());
    update();
    const id = setInterval(update, 60000);
    return () => clearInterval(id);
  }, []);
  useEffect(() => {
    if (event === "hello") return;
    const timer = setTimeout(() => setEvent("hello"), 7000);
    return () => clearTimeout(timer);
  }, [event, motion]);
  const reaction = personalityReaction(pet.form, event, hour, motion);
  const s = getSpecies(pet.form);
  function interact(next: PetEvent) {
    setEvent(next);
    setMotion((m) => m + 1);
  }
  return (
    <section className="companion-card pet-playground">
      <div className="companion-card-top">
        <Badge tone="sage">YOUR {s.element.toUpperCase()} LOOMA</Badge>
        <Link
          href="/student/looma"
          className="icon-button"
          aria-label="Customise your Looma"
        >
          <ArrowUpRight size={19} />
        </Link>
      </div>
      <div className="companion-scene">
        <div className="scene-circle" />
        <button
          className="pet-touch"
          onClick={() => interact("hello")}
          aria-label={`Say hello to ${pet.name}`}
        >
          <LoomaPet
            {...pet}
            onPerformance={setActing}
            cue={motion ? { id: `interaction-${motion}`, event } : undefined}
          />
        </button>
        <span className="scene-seed seed-one" />
        <span className="scene-seed seed-two" />
      </div>
      <h2>
        {pet.name}, your little {s.name}.
      </h2>
      <span className="pet-personality">
        {s.personality} ·{" "}
        {hour >= 21 || hour < 6
          ? "Moonlight hours"
          : hour < 12
            ? "Morning light"
            : "A little daytime company"}
      </span>
      <p className="companion-message" aria-live="polite">
        {acting?.line ?? reaction.line}
      </p>
      <div
        className="pet-action-buttons"
        role="group"
        aria-label="Spend a moment with your Looma"
      >
        {(
          [
            { id: "hello", label: "Wave", icon: Hand },
            { id: "snack", label: "Snack", icon: Cookie },
            { id: "play", label: "Play", icon: Music2 },
            { id: "focus", label: "Focus", icon: BookOpen },
            { id: "rest", label: "Rest", icon: Moon },
          ] as const
        ).map(({ id, label, icon: Icon }) => (
          <button
            key={id}
            onClick={() => interact(id)}
            aria-pressed={event === id}
          >
            <Icon size={17} />
            <span>{label}</span>
          </button>
        ))}
      </div>
      <Link href="/student/chat" className="button button-dark companion-chat">
        <MessageCircle size={17} />
        Let’s talk
        <ArrowUpRight size={17} />
      </Link>
      <p className="pet-hint">Always glad to see you. No attention to earn.</p>
    </section>
  );
}
