import type { Accessory, PetForm } from "@/lib/types";
import { petRigs } from "@/lib/pet-rig";
export function FittedAccessory({
  form,
  accessory,
  layer,
  uid,
}: {
  form: PetForm;
  accessory: Accessory;
  layer: "back" | "torso" | "head";
  uid: string;
}) {
  const r = petRigs[form],
    x = r.headX,
    n = r.neckY,
    w = r.shoulder;
  const cloak = accessory === "mooncloak" || accessory === "batcape";
  const chain = accessory === "voidchains";
  const gradient = `chain-metal-${uid}`,
    shadow = `chain-edge-${uid}`;
  if (layer === "back")
    return (
      <g className="accessory-back" data-fit={form}>
        {cloak && (
          <path
            d={`M${x - w} ${n - 8}Q${x} ${n - 27} ${x + w} ${n - 8}L${x + w + 11} 237Q${x + 28} 229 ${x + 10} 243L${x - 14} 235L${x - w - 14} 239Z`}
            fill={accessory === "batcape" ? "#65536D" : "#7F91A2"}
            stroke="#514D5C"
          />
        )}
        {(accessory === "scarf" || chain) && (
          <path
            d={`M${x - w - 2} ${n - 4}Q${x} ${n - 24} ${x + w + 2} ${n - 4}L${x + w + 4} ${n + 10}Q${x} ${n - 4} ${x - w - 4} ${n + 10}Z`}
            fill={chain ? "#3A3035" : "#B5795E"}
          />
        )}
        {chain && (
          <g fill="none" stroke="#71604B" strokeWidth="4">
            {[-1, 1].flatMap((side) =>
              [0, 1, 2].map((i) => (
                <ellipse
                  key={`${side}-${i}`}
                  cx={x + side * (w + 5 + i * 2)}
                  cy={n + i * 15}
                  rx="7"
                  ry="11"
                  transform={`rotate(${side * 14} ${x + side * (w + 5 + i * 2)} ${n + i * 15})`}
                />
              )),
            )}
          </g>
        )}
        {accessory === "satchel" && (
          <path
            d={`M${x - w + 4} ${n - 8}L${x + w + 3} 223`}
            fill="none"
            stroke="#705A44"
            strokeWidth="8"
          />
        )}
      </g>
    );
  if (layer === "torso")
    return (
      <g className="accessory-torso" data-fit={form}>
        {accessory === "scarf" && (
          <>
            <path
              d={`M${x - w} ${n}Q${x} ${n + 22} ${x + w} ${n}L${x + w} ${n + 12}Q${x} ${n + 32} ${x - w} ${n + 12}Z`}
              fill="#D29173"
            />
            <path
              d={`M${x + 19} ${n + 17}L${x + 38} ${n + 19}L${x + 32} 231L${x + 14} 227Z`}
              fill="#C28061"
            />
            <path
              d={`M${x + 17} 219L${x + 33} 222`}
              stroke="#F2CFAC"
              strokeWidth="3"
            />
          </>
        )}
        {cloak && (
          <>
            <path
              d={`M${x - w + 1} ${n}Q${x} ${n + 18} ${x + w - 1} ${n}L${x + w - 5} ${n + 10}Q${x} ${n + 26} ${x - w + 5} ${n + 10}Z`}
              fill={accessory === "batcape" ? "#8E7997" : "#ADBCC7"}
            />
            <path
              d={`M${x - 6} ${n + 15}L${x} ${n + 9}L${x + 7} ${n + 15}L${x} ${n + 22}Z`}
              fill="#E7CC8A"
            />
          </>
        )}
        {accessory === "satchel" && (
          <>
            <path
              d={`M${x - w + 4} ${n - 8}L${x + w} 218`}
              fill="none"
              stroke="#9C7951"
              strokeWidth="6"
            />
            <rect
              x={x + w - 15}
              y="201"
              width="30"
              height="30"
              rx="7"
              fill="#C1A078"
            />
            <path d={`M${x + w - 14} 209H${x + w + 14}`} stroke="#806347" />
            <rect
              x={x + w - 3}
              y="209"
              width="7"
              height="7"
              rx="2"
              fill="#EAD6A9"
            />
          </>
        )}
        {chain && (
          <>
            <defs>
              <linearGradient id={gradient} x1="0" y1="0" x2=".7" y2="1">
                <stop offset="0" stopColor="#25252D" />
                <stop offset=".24" stopColor="#8D7854" />
                <stop offset=".45" stopColor="#9C8558" />
                <stop offset=".58" stopColor="#4D3D41" />
                <stop offset=".8" stopColor="#783F3D" />
                <stop offset="1" stopColor="#24242C" />
              </linearGradient>
              <linearGradient id={shadow}>
                <stop stopColor="#6C5B44" />
                <stop offset="1" stopColor="#563136" />
              </linearGradient>
            </defs>
            <path
              d={`M${x - w + 3} ${n + 1}Q${x} ${n + 53} ${x + w - 3} ${n + 1}`}
              fill="none"
              stroke="#241F27"
              strokeWidth="8"
            />
            {[0, 1, 2, 3, 4, 5, 6].map((i) => {
              const t = i / 6,
                cx = x - w + 5 + (w * 2 - 10) * t,
                cy = n + 5 + Math.sin(t * Math.PI) * 24,
                angle = (0.5 - t) * 65;
              return (
                <g key={i} transform={`rotate(${angle} ${cx} ${cy})`}>
                  <ellipse
                    cx={cx}
                    cy={cy}
                    rx={i % 2 ? 7 : 11}
                    ry={i % 2 ? 11 : 7}
                    fill="none"
                    stroke={`url(#${shadow})`}
                    strokeWidth="6"
                  />
                  <ellipse
                    cx={cx}
                    cy={cy}
                    rx={i % 2 ? 7 : 11}
                    ry={i % 2 ? 11 : 7}
                    fill="none"
                    stroke={`url(#${gradient})`}
                    strokeWidth="4"
                  />
                  <path
                    d={`M${cx - 3} ${cy - 6}L${cx + 3} ${cy - 5}`}
                    stroke="#AF9964"
                    strokeWidth="1.2"
                  />
                </g>
              );
            })}
            <path
              d={`M${x} ${n + 27}L${x + 6} ${n + 34}L${x} ${n + 42}L${x - 6} ${n + 34}Z`}
              fill="#8E4A47"
              stroke="#C1A268"
              strokeWidth="1.5"
            />
          </>
        )}
        {(accessory === "starpin" || accessory === "dewbadge") && (
          <g transform={`translate(${x + w - 18} ${n + 6})`}>
            <circle r="12" fill="#DCC38A" />
            <path
              d={
                accessory === "dewbadge"
                  ? "M0-8Q-12 6 0 8Q12 6 0-8Z"
                  : "M0-9L3-3L10-2L5 3L6 10L0 7L-6 10L-5 3L-10-2L-3-3Z"
              }
              fill={accessory === "dewbadge" ? "#94B6AE" : "#F7E9BF"}
              strokeWidth="1"
            />
          </g>
        )}
        {accessory === "trailbow" && (
          <g transform={`translate(${x} ${n + 10})`}>
            <path
              d="M-4 0Q-28-19-29 0Q-29 15-4 6Q23 22 28 0Q29-17 4 0Z"
              fill="#95B1A4"
            />
            <circle r="5" cy="3" fill="#C8DCD0" />
          </g>
        )}
      </g>
    );
  if (accessory === "glasses")
    return (
      <g
        className="accessory-head"
        fill="none"
        stroke="#534E48"
        strokeWidth="3"
      >
        <rect x="98" y="136" width="31" height="27" rx="10" />
        <rect x="141" y="136" width="31" height="27" rx="10" />
        <path
          d={`M129 147Q135 143 141 147M98 145L${x - r.headWidth / 2 + 1} 141M172 145L${x + r.headWidth / 2 - 1} 141`}
        />
      </g>
    );
  if (accessory === "headphones")
    return (
      <g className="accessory-head">
        <path
          d={`M${x - r.headWidth / 2} 154Q${x - r.headWidth / 2 - 5} ${r.headY - 20} ${x} ${r.headY - 23}Q${x + r.headWidth / 2 + 4} ${r.headY - 20} ${x + r.headWidth / 2} 154`}
          fill="none"
          stroke="#77748D"
          strokeWidth="9"
        />
        <rect
          x={x - r.headWidth / 2 - 6}
          y="141"
          width="17"
          height="32"
          rx="8"
          fill="#C2B8D1"
        />
        <rect
          x={x + r.headWidth / 2 - 11}
          y="141"
          width="17"
          height="32"
          rx="8"
          fill="#C2B8D1"
        />
      </g>
    );
  const transform = `translate(${x - 138} ${r.headY - 108}) rotate(${r.hatTilt} 138 108) translate(138 108) scale(${r.headWidth / 104} 1) translate(-138 -108)`;
  return (
    <g className="accessory-head" transform={transform} data-fit={form}>
      {accessory === "bow" && (
        <g fill="#D198AD">
          <path d="M135 105Q98 81 103 109Q107 125 135 111Q168 129 174 107Q179 83 141 105Z" />
          <circle cx="138" cy="109" r="7" fill="#F2CED0" />
        </g>
      )}
      {accessory === "leafhat" && (
        <>
          <path d="M89 109Q117 63 187 86Q179 112 89 109Z" fill="#92B489" />
          <path d="M94 108L171 88" stroke="#567B58" fill="none" />
        </>
      )}
      {(accessory === "crown" ||
        accessory === "rubytiara" ||
        accessory === "mooncrown") && (
        <>
          <path
            d="M96 111L92 83L115 98L137 74L159 98L181 83L177 111Z"
            fill="#DEC584"
          />
          <path d="M100 106H174" stroke="#A88749" />
          {accessory === "rubytiara" ? (
            <path d="M127 94L137 83L148 94L137 105Z" fill="#A84A65" />
          ) : accessory === "mooncrown" ? (
            <path d="M139 76L159 98L181 83L177 111H139Z" fill="#9686AD" />
          ) : (
            <circle cx="137" cy="98" r="5" fill="#D8A27D" />
          )}
        </>
      )}
      {accessory === "diamondhalo" && (
        <ellipse
          cx="138"
          cy="81"
          rx="43"
          ry="10"
          fill="none"
          stroke="#98BECD"
          strokeWidth="5"
        />
      )}
      {accessory === "pumpkinhat" && (
        <>
          <path d="M94 109Q97 78 133 78Q173 76 182 109Z" fill="#DCAA74" />
          <path
            d="M119 83Q112 96 116 108M149 82Q162 94 159 107"
            stroke="#B28157"
            fill="none"
          />
          <path d="M135 78L132 64L143 60L145 79" fill="#6C9269" />
        </>
      )}
      {accessory === "stitchbow" && (
        <g fill="#AB91B1">
          <path d="M135 108Q97 84 103 112L134 119Q168 134 175 107L142 110Z" />
          <circle cx="138" cy="113" r="7" fill="#E3BE94" />
          <path
            d="M108 105L123 112M114 102L111 111M121 106L118 115M152 118L168 112"
            stroke="#F5DABD"
            strokeWidth="2"
          />
        </g>
      )}
      {accessory === "candlehat" && (
        <>
          <ellipse cx="138" cy="110" rx="34" ry="7" fill="#AAA59A" />
          <path d="M123 107V74Q137 67 151 74V107Z" fill="#EDD9AC" />
          <path
            d="M124 79Q130 74 135 85Q142 76 151 80"
            stroke="#C7AF7D"
            fill="none"
          />
          <path d="M137 51Q121 70 137 72Q153 70 137 51Z" fill="#DCA66E" />
        </>
      )}
    </g>
  );
}
