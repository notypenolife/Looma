import type { Expression, PetForm } from "@/lib/types";
import { presence } from "@/lib/embodiment";
export function PetFace({
  form,
  expression,
  wink,
  turn,
  eating,
}: {
  form: PetForm;
  expression: Expression;
  wink: boolean;
  turn: boolean;
  eating: boolean;
}) {
  const p = presence[form],
    ink = form === "void" ? "#E5CE8A" : "#3F4941";
  const sleepy = expression === "sleepy",
    pleased = expression === "celebrating";
  const gaze =
    expression === "thinking" ? -2 : expression === "curious" ? 3 : p.gaze;
  const height =
    p.eyes === "droop"
      ? 4.7
      : p.eyes === "wide"
        ? 8.2
        : p.eyes === "almond"
          ? 6.2
          : 7;
  return (
    <g
      className={`pet-face face-${p.eyes} ${sleepy ? "face-asleep" : ""}`}
      stroke={ink}
      data-expression={expression}
    >
      <g className={sleepy ? "eyes-closed" : "pet-eyes"}>
        {[114, 155].map((x, i) => (
          <g key={x} className={`pet-eye eye-${i}`}>
            {sleepy || pleased || (wink && i === 1) ? (
              <path
                d={`M${x - 7} 151Q${x} ${sleepy ? 158 : 140} ${x + 7} 151`}
                fill="none"
                strokeWidth="3.4"
              />
            ) : (
              <>
                <ellipse
                  cx={x}
                  cy="150"
                  rx={turn && i === 0 ? 4 : p.eyes === "wide" ? 6.5 : 5.4}
                  ry={height}
                  fill={ink}
                  stroke="none"
                />
                {p.eyes === "droop" && (
                  <path
                    d={`M${x - 7} 146L${x + 6} 148`}
                    fill="none"
                    strokeWidth="2"
                  />
                )}
                <circle
                  className="pet-gaze"
                  cx={x + gaze / 2}
                  cy="147.8"
                  r="1.8"
                  fill="#FFFBEA"
                  stroke="none"
                />
              </>
            )}
            <path
              className="pet-brow"
              d={`M${x - 8} ${134 + (i ? p.brow : -p.brow)}Q${x} ${130 + (expression === "curious" && i === 0 ? -5 : p.brow)} ${x + 7} 134`}
              fill="none"
              strokeWidth="2"
              opacity={sleepy ? 0.25 : 0.75}
            />
          </g>
        ))}
      </g>
      <g className="pet-cheeks" fill="#D79488" stroke="none" opacity=".5">
        <ellipse cx="98" cy="166" rx="8" ry="4" />
        <ellipse cx="174" cy="166" rx="8" ry="4" />
      </g>
      <g className={`pet-muzzle ${eating ? "muzzle-chew" : ""}`}>
        {form === "pip" ? (
          <path
            d="M126 162L138 158L146 166L134 175Z"
            fill="#D7A160"
            strokeWidth="2"
          />
        ) : expression === "curious" ? (
          <ellipse cx="136" cy="171" rx="4" ry="5" fill={ink} stroke="none" />
        ) : expression === "thinking" || (p.eyes === "droop" && !pleased) ? (
          <path d="M129 172Q136 174 143 170" fill="none" strokeWidth="2.5" />
        ) : (
          <path
            d={
              sleepy
                ? "M131 173Q136 176 141 172"
                : form === "fiend"
                  ? "M124 168Q135 179 147 163"
                  : "M125 167Q136 181 146 167"
            }
            fill={pleased ? "#C48780" : "none"}
            strokeWidth="2.5"
          />
        )}
        {form === "fiend" && !sleepy && (
          <path d="M140 170L141 176L146 167" fill="#F5E8CB" strokeWidth="1" />
        )}
      </g>
    </g>
  );
}
