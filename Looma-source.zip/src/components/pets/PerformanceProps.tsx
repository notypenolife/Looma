import type { Performance } from "@/lib/behaviours";
export function PerformanceProps({
  performance,
}: {
  performance: Performance | null;
}) {
  if (!performance || performance.prop === "none") return null;
  const prop = performance.prop;
  return (
    <g
      className={`performance-prop prop-${prop}`}
      stroke="#655F50"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      {prop === "book" && (
        <>
          <path
            d="M102 187Q118 179 137 190Q154 178 174 186L171 218Q154 212 138 225Q119 213 103 219Z"
            fill="#6E6178"
          />
          <path
            d="M108 190Q121 184 137 194Q153 183 168 190L165 212Q153 208 138 219Q122 208 108 214Z"
            fill="#EADFC5"
          />
          <path
            d="M138 194V219M114 194L126 197M114 202L127 205M149 197L161 193M149 205L161 201"
            fill="none"
            strokeWidth="1.2"
          />
          <path
            className="performance-page"
            d="M138 193Q153 183 167 189L164 211Q152 208 138 219Z"
            fill="#F4EAD1"
          />
          <path
            d="M91 202Q99 189 110 199M167 198Q183 188 190 202"
            fill="none"
            stroke="#9B9380"
            strokeWidth="9"
          />
        </>
      )}
      {prop === "note" && (
        <>
          <path d="M111 190L170 185L175 226L115 231Z" fill="#F2E6CB" />
          <path
            d="M127 209L137 217L157 199"
            stroke="#6D8F6D"
            strokeWidth="4"
            fill="none"
          />
          <path
            d="M99 213L114 209M175 207L187 213"
            stroke="#9EAD98"
            strokeWidth="9"
          />
        </>
      )}
      {prop === "leaf" && (
        <>
          <path d="M165 204Q167 180 196 184Q197 204 167 213Z" fill="#A1BF8D" />
          <path d="M167 213L187 190" fill="none" />
        </>
      )}
      {prop === "pencil" && (
        <>
          <path d="M165 220L181 182L188 185L173 223L166 229Z" fill="#DBBC7D" />
          <path d="M165 220L173 223L166 229Z" fill="#ECE4CB" />
        </>
      )}
      {prop === "stone" && (
        <path
          d="M167 218Q155 199 173 191Q191 188 198 205Q201 221 181 226Z"
          fill="#B7B8AD"
        />
      )}
      {prop === "gear" && (
        <g fill="#C9A779">
          <path d="M170 190L176 186L182 192L190 190L195 198L190 204L193 212L184 217L179 212L171 216L165 208L169 202L163 196Z" />
          <circle cx="179" cy="201" r="6" fill="#F0DFC3" />
        </g>
      )}
      {prop === "bell" && (
        <g fill="#BCCDD2">
          <path d="M165 212Q170 208 169 199Q170 187 181 187Q194 190 192 203L195 215Z" />
          <circle cx="180" cy="218" r="4" />
        </g>
      )}
      {prop === "gem" && (
        <g>
          <path d="M166 202L175 188L190 191L199 207L181 223Z" fill="#BFD9DF" />
          <path
            d="M175 189L181 222L190 192M166 202L198 207"
            stroke="#83A4B4"
            fill="none"
          />
        </g>
      )}
      {prop === "cup" && (
        <g>
          <path d="M165 195H190L187 218Q176 223 167 216Z" fill="#D8C7AB" />
          <path d="M190 198Q209 196 196 211H189" fill="none" />
          <path
            d="M173 185Q168 177 176 172M184 185Q178 178 185 174"
            fill="none"
            stroke="#BDBCAF"
          />
        </g>
      )}
      {prop === "star" && (
        <path
          d="M183 183L189 195L203 197L193 208L194 221L182 215L170 221L173 207L163 197L177 194Z"
          fill="#E7CD84"
        />
      )}
      {prop === "crumb" && (
        <g fill="#D6B58C">
          <path d="M173 199L185 193L195 203L188 217L173 213Z" />
          <circle cx="177" cy="223" r="2" />
          <circle cx="199" cy="217" r="2" />
        </g>
      )}
      {prop === "wand" && (
        <>
          <path d="M166 226L190 188" stroke="#9A7C9C" strokeWidth="5" />
          <path
            d="M192 175L196 183L206 186L198 193L196 202L187 196L177 196L182 187L181 178Z"
            fill="#E4CF90"
          />
        </>
      )}
      {prop === "lantern" && (
        <>
          <path d="M174 193Q174 179 185 180Q197 181 195 194" fill="none" />
          <path d="M172 194H198L195 219H175Z" fill="#D4B16F" />
          <path d="M178 198H192V215H179Z" fill="#F6E4A7" />
        </>
      )}
    </g>
  );
}
