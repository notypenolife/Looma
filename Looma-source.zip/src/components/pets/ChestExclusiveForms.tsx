import type { PetForm } from "@/lib/types";
export function ChestExclusiveForm({ form }: { form: PetForm }) {
  if (form === "twig")
    return (
      <>
        <>
          <path
            className="pet-crest pet-crest-left"
            d="M105 99L94 62L111 74L124 95"
            fill="#97AE81"
          />
          <path
            className="pet-crest pet-crest-right"
            d="M158 95L175 65L180 80L174 109"
            fill="#97AE81"
          />
        </>
        <>
          <path
            className="pet-foot pet-foot-left"
            d="M94 218L88 237Q107 243 118 225"
            fill="#A28E6D"
          />
          <path
            className="pet-foot pet-foot-right"
            d="M164 224L189 238L184 217"
            fill="#A28E6D"
          />
        </>
        <path
          className="pet-torso"
          d="M82 145Q88 104 130 94L172 108Q202 121 199 171L191 213Q167 236 127 230L92 218Z"
          fill="#CDB897"
        />
        <path
          d="M94 129L104 119M178 132L185 148M99 199L108 215M174 202L182 188"
          stroke="#AA906B"
          strokeWidth="4"
        />
        <path
          d="M114 206Q139 196 161 209"
          stroke="#E7D7B5"
          fill="none"
          strokeWidth="9"
        />
        <>
          <path
            className="pet-arm pet-arm-left"
            d="M83 176Q57 165 59 184Q65 201 88 198"
            fill="#CDB897"
          />
          <path
            className="pet-arm pet-arm-right"
            d="M194 177Q222 164 222 184Q215 200 197 199"
            fill="#CDB897"
          />
        </>
      </>
    );
  if (form === "copper")
    return (
      <>
        <path
          className="pet-crest pet-crest-left"
          d="M121 100L110 82L125 81L130 67L146 74L159 66L163 83L179 88L165 106"
          fill="#B3926F"
        />
        <>
          <path
            className="pet-foot pet-foot-left"
            d="M95 216L88 237Q107 245 120 225"
            fill="#A78666"
          />
          <path
            className="pet-foot pet-foot-right"
            d="M165 225Q182 244 196 234L183 215"
            fill="#A78666"
          />
        </>
        <path
          className="pet-torso"
          d="M77 150Q76 106 124 100H161Q204 107 205 151V186Q198 229 140 233Q80 229 77 185Z"
          fill="#CDB093"
        />
        <>
          <path
            className="pet-arm pet-arm-left"
            d="M80 154L60 149L50 161V186L77 194"
            fill="#AD8C70"
          />
          <path
            className="pet-arm pet-arm-right"
            d="M202 155L225 150L236 163V185L207 193"
            fill="#AD8C70"
          />
        </>
        <circle cx="91" cy="137" r="4" fill="#E4CAA6" />
        <circle cx="191" cy="136" r="4" fill="#E4CAA6" />
        <path d="M118 204H163" stroke="#E8D6B5" strokeWidth="10" />
        <circle cx="141" cy="204" r="7" fill="#A48669" />
      </>
    );
  if (form === "silverling")
    return (
      <>
        <>
          <path
            className="pet-crest pet-crest-left"
            d="M102 111Q82 75 102 49Q122 69 122 101"
            fill="#B8C9CF"
          />
          <path
            className="pet-crest pet-crest-right"
            d="M155 101Q159 67 178 53Q196 80 178 117"
            fill="#B8C9CF"
          />
        </>
        <>
          <path
            className="pet-crest pet-crest-left"
            d="M105 63L113 94"
            stroke="#E5ECE5"
            strokeWidth="6"
          />
          <path
            className="pet-crest pet-crest-right"
            d="M176 69L165 96"
            stroke="#E5ECE5"
            strokeWidth="6"
          />
        </>
        <>
          <path
            className="pet-foot pet-foot-left"
            d="M96 215L90 237L115 226"
            fill="#92ABB5"
          />
          <path
            className="pet-foot pet-foot-right"
            d="M166 224L190 237L184 214"
            fill="#92ABB5"
          />
        </>
        <path
          className="pet-torso"
          d="M82 145Q91 102 135 98Q188 97 200 144L208 214Q182 223 171 214Q139 239 109 217L75 221Z"
          fill="#C7D4D7"
        />
        <>
          <path
            className="pet-arm pet-arm-left"
            d="M79 173Q55 161 55 183L81 196"
            fill="#B5C5CD"
          />
          <path
            className="pet-arm pet-arm-right"
            d="M204 173Q229 163 230 183L202 198"
            fill="#B5C5CD"
          />
        </>
        <path d="M125 201Q134 188 145 199L151 216H120Z" fill="#EEF0DC" />
        <circle cx="136" cy="219" r="4" fill="#97ADB1" />
      </>
    );
  if (form === "plume")
    return (
      <>
        <path
          className="pet-crest pet-crest-left"
          d="M123 106Q101 89 119 69Q146 50 158 77Q159 93 143 96Q131 94 139 81"
          fill="#ACCCC0"
        />
        <>
          <path
            className="pet-foot pet-foot-left"
            d="M99 215Q75 228 94 239L121 225"
            fill="#86ADA4"
          />
          <path
            className="pet-foot pet-foot-right"
            d="M165 224Q185 243 201 231L182 214"
            fill="#86ADA4"
          />
        </>
        <path
          className="pet-torso"
          d="M79 150Q82 109 123 100Q173 88 196 124Q215 148 204 184Q201 220 168 231Q123 244 95 216Q73 191 79 150Z"
          fill="#BBD7CE"
        />
        <>
          <path
            className="pet-arm pet-arm-left"
            d="M90 174Q60 162 60 180Q61 197 89 200"
            fill="#A3C5BB"
          />
          <path
            className="pet-arm pet-arm-right"
            d="M202 168Q229 153 234 170Q233 190 206 196"
            fill="#A3C5BB"
          />
        </>
        <path
          d="M113 215Q130 189 159 200Q181 210 165 225Q139 234 113 215Z"
          fill="#DCE9DD"
        />
        <circle cx="146" cy="212" r="10" fill="#EEF0DF" />
      </>
    );
  if (form === "sol")
    return (
      <>
        <g fill="#D8B86C">
          {[0, 1, 2, 3, 4, 5, 6, 7].map((i) => (
            <ellipse
              key={i}
              cx="139"
              cy="100"
              rx="18"
              ry="36"
              transform={`rotate(${i * 45} 139 154)`}
            />
          ))}
        </g>
        <>
          <path
            className="pet-foot pet-foot-left"
            d="M96 214L86 236Q107 245 122 226"
            fill="#BFA05D"
          />
          <path
            className="pet-foot pet-foot-right"
            d="M165 225Q182 245 198 233L184 213"
            fill="#BFA05D"
          />
        </>
        <path
          className="pet-torso"
          d="M79 152Q80 109 133 103Q189 98 201 145Q217 199 184 222Q142 243 102 221Q77 202 79 152Z"
          fill="#ECD89F"
        />
        <>
          <path
            className="pet-arm pet-arm-left"
            d="M82 176Q57 166 56 184Q63 202 86 198"
            fill="#E0C37D"
          />
          <path
            className="pet-arm pet-arm-right"
            d="M202 176Q227 162 231 181Q228 199 203 199"
            fill="#E0C37D"
          />
        </>
        <path
          d="M121 203Q136 190 157 204Q151 221 138 222Q124 218 121 203Z"
          fill="#F6E8B8"
        />
      </>
    );
  if (form === "facet")
    return (
      <>
        <path
          className="pet-crest pet-crest-left"
          d="M97 115L86 79L119 97L139 61L160 96L188 78L180 119"
          fill="#BBDAE3"
        />
        <>
          <path
            className="pet-foot pet-foot-left"
            d="M94 216L84 236L117 226"
            fill="#8EAFBD"
          />
          <path
            className="pet-foot pet-foot-right"
            d="M164 224L195 234L183 213"
            fill="#8EAFBD"
          />
        </>
        <path
          className="pet-torso"
          d="M78 147L102 108L145 96L185 116L204 155L198 198L168 228L125 233L91 211Z"
          fill="#BFD9E4"
        />
        <path
          d="M102 108L112 131M185 116L175 133M91 211L113 195M168 228L158 205"
          fill="none"
          stroke="#8DB0BF"
        />
        <>
          <path
            className="pet-arm pet-arm-left"
            d="M78 176L56 169L52 191L87 201"
            fill="#ACCCD6"
          />
          <path
            className="pet-arm pet-arm-right"
            d="M202 173L226 164L233 186L201 202"
            fill="#ACCCD6"
          />
        </>
        <path d="M137 186L153 204L138 223L121 204Z" fill="#E3EFF0" />
        <path d="M138 187V223M122 204H151" stroke="#A9CCD9" strokeWidth="1.5" />
      </>
    );
  return null;
}
