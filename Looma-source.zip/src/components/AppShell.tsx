"use client";
import { usePathname } from "next/navigation";
import Link from "next/link";
import {
  House,
  MessageCircle,
  BookOpen,
  CalendarDays,
  Sprout,
  Store,
  Flag,
  Gift,
  Send,
  Settings,
  ClipboardCheck,
  ListChecks,
  FileText,
  ArrowLeftRight,
  ChevronDown,
  Bell,
  ArrowUpRight,
} from "lucide-react";
import { Celebration } from "./rewards/Celebration";
import { Logo } from "./ui/shared";
import { useDemo } from "@/lib/store";
const studentNav = [
  { href: "/student", label: "My day", icon: House },
  { href: "/student/chat", label: "Talk to Looma", icon: MessageCircle },
  { href: "/student/missions", label: "Missions", icon: Flag },
  { href: "/student/chests", label: "Earned chests", icon: Gift },
  { href: "/student/homework", label: "Homework", icon: BookOpen },
  { href: "/student/schedule", label: "Schedule & school", icon: CalendarDays },
  { href: "/student/looma", label: "My Looma", icon: Sprout },
  { href: "/student/shop", label: "Little shop", icon: Store },
];
const staffNav = [
  {href:"/staff/missions",label:"Reward missions",icon:Flag},
  { href: "/staff", label: "Overview", icon: House },
  { href: "/staff/inspections", label: "Room checks", icon: ClipboardCheck },
  { href: "/staff/submissions", label: "Demo hand-ins", icon: Send },
  { href: "/staff/tasks", label: "Follow-up tasks", icon: ListChecks },
  { href: "/staff/detentions", label: "Detentions", icon: FileText },
  { href: "/staff/notices", label: "House notices", icon: CalendarDays },
];
export function AppShell({
  role,
  children,
}: {
  role: "student" | "staff";
  children: React.ReactNode;
}) {
  const path = usePathname();
  const isStaff = role === "staff";
  const nav = isStaff ? staffNav : studentNav;
  const { persistenceError } = useDemo();
  return (
    <div className={`app-shell ${isStaff ? "staff-shell" : ""}`}>
      <Celebration />
      <a href="#main-content" className="skip-link">
        Skip to content
      </a>
      <aside className="sidebar">
        <Logo light />
        <div className="school-switch">
          <span className="school-symbol">W</span>
          <div>
            <strong>Willowmere Academy</strong>
            <small>{isStaff ? "Boarding staff" : "Student space"}</small>
          </div>
          <ChevronDown size={14} aria-hidden="true" />
        </div>
        <p className="nav-label">
          {isStaff ? "BOARDING OPERATIONS" : "A LITTLE MORE ORGANISED"}
        </p>
        <nav aria-label={`${role} navigation`}>
          {nav.map(({ href, label, icon: Icon }) => (
            <Link
              key={href}
              href={href}
              aria-current={path === href ? "page" : undefined}
              className={`nav-item ${path === href ? "active" : ""}`}
            >
              <Icon size={19} strokeWidth={1.7} />
              <span>{label}</span>
              {path === href && <span className="nav-dot" />}
            </Link>
          ))}
        </nav>
        <div className="sidebar-bottom">
          <div className="sidebar-note">
            <span className="tiny-leaf">✳</span>
            <p>
              {isStaff
                ? "More time for the people. Less time on the paperwork."
                : "Small steps. A little breathing room. You’ve got today."}
            </p>
          </div>
          <Link
            href={`/${role}/settings`}
            className={`nav-item ${path.endsWith("/settings") ? "active" : ""}`}
          >
            <Settings size={18} />
            Settings
          </Link>
          <Link
            href={isStaff ? "/student" : "/staff"}
            className="nav-item demo-switch"
          >
            <ArrowLeftRight size={17} />
            {isStaff ? "Explore student demo" : "Explore staff demo"}
          </Link>
          <div className="profile-row">
            <span className="avatar">{isStaff ? "MT" : "AR"}</span>
            <div>
              <strong>{isStaff ? "Morgan Thompson" : "Alex Rivers"}</strong>
              <small>
                {isStaff ? "Duty staff · Fictional" : "Year 11 · Kōwhai house"}
              </small>
            </div>
          </div>
        </div>
      </aside>
      <div className="app-body">
        <header className="topbar">
          <div className="mobile-logo">
            <Logo />
          </div>
          <div className="breadcrumb">
            {isStaff ? "Boarding" : "Your space"}
            <span>/</span>
            {[...nav, { href: `/${role}/settings`, label: "Settings" }].find(
              (n) => n.href === path,
            )?.label || "Overview"}
          </div>
          <div className="topbar-right">
            <span className="demo-indicator">
              <span />
              Fictional demo
            </span>
            <Link
              href={isStaff ? "/staff/notices" : "/student/schedule"}
              className="icon-button"
              aria-label="View school notices"
            >
              <Bell size={19} />
            </Link>
            <span className="avatar avatar-small">{isStaff ? "MT" : "AR"}</span>
          </div>
        </header>
        {persistenceError && (
          <div className="storage-warning" role="alert">
            Browser storage is unavailable. Changes will last for this tab only.
          </div>
        )}
        <main id="main-content" className="main-content">
          {children}
          <footer className="app-footer">
            <span>Looma · A little room to grow.</span>
            <span>
              Fictional data · Saved only in this browser{" "}
              <ArrowUpRight size={12} />
            </span>
          </footer>
        </main>
        <nav className="mobile-nav" aria-label="Mobile navigation">
          {nav.map(({ href, label, icon: Icon }) => (
            <Link
              key={href}
              href={href}
              aria-label={label}
              aria-current={path === href ? "page" : undefined}
              className={path === href ? "active" : ""}
            >
              <Icon size={21} />
              <span>
                {label === "Schedule & school"
                  ? "Schedule"
                  : label === "Talk to Looma"
                    ? "Chat"
                    : label === "Follow-up tasks"
                      ? "Tasks"
                      : label === "House notices"
                        ? "Notices"
                        : label}
              </span>
            </Link>
          ))}
          <Link
            href={`/${role}/settings`}
            aria-label="Settings"
            className={path.endsWith("/settings") ? "active" : ""}
          >
            <Settings size={21} />
            <span>Settings</span>
          </Link>
        </nav>
      </div>
    </div>
  );
}
