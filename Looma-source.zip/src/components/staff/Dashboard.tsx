"use client";
import Link from "next/link";
import {
  ClipboardCheck,
  ArrowUpRight,
  Check,
  Clock3,
  ArrowRight,
  CircleAlert,
  Leaf,
  CalendarDays,
} from "lucide-react";
import { useDemo } from "@/lib/store";
import { roomSummary } from "@/lib/utils";
import { PageHeading, SectionHeading, Badge } from "../ui/shared";
export function StaffDashboard() {
  const { staff, setStaff } = useDemo();
  const summary = roomSummary(staff.rooms);
  const outstanding = staff.tasks.filter((t) => !t.complete);
  return (
    <>
      <PageHeading
        eyebrow="WEDNESDAY, 14 OCTOBER 2026 · DUTY OVERVIEW"
        title="A good morning, in the making."
        description="The house at a glance. A clear place to pick things up."
        action={
          <Link href="/staff/inspections" className="button button-dark">
            <ClipboardCheck size={18} />
            Continue room checks
            <ArrowUpRight size={17} />
          </Link>
        }
      />
      <div className="staff-summary">
        <Stat
          value={`${summary.checked}/${summary.total}`}
          title="Rooms checked"
          detail={`${Math.round((summary.checked / summary.total) * 100)}% of this morning’s round`}
          colour="sage"
          icon={<ClipboardCheck size={23} />}
        />
        <Stat
          value={summary.unchecked}
          title="Still to check"
          detail="A little more to get through"
          colour="blue"
          icon={<Clock3 size={23} />}
        />
        <Stat
          value={summary.followUp}
          title="Need a follow-up"
          detail="Staff review, no automatic action"
          colour="apricot"
          icon={<CircleAlert size={23} />}
        />
        <Stat
          value={outstanding.length}
          title="Outstanding tasks"
          detail="Small things to keep moving"
          colour="gold"
          icon={<CalendarDays size={23} />}
        />
      </div>
      <div className="staff-dashboard-grid">
        <section className="panel room-progress-card">
          <SectionHeading
            title="The morning round"
            href="/staff/inspections"
            label="Open room checks"
          />
          <div className="progress-title">
            <h3>Room inspection progress</h3>
            <span>
              {summary.checked} of {summary.total} checked
            </span>
          </div>
          <div className="progress-track">
            <span
              style={{ width: `${(summary.passed / summary.total) * 100}%` }}
            />
            <span
              className="progress-followup"
              style={{ width: `${(summary.followUp / summary.total) * 100}%` }}
            />
          </div>
          <div className="progress-legend">
            <span>
              <i className="status-dot passed" />
              {summary.passed} passed
            </span>
            <span>
              <i className="status-dot follow-up" />
              {summary.followUp} follow-up
            </span>
            <span>
              <i className="status-dot unchecked" />
              {summary.unchecked} unchecked
            </span>
          </div>
          <div className="house-progress">
            {["Kōwhai", "Tōtara"].map((h) => {
              const rooms = staff.rooms.filter((r) => r.house === h);
              const s = roomSummary(rooms);
              return (
                <div key={h}>
                  <span className="house-initial">{h[0]}</span>
                  <div>
                    <h3>{h} house</h3>
                    <p>
                      {s.followUp} follow-up · {s.unchecked} unchecked
                    </p>
                  </div>
                  <strong>
                    {s.checked}/{s.total}
                  </strong>
                  <Link
                    href={`/staff/inspections?house=${encodeURIComponent(h)}`}
                    aria-label={`Check ${h} house`}
                    className="icon-button"
                  >
                    <ArrowUpRight size={18} />
                  </Link>
                </div>
              );
            })}
          </div>
          <p className="panel-foot">
            Entries saved in this browser · Fictional rooms and residents
          </p>
        </section>
        <section className="panel duty-card">
          <SectionHeading title="On duty today" />
          <div className="duty-item">
            <span>07:30</span>
            <div>
              <h3>Morning room checks</h3>
              <p>Morgan Thompson · Both houses</p>
            </div>
            <Badge tone="sage">In progress</Badge>
          </div>
          <div className="duty-item">
            <span>15:30</span>
            <div>
              <h3>Afternoon handover</h3>
              <p>House office · Duty team</p>
            </div>
          </div>
          <div className="duty-item">
            <span>19:00</span>
            <div>
              <h3>Evening prep supervision</h3>
              <p>Study room · Priya Chen</p>
            </div>
          </div>
          <div className="duty-note">
            <Clock3 size={17} />
            <p>A sample duty roster. Confirm actual cover with your team.</p>
          </div>
        </section>
        <section className="panel staff-followups">
          <SectionHeading
            title="A little follow-through"
            href="/staff/tasks"
            label="All tasks"
          />
          <div>
            {staff.tasks.map((t) => (
              <div
                key={t.id}
                className={`staff-task-row ${t.complete ? "completed" : ""}`}
              >
                <button
                  className={`check-button ${t.complete ? "checked" : ""}`}
                  aria-label={`${t.complete ? "Reopen" : "Complete"} ${t.title}`}
                  onClick={() =>
                    setStaff((s) => ({
                      ...s,
                      tasks: s.tasks.map((x) =>
                        x.id === t.id ? { ...x, complete: !x.complete } : x,
                      ),
                    }))
                  }
                >
                  <Check size={15} />
                </button>
                <h3>{t.title}</h3>
                <Badge>{t.complete ? "Done" : "To do"}</Badge>
              </div>
            ))}
          </div>
        </section>
        <section className="staff-notice">
          <span className="notice-label">
            <Leaf size={20} />
            HOUSE NOTICEBOARD
          </span>
          <h2>Friday in the garden.</h2>
          <p>
            Community planting at 16:00. Please remind interested students at
            tonight’s house meeting.
          </p>
          <Link href="/staff/notices" className="text-link">
            Read the house notices
            <ArrowRight size={17} />
          </Link>
        </section>
      </div>
      <section className="daily-brief">
        <span>THE DAILY BRIEF</span>
        <p>
          {summary.unchecked
            ? `${summary.unchecked} rooms are still unchecked.`
            : "Every room has been checked."}{" "}
          {summary.followUp} rooms need a staff follow-up. {outstanding.length}{" "}
          operational tasks remain open. No disciplinary actions have been
          automatically assigned.
        </p>
      </section>
    </>
  );
}
function Stat({
  value,
  title,
  detail,
  colour,
  icon,
}: {
  value: string | number;
  title: string;
  detail: string;
  colour: string;
  icon: React.ReactNode;
}) {
  return (
    <article className="stat-card">
      <span className={`summary-icon ${colour}`}>{icon}</span>
      <strong>{value}</strong>
      <h2>{title}</h2>
      <p>{detail}</p>
    </article>
  );
}
