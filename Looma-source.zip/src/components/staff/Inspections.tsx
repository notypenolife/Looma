"use client";
import { RoomRequests } from "./RoomRequests";
import { useState } from "react";
import { useSearchParams } from "next/navigation";
import {
  Check,
  ClipboardCheck,
  Search,
  Pencil,
  RotateCcw,
  CircleAlert,
  Clock3,
} from "lucide-react";
import { useDemo } from "@/lib/store";
import { roomSummary } from "@/lib/utils";
import { PageHeading, Badge, Modal, EmptyState } from "../ui/shared";
import type { Room, RoomStatus } from "@/lib/types";
const statuses = {
  unchecked: "Unchecked",
  passed: "Passed",
  "follow-up": "Needs follow-up",
};
export function Inspections() {
  const { staff, setStaff, journey, reviewRoomRequest } = useDemo();
  const params = useSearchParams();
  const [house, setHouse] = useState(params.get("house") || "All houses");
  const [status, setStatus] = useState("All statuses");
  const [search, setSearch] = useState("");
  const [editing, setEditing] = useState<Room | null>(null);
  const [result, setResult] = useState<RoomStatus>("passed");
  const [reason, setReason] = useState("");
  const [note, setNote] = useState("");
  const [toast, setToast] = useState("");
  const summary = roomSummary(staff.rooms);
  const rooms = staff.rooms.filter(
    (r) =>
      (house === "All houses" || r.house === house) &&
      (status === "All statuses" || r.status === status) &&
      `${r.number} ${r.residents}`.toLowerCase().includes(search.toLowerCase()),
  );
  function open(room: Room, next?: RoomStatus) {
    setEditing(room);
    setResult(next || (room.status === "unchecked" ? "passed" : room.status));
    setReason(room.reason);
    setNote(room.note);
  }
  function save(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!editing || (result === "follow-up" && !reason)) return;
    if (result === "passed" || result === "follow-up") {
      const reviewStatus = result;
      journey.rooms
        .filter((r) => r.roomId === editing.id && r.status !== "passed")
        .forEach((r) => reviewRoomRequest(r.id, reviewStatus, note.trim()));
    }
    setStaff((s) => ({
      ...s,
      rooms: s.rooms.map((r) =>
        r.id === editing.id
          ? {
              ...r,
              status: result,
              note: note.trim(),
              reason: result === "follow-up" ? reason : "",
              updatedAt: new Date().toISOString(),
            }
          : r,
      ),
    }));
    setToast(
      `Room ${editing.number} marked ${statuses[result].toLowerCase()}. Saved in this browser.`,
    );
    setEditing(null);
  }
  return (
    <>
      <PageHeading
        eyebrow="MORNING ROUND · 14 OCTOBER"
        title="A clear start for the house."
        description="Check a room, leave a useful note, keep things moving."
        action={
          <Badge tone="sage">
            <ClipboardCheck size={15} />
            {summary.checked} of {summary.total} checked
          </Badge>
        }
      />
      <RoomRequests />
      <section className="inspection-progress">
        <div>
          <strong>
            {Math.round((summary.checked / summary.total) * 100)}%
          </strong>
          <span>of the morning round complete</span>
        </div>
        <div className="progress-track">
          <span
            style={{ width: `${(summary.checked / summary.total) * 100}%` }}
          />
        </div>
        <div className="progress-legend">
          <span>
            <i className="status-dot passed" />
            {summary.passed} passed
          </span>
          <span>
            <i className="status-dot follow-up" />
            {summary.followUp} follow-up
          </span>
          <span>
            <i className="status-dot unchecked" />
            {summary.unchecked} unchecked
          </span>
        </div>
      </section>
      <section className="panel inspection-panel">
        <div className="list-toolbar">
          <label className="search-field">
            <Search size={17} />
            <span className="sr-only">Search room or resident</span>
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Find a room or resident…"
            />
          </label>
          <div className="filter-group">
            <label className="filter-label">
              <span className="sr-only">Boarding house</span>
              <select value={house} onChange={(e) => setHouse(e.target.value)}>
                <option>All houses</option>
                <option>Kōwhai</option>
                <option>Tōtara</option>
              </select>
            </label>
            <label className="filter-label">
              <span className="sr-only">Inspection status</span>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value)}
              >
                <option>All statuses</option>
                {Object.entries(statuses).map(([v, label]) => (
                  <option value={v} key={v}>
                    {label}
                  </option>
                ))}
              </select>
            </label>
          </div>
        </div>
        <div className="room-table-header">
          <span>ROOM & RESIDENTS</span>
          <span>HOUSE</span>
          <span>STATUS / NOTES</span>
          <span>ACTION</span>
        </div>
        <div className="room-list">
          {rooms.map((r) => (
            <article key={r.id} className="room-row">
              <div className="room-ident">
                <span className="room-number">{r.number}</span>
                <div>
                  <h3>Room {r.number}</h3>
                  <p>{r.residents}</p>
                  <small className="room-mobile-house">{r.house} house</small>
                </div>
              </div>
              <span className="room-house">{r.house}</span>
              <div className="room-status">
                <Badge
                  tone={
                    r.status === "passed"
                      ? "sage"
                      : r.status === "follow-up"
                        ? "apricot"
                        : "neutral"
                  }
                >
                  {r.status === "passed" ? (
                    <Check size={13} />
                  ) : r.status === "follow-up" ? (
                    <CircleAlert size={13} />
                  ) : (
                    <Clock3 size={13} />
                  )}
                  {statuses[r.status]}
                </Badge>
                {r.note && <p>{r.note}</p>}
              </div>
              <div className="room-actions">
                {r.status === "unchecked" ? (
                  <>
                    <button
                      className="button button-pass button-small"
                      onClick={() => open(r, "passed")}
                    >
                      <Check size={15} />
                      Pass
                    </button>
                    <button
                      className="icon-button followup-button"
                      aria-label={`Follow up room ${r.number}`}
                      onClick={() => open(r, "follow-up")}
                    >
                      <CircleAlert size={18} />
                    </button>
                  </>
                ) : (
                  <button
                    className="button button-outline button-small"
                    onClick={() => open(r)}
                  >
                    <Pencil size={14} />
                    Review
                  </button>
                )}
              </div>
            </article>
          ))}
          {rooms.length === 0 && (
            <EmptyState title="Nothing in this view.">
              Try another house, status, or search term.
            </EmptyState>
          )}
        </div>
        <div className="panel-foot">
          {rooms.length} rooms shown · All names and inspection records are
          fictional.
        </div>
      </section>
      <div className="tip-banner">
        <ClipboardCheck size={20} />
        <p>
          Room checks support a staff conversation. They never automatically
          create detentions or punishments.
        </p>
      </div>
      <p className="save-status" role="status">
        {toast}
      </p>
      <Modal
        open={!!editing}
        onOpenChange={(open) => {
          if (!open) setEditing(null);
        }}
        title={`Room ${editing?.number || ""} · ${editing?.house || ""}`}
        description={`${editing?.residents || ""} — Fictional residents. Save or correct this inspection.`}
      >
        <form className="form-stack" onSubmit={save}>
          <fieldset className="inspection-options">
            <legend>Inspection result</legend>
            {(["passed", "follow-up", "unchecked"] as RoomStatus[]).map((s) => (
              <label key={s} className={result === s ? "selected" : ""}>
                <input
                  type="radio"
                  name="result"
                  value={s}
                  checked={result === s}
                  onChange={() => setResult(s)}
                />
                {s === "passed" ? (
                  <Check size={18} />
                ) : s === "unchecked" ? (
                  <RotateCcw size={18} />
                ) : (
                  <CircleAlert size={18} />
                )}
                {statuses[s]}
              </label>
            ))}
          </fieldset>
          {result === "follow-up" && (
            <label>
              Follow-up reason
              <select
                required
                value={reason}
                onChange={(e) => setReason(e.target.value)}
              >
                <option value="">Choose a reason</option>
                <option>Desk area</option>
                <option>Bed & bedding</option>
                <option>Laundry</option>
                <option>Shared space</option>
                <option>Maintenance</option>
                <option>Other</option>
              </select>
            </label>
          )}
          <label>
            Inspection note <span className="optional">optional</span>
            <textarea
              rows={3}
              maxLength={500}
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="A factual, useful note for the next staff member…"
            />
          </label>
          {editing?.updatedAt && (
            <p className="input-hint">
              Last entry:{" "}
              {new Intl.DateTimeFormat("en-NZ", {
                day: "numeric",
                month: "short",
                hour: "numeric",
                minute: "2-digit",
                timeZone: "Pacific/Auckland",
              }).format(new Date(editing.updatedAt))}{" "}
              · Local demo
            </p>
          )}
          <button type="submit" className="button button-dark">
            Save inspection
            <Check size={17} />
          </button>
        </form>
      </Modal>
    </>
  );
}
