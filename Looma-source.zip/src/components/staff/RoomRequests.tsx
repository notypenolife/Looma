"use client";
import { useState } from "react";
import { ClipboardCheck, Check, CircleAlert } from "lucide-react";
import { useDemo } from "@/lib/store";
import { Badge, Modal } from "../ui/shared";
export function RoomRequests() {
  const { journey, reviewRoomRequest } = useDemo();
  const [reviewing, setReviewing] = useState<string | null>(null),
    [notice, setNotice] = useState("");
  const requests = journey.rooms.filter((r) => r.status !== "passed"),
    passed = journey.rooms.filter((r) => r.status === "passed");
  const selected = journey.rooms.find((r) => r.id === reviewing);
  if (journey.rooms.length === 0) return null;
  return (
    <section className="student-room-requests">
      <div className="section-heading">
        <div>
          <p className="eyebrow">FROM THE STUDENT DEMO</p>
          <h2>Ready for a little check.</h2>
        </div>
        <Badge tone="sage">
          {requests.length} requests · {passed.length} passed
        </Badge>
      </div>
      <p>
        Room 101 · Alex Rivers & Jamie Taylor. Reviews update the student’s
        boarding mission. No disciplinary action is created.
      </p>
      {requests.map((r) => (
        <article key={r.id}>
          <span className="request-room-icon">
            <ClipboardCheck size={21} />
          </span>
          <div>
            <h3>
              Room 101 is{" "}
              {r.status === "ready" ? "ready for review" : "awaiting follow-up"}
              .
            </h3>
            <p>
              {r.day} · {r.note}
            </p>
          </div>
          <button
            className="button button-dark button-small"
            onClick={() => setReviewing(r.id)}
          >
            Review student request
          </button>
        </article>
      ))}
      {requests.length === 0 && (
        <p className="request-success">
          <Check size={16} />
          All student requests have passed. Results are visible in Missions.
        </p>
      )}
      <p className="save-status" role="status">
        {notice}
      </p>
      <Modal
        open={!!selected}
        onOpenChange={(open) => {
          if (!open) setReviewing(null);
        }}
        title="Room 101 · a student-ready check."
        description="This reviews a fictional room-ready request and updates the existing inspection record in this browser."
      >
        <form
          className="form-stack"
          onSubmit={(e) => {
            e.preventDefault();
            if (!selected) return;
            const data = new FormData(e.currentTarget),
              result = String(data.get("result")) as "passed" | "follow-up";
            reviewRoomRequest(
              selected.id,
              result,
              String(data.get("note")).trim(),
            );
            setReviewing(null);
            setNotice(
              result === "passed"
                ? "Room passed. The student mission is complete and ready for its chest."
                : "Follow-up saved. The student can read the note and mark their room ready again.",
            );
          }}
        >
          <label>
            Review result
            <select name="result">
              <option value="passed">Passed</option>
              <option value="follow-up">Needs follow-up</option>
            </select>
          </label>
          <label>
            Helpful note
            <textarea
              name="note"
              maxLength={500}
              rows={3}
              defaultValue={
                selected?.status === "follow-up" ? selected.note : ""
              }
              placeholder="A useful, factual note…"
            />
          </label>
          <button className="button button-dark">
            Save room-ready review
            <Check size={16} />
          </button>
        </form>
      </Modal>
      <span className="sr-only">
        <CircleAlert size={1} />
        Fictional room-ready workflow
      </span>
    </section>
  );
}
