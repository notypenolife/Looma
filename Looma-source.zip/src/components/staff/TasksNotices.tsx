"use client";
import { useState } from "react";
import { Check, Plus, Trash2, Leaf, CalendarDays } from "lucide-react";
import { useDemo } from "@/lib/store";
import { uid } from "@/lib/utils";
import { facts } from "@/lib/data/mock";
import { PageHeading, Badge, EmptyState } from "../ui/shared";
export function StaffTasks() {
  const { staff, setStaff } = useDemo();
  const [title, setTitle] = useState("");
  const [filter, setFilter] = useState("To do");
  const [toast, setToast] = useState("");
  const tasks = staff.tasks.filter(
    (t) => filter === "All" || (filter === "Done" ? t.complete : !t.complete),
  );
  return (
    <>
      <PageHeading
        eyebrow="KEEP THE SMALL THINGS MOVING"
        title="A little follow-through."
        description="Operational tasks for the fictional boarding team."
      />
      <section className="panel">
        <div className="list-toolbar">
          <div className="segmented">
            {["To do", "Done", "All"].map((s) => (
              <button
                key={s}
                aria-pressed={filter === s}
                className={filter === s ? "selected" : ""}
                onClick={() => setFilter(s)}
              >
                {s}
              </button>
            ))}
          </div>
          <Badge>Local demo</Badge>
        </div>
        {tasks.map((t) => (
          <div
            className={`staff-task-row full-staff-task ${t.complete ? "completed" : ""}`}
            key={t.id}
          >
            <button
              className={`check-button ${t.complete ? "checked" : ""}`}
              aria-label={`${t.complete ? "Reopen" : "Complete"} ${t.title}`}
              onClick={() => {
                setStaff((s) => ({
                  ...s,
                  tasks: s.tasks.map((x) =>
                    x.id === t.id ? { ...x, complete: !x.complete } : x,
                  ),
                }));
                setToast("Task status updated.");
              }}
            >
              <Check size={15} />
            </button>
            <h3>{t.title}</h3>
            <Badge>{t.complete ? "Done" : "To do"}</Badge>
            <button
              className="icon-button"
              aria-label={`Delete ${t.title}`}
              onClick={() => {
                setStaff((s) => ({
                  ...s,
                  tasks: s.tasks.filter((x) => x.id !== t.id),
                }));
                setToast("Task deleted from this browser.");
              }}
            >
              <Trash2 size={16} />
            </button>
          </div>
        ))}
        {!tasks.length && (
          <EmptyState title="A clear list.">
            Add a task or switch to another view.
          </EmptyState>
        )}
        <form
          className="staff-add-task"
          onSubmit={(e) => {
            e.preventDefault();
            if (!title.trim()) return;
            setStaff((s) => ({
              ...s,
              tasks: [
                ...s.tasks,
                { id: uid(), title: title.trim(), complete: false },
              ],
            }));
            setTitle("");
            setToast("Operational task added in this browser.");
          }}
        >
          <label className="sr-only" htmlFor="staff-task">
            New staff task
          </label>
          <input
            id="staff-task"
            required
            maxLength={120}
            placeholder="A small thing to follow up…"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
          />
          <button className="button button-dark" type="submit">
            <Plus size={17} />
            Add task
          </button>
        </form>
      </section>
      <p className="save-status" role="status">
        {toast}
      </p>
    </>
  );
}
export function StaffNotices() {
  return (
    <>
      <PageHeading
        eyebrow="AROUND THE HOUSE"
        title="The noticeboard."
        description="A shared place for the useful little updates."
        action={<Badge>Sample notices</Badge>}
      />
      <div className="information-grid">
        {facts.slice(1).map((f) => (
          <article className="information-card" key={f.id}>
            <span className="essential-icon sage">
              {f.id === "notice" ? (
                <Leaf size={26} />
              ) : (
                <CalendarDays size={26} />
              )}
            </span>
            <Badge>Fictional information</Badge>
            <h2>{f.title}</h2>
            <p>{f.content}</p>
            <div className="fact-source">
              <Leaf size={14} />
              <span>
                {f.source}
                <br />
                Updated{" "}
                {new Intl.DateTimeFormat("en-NZ", {
                  day: "numeric",
                  month: "short",
                  year: "numeric",
                  timeZone: "Pacific/Auckland",
                }).format(new Date(f.updatedAt))}
              </span>
            </div>
          </article>
        ))}
      </div>
      <div className="tip-banner">
        <Leaf size={20} />
        <p>
          Notices are read-only sample content. Publishing to a real school will
          require an authorised staff account and a verified source.
        </p>
      </div>
    </>
  );
}
