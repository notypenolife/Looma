"use client";
import { useState } from "react";
import Link from "next/link";
import { Plus, Check, Flag, ArrowUpRight } from "lucide-react";
import { useDemo } from "@/lib/store";
import {
  rewardPresets,
  occurrence,
  finished,
  reviewComplete,
  prettyDay,
  type Mission,
} from "@/lib/journey";
import { PageHeading, Badge, Modal } from "../ui/shared";
export function RewardMissions() {
  const { journey, saveStaffMission, reviewMission } = useDemo();
  const [creating, setCreating] = useState(false),
    [reviewing, setReviewing] = useState<{
      mission: Mission;
      day: string;
    } | null>(null),
    [notice, setNotice] = useState("");
  const missions = journey.missions.filter((m) => m.kind === "reward");
  const reviews = missions.flatMap((m) =>
    Array.from(
      new Set([
        journey.day,
        ...Object.keys(journey.completedSteps)
          .filter((k) => k.endsWith(`/${m.id}`))
          .map((k) => k.slice(0, 10)),
      ]),
    )
      .filter((day) => finished(journey, m, day))
      .map((day) => ({ mission: m, day, key: occurrence(m, day) })),
  );
  const selectedReady =
    reviewing && reviewComplete(journey, reviewing.mission, reviewing.day);
  return (
    <>
      <PageHeading
        eyebrow="FICTIONAL TEACHER & HOUSEMASTER DESK"
        title="Effort, recognised with care."
        description="Set reward missions and review completion. Students plan personal goals without assigning their own currency."
        action={
          <button
            className="button button-dark"
            onClick={() => setCreating(true)}
          >
            <Plus size={17} />
            Create reward mission
          </button>
        }
      />
      <div className="submission-disclaimer">
        <Flag size={20} />
        <p>
          This is a local staff demonstration. Reward presets and approval are
          checked in the demo’s domain logic. Production will require
          authenticated staff permissions and server-side transactions.
        </p>
      </div>
      <section className="reward-review-section">
        <div className="section-heading">
          <h2>Ready for a human review</h2>
          <Badge>
            {
              reviews.filter(
                (r) => journey.approvals?.[r.key]?.status !== "approved",
              ).length
            }{" "}
            waiting
          </Badge>
        </div>
        {reviews.length ? (
          reviews.map(({ mission: m, day, key }) => {
            const approval = journey.approvals?.[key],
              claimed = journey.chests.some((c) => c.occurrence === key);
            return (
              <article className="staff-reward-row" key={key}>
                <div>
                  <h3>{m.title}</h3>
                  <p>
                    Alex Rivers · {prettyDay(day)} · {m.reward} base Dewdrops
                  </p>
                  <small>{m.authorisedBy}</small>
                  {!reviewComplete(journey, m, day) && (
                    <p>
                      Review the{" "}
                      <Link href="/staff/submissions">assignment hand-in</Link>{" "}
                      or{" "}
                      <Link href="/staff/inspections">room-ready request</Link>{" "}
                      before approving this mission.
                    </p>
                  )}
                  {approval?.note && <p>{approval.note}</p>}
                </div>
                <div>
                  <Badge
                    tone={approval?.status === "approved" ? "sage" : "neutral"}
                  >
                    {claimed
                      ? "Chest collected"
                      : (approval?.status ?? "Steps finished")}
                  </Badge>
                  <button
                    className="button button-outline button-small"
                    disabled={claimed}
                    aria-label={`Review mission ${m.title}`}
                    onClick={() => setReviewing({ mission: m, day })}
                  >
                    Review completion
                  </button>
                </div>
              </article>
            );
          })
        ) : (
          <p className="journey-muted">
            Complete the steps of a staff-set mission in the student demo to
            bring it here.
          </p>
        )}
      </section>
      <section className="reward-review-section">
        <div className="section-heading">
          <h2>Staff-set missions</h2>
          <span className="small-muted">
            REWARDS ARE READ-ONLY FOR STUDENTS
          </span>
        </div>
        {missions.map((m) => (
          <article className="staff-reward-row" key={m.id}>
            <div>
              <h3>{m.title}</h3>
              <p>
                {m.authorisedBy} · {m.category} · {m.time} ·{" "}
                {m.repeat ? "Daily demo routine" : m.date}
              </p>
              <small>{m.steps.map((s) => s.title).join(" · ")}</small>
            </div>
            <Badge>{m.reward} base Dewdrops</Badge>
          </article>
        ))}
      </section>
      <p role="status" className="save-status">
        {notice}
      </p>
      <Modal
        open={creating}
        onOpenChange={setCreating}
        title="A little effort to recognise."
        description="Create a staff-authorised reward mission for the fictional student. Choose a preset; students cannot modify this reward."
      >
        <form
          className="form-stack"
          onSubmit={(e) => {
            e.preventDefault();
            const data = new FormData(e.currentTarget),
              preset = rewardPresets.find((p) => p.id === data.get("preset"))!;
            saveStaffMission({
              id: crypto.randomUUID(),
              title: String(data.get("title")).trim(),
              kind: "reward",
              authorisedBy: String(data.get("staff")),
              preset: preset.id,
              reward: preset.amount,
              category: String(data.get("category")) as Mission["category"],
              date: String(data.get("date")),
              time: String(data.get("time")),
              minutes: Number(data.get("minutes")),
              repeat: data.get("repeat") === "on",
              steps: [
                {
                  id: crypto.randomUUID(),
                  title: String(data.get("step")).trim(),
                  kind: String(data.get("stepKind")) as
                    "check" | "submission" | "room",
                },
              ],
            });
            setCreating(false);
            setNotice("Staff-set reward mission saved in this browser.");
          }}
        >
          <label>
            Reward mission name
            <input name="title" required maxLength={100} />
          </label>
          <label>
            Set by
            <select name="staff">
              <option>Morgan Vale · Demo housemaster</option>
              <option>Ms Wren · Demo teacher</option>
              <option>Dr Finch · Demo teacher</option>
            </select>
          </label>
          <label>
            Reward preset
            <select name="preset">
              {rewardPresets.map((p) => (
                <option value={p.id} key={p.id}>
                  {p.label}
                </option>
              ))}
            </select>
          </label>
          <label>
            Category
            <select name="category">
              {["Study", "Activity", "Boarding", "Mixed"].map((c) => (
                <option key={c}>{c}</option>
              ))}
            </select>
          </label>
          <div className="mission-form-pair">
            <label>
              Scheduled date
              <input
                name="date"
                type="date"
                required
                defaultValue={journey.day}
                min={journey.day}
              />
            </label>
            <label>
              Start time
              <input type="time" required name="time" defaultValue="16:30" />
            </label>
          </div>
          <label>
            Duration in minutes
            <input
              name="minutes"
              type="number"
              required
              defaultValue={30}
              min={5}
              max={480}
            />
          </label>
          <label>
            Completion requirement
            <input
              name="step"
              maxLength={120}
              required
              placeholder="Complete the agreed study session"
            />
          </label>
          <label>
            Evidence type
            <select name="stepKind">
              <option value="check">Self-check, then staff review</option>
              <option value="submission">
                Fictional teacher hand-in review
              </option>
              <option value="room">Boarding room review</option>
            </select>
          </label>
          <label className="mission-repeat">
            <input type="checkbox" name="repeat" />
            Repeat daily in the demo
          </label>
          <button className="button button-dark">
            Save staff-set mission
            <Check size={16} />
          </button>
        </form>
      </Modal>
      <Modal
        open={!!reviewing}
        onOpenChange={(open) => {
          if (!open) setReviewing(null);
        }}
        title={reviewing?.mission.title ?? "Review completion"}
        description="Fictional human review. Approving qualifies the day and permits one chest claim; it does not grant currency immediately."
      >
        <form
          className="form-stack"
          onSubmit={(e) => {
            e.preventDefault();
            if (!reviewing) return;
            const data = new FormData(e.currentTarget);
            reviewMission(
              reviewing.mission.id,
              reviewing.day,
              String(data.get("status")) as "approved" | "follow-up",
              String(data.get("note")).trim(),
            );
            setReviewing(null);
            setNotice("Mission review saved. The student can see the result.");
          }}
        >
          <label>
            Review decision
            <select
              name="status"
              defaultValue={selectedReady ? "approved" : "follow-up"}
            >
              <option value="approved" disabled={!selectedReady}>
                Approve completion
              </option>
              <option value="follow-up">Request follow-up</option>
            </select>
          </label>
          {!selectedReady && (
            <p className="input-hint">
              Assignment and room evidence must be reviewed in their own staff
              screens first.
            </p>
          )}
          <label>
            Staff note
            <textarea
              name="note"
              rows={3}
              required
              maxLength={300}
              defaultValue="Fictional completion reviewed. A good little effort."
            />
          </label>
          <button className="button button-dark">
            Save mission review
            <Check size={16} />
          </button>
        </form>
      </Modal>
      <Link className="text-link" href="/student/missions">
        View the student’s goals & missions
        <ArrowUpRight size={15} />
      </Link>
    </>
  );
}
