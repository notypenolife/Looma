"use client";
import { useState } from "react";
import { FileText, Pencil, Check, Search } from "lucide-react";
import { useDemo } from "@/lib/store";
import { PageHeading, Badge, Modal, EmptyState } from "../ui/shared";
import type { Detention } from "@/lib/types";
export function Detentions() {
  const { staff, setStaff } = useDemo();
  const [status, setStatus] = useState("All");
  const [query, setQuery] = useState("");
  const [editing, setEditing] = useState<Detention | null>(null);
  const [toast, setToast] = useState("");
  const records = staff.detentions.filter(
    (d) =>
      (status === "All" || d.status === status) &&
      `${d.student} ${d.house}`.toLowerCase().includes(query.toLowerCase()),
  );
  function save(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const data = new FormData(e.currentTarget);
    setStaff((s) => ({
      ...s,
      detentions: s.detentions.map((d) =>
        d.id === editing?.id
          ? {
              ...d,
              status: String(data.get("status")) as Detention["status"],
              session: String(data.get("session")),
              note: String(data.get("note")).trim(),
            }
          : d,
      ),
    }));
    setEditing(null);
    setToast("Administrative record updated in this browser.");
  }
  return (
    <>
      <PageHeading
        eyebrow="STAFF ADMINISTRATION"
        title="Clear records. Human decisions."
        description="Review fictional sessions, attendance, and outstanding follow-up."
        action={<Badge>Administrative prototype</Badge>}
      />
      <div className="detention-intro">
        <FileText size={23} />
        <p>
          These existing records were assigned by fictional staff. Looma does
          not make disciplinary decisions, recommend punishments, or create
          records from companion conversations.
        </p>
      </div>
      <section className="panel">
        <div className="list-toolbar">
          <div className="segmented">
            {["All", "Scheduled", "Completed", "Follow-up"].map((s) => (
              <button
                key={s}
                aria-pressed={status === s}
                className={status === s ? "selected" : ""}
                onClick={() => setStatus(s)}
              >
                {s}
              </button>
            ))}
          </div>
          <label className="search-field">
            <Search size={17} />
            <span className="sr-only">Search student or house</span>
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Find a student…"
            />
          </label>
        </div>
        <div className="detention-table">
          {records.map((d) => (
            <article key={d.id}>
              <div className="detention-person">
                <span className="avatar">
                  {d.student
                    .split(" ")
                    .map((n) => n[0])
                    .join("")}
                </span>
                <div>
                  <h3>{d.student}</h3>
                  <p>{d.house} house · Fictional student</p>
                </div>
              </div>
              <div className="detention-reason">
                <h3>{d.reason}</h3>
                <p>{d.note}</p>
              </div>
              <div className="detention-session">
                <span className="small-muted">SESSION · 16:00</span>
                <strong>
                  {new Intl.DateTimeFormat("en-NZ", {
                    weekday: "short",
                    day: "numeric",
                    month: "short",
                    timeZone: "Pacific/Auckland",
                  }).format(new Date(`${d.session}T00:00:00Z`))}
                </strong>
                <Badge
                  tone={
                    d.status === "Completed"
                      ? "sage"
                      : d.status === "Follow-up"
                        ? "apricot"
                        : "blue"
                  }
                >
                  {d.status}
                </Badge>
              </div>
              <button
                className="icon-button"
                aria-label={`Review record for ${d.student}`}
                onClick={() => setEditing(d)}
              >
                <Pencil size={17} />
              </button>
            </article>
          ))}
        </div>
        {records.length === 0 && (
          <EmptyState title="No matching records.">
            Try another status or student name.
          </EmptyState>
        )}
        <div className="panel-foot">
          {records.length} fictional records shown · Staff demonstration only
        </div>
      </section>
      <p className="save-status" role="status">
        {toast}
      </p>
      <Modal
        open={!!editing}
        onOpenChange={(v) => {
          if (!v) setEditing(null);
        }}
        title={`Review · ${editing?.student || ""}`}
        description="Update the administrative details of this existing fictional record."
      >
        {editing && (
          <form className="form-stack" onSubmit={save}>
            <div className="record-reason">
              <span className="small-muted">EXISTING REASON</span>
              <p>{editing.reason}</p>
            </div>
            <div className="form-two">
              <label>
                Session date
                <input
                  type="date"
                  name="session"
                  required
                  min="2020-01-01"
                  max="2100-12-31"
                  defaultValue={editing.session}
                />
              </label>
              <label>
                Completion status
                <select name="status" defaultValue={editing.status}>
                  <option>Scheduled</option>
                  <option>Completed</option>
                  <option>Follow-up</option>
                </select>
              </label>
            </div>
            <label>
              Staff follow-up note
              <textarea
                name="note"
                rows={3}
                maxLength={500}
                defaultValue={editing.note}
              />
            </label>
            <button className="button button-dark" type="submit">
              Save record
              <Check size={17} />
            </button>
          </form>
        )}
      </Modal>
    </>
  );
}
