"use client";
import { useState } from "react";
import { Send, Check, FileText } from "lucide-react";
import { useDemo } from "@/lib/store";
import type { Submission } from "@/lib/journey";
import { PageHeading, Badge, Modal, EmptyState } from "../ui/shared";
export function Submissions() {
  const { journey, reviewSubmission } = useDemo();
  const [status, setStatus] = useState("all"),
    [editing, setEditing] = useState<Submission | null>(null),
    [notice, setNotice] = useState("");
  const submissions = journey.submissions.filter(
    (s) => status === "all" || s.status === status,
  );
  return (
    <>
      <PageHeading
        eyebrow="FICTIONAL TEACHER DESK"
        title="A little work, received."
        description="Review sample hand-ins from the student demo. Nothing is uploaded or sent."
        action={
          <Badge>
            {journey.submissions.filter((s) => s.status === "submitted").length}{" "}
            awaiting review
          </Badge>
        }
      />
      <div className="submission-disclaimer">
        <Send size={19} />
        <p>
          Every record is a local demonstration. Teachers, assignments and
          reviews are fictional. No file contents are uploaded or stored here.
        </p>
      </div>
      <label className="submission-filter">
        Submission status
        <select value={status} onChange={(e) => setStatus(e.target.value)}>
          <option value="all">All submissions</option>
          <option value="submitted">Awaiting review</option>
          <option value="reviewed">Reviewed</option>
          <option value="needs-revision">Needs revision</option>
        </select>
      </label>
      <section className="staff-submission-list">
        {submissions.map((s) => (
          <article key={s.id}>
            <span className="staff-submission-icon">
              <FileText size={23} />
            </span>
            <div>
              <h2>{s.title}</h2>
              <p>
                Alex Rivers · {s.subject} · {s.teacher} · {s.day}
              </p>
              <small>Demo submission — nothing was sent.</small>
              {s.summary && <p>{s.summary}</p>}
              {s.attachment && (
                <p>
                  Attachment metadata: {s.attachment.name} ·{" "}
                  {Math.ceil(s.attachment.size / 1024)} KB
                </p>
              )}
              {s.staffNote && <p>Review note: {s.staffNote}</p>}
            </div>
            <div>
              <Badge tone={s.status === "reviewed" ? "sage" : "neutral"}>
                {s.status.replace("-", " ")}
              </Badge>
              <button
                className="button button-outline button-small"
                onClick={() => setEditing(s)}
              >
                Review hand-in
              </button>
            </div>
          </article>
        ))}
        {submissions.length === 0 && (
          <EmptyState title="A clear little inbox.">
            Hand in a demo assignment from Student → Missions to see a receipt
            here.
          </EmptyState>
        )}
      </section>
      <p role="status" className="save-status">
        {notice}
      </p>
      <Modal
        open={!!editing}
        onOpenChange={(open) => {
          if (!open) setEditing(null);
        }}
        title={editing?.title ?? "Review hand-in"}
        description="Fictional teacher review. This updates the local demo receipt only."
      >
        <form
          className="form-stack"
          key={editing?.id}
          onSubmit={(e) => {
            e.preventDefault();
            if (!editing) return;
            const data = new FormData(e.currentTarget);
            reviewSubmission(
              editing.id,
              String(data.get("status")) as Submission["status"],
              String(data.get("note")).trim(),
            );
            setEditing(null);
            setNotice("Demo review saved. No message was sent.");
          }}
        >
          <label>
            Review status
            <select name="status" defaultValue={editing?.status}>
              <option value="submitted">Awaiting review</option>
              <option value="reviewed">Reviewed</option>
              <option value="needs-revision">Needs revision</option>
            </select>
          </label>
          <label>
            Fictional teacher note
            <textarea
              name="note"
              maxLength={500}
              rows={3}
              defaultValue={editing?.staffNote}
            />
          </label>
          <button className="button button-dark">
            Save demo review
            <Check size={16} />
          </button>
        </form>
      </Modal>
    </>
  );
}
