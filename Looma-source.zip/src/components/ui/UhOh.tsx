"use client";
import Link from "next/link";
import { useContext } from "react";
import { DemoContext } from "@/lib/store";
import { defaultPet } from "@/lib/data/mock";
import { LoomaPet } from "../pets/LoomaPet";
export function UhOh({
  retry,
  unfinished = false,
}: {
  retry?: () => void;
  unfinished?: boolean;
}) {
  const demo = useContext(DemoContext);
  const pet = demo?.pet ?? defaultPet;
  return (
    <section className="uh-oh-page">
      <span className="uh-oh-label">LOOMA’S LITTLE REPAIR CORNER</span>
      <div className="repair-scene">
        <span className="repair-tape tape-one" />
        <LoomaPet
          {...pet}
          accessory="none"
          expression="thinking"
          construction
        />
        <span className="repair-tape tape-two" />
      </div>
      <h1>Uh oh. A little work in progress.</h1>
      <p>
        {unfinished
          ? "This corner isn’t quite ready for visitors. Hard hat on, tiny sleeves rolled up."
          : "Something got a little tangled. Hard hat on, deep breath. Let’s try that again."}
      </p>
      <p className="repair-pet-line">“{pet.name} has the tiny toolkit.”</p>
      <div className="repair-actions">
        {retry && (
          <button className="button button-dark" onClick={retry}>
            Try again
          </button>
        )}
        <Link className="button button-outline" href="/student">
          Back to my day
        </Link>
        <Link className="text-link" href="/staff">
          Staff overview
        </Link>
      </div>
      <small>
        Your browser-saved demo data stays here. If this keeps happening,
        refresh the page.
      </small>
    </section>
  );
}
