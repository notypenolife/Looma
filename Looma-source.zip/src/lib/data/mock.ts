import type {
  PetPreferences,
  StudentData,
  StaffData,
  SchoolFact,
  Lesson,
} from "../types";
export const DEMO_DATE = "2026-10-14";
export const DEMO_SCHOOL = {
  id: "demo-willowmere",
  name: "Willowmere Academy",
  location: "Fictional Harbour Bay",
};
export const defaultPet: PetPreferences = {
  name: "Fern",
  form: "sprout",
  colour: "sage",
  accessory: "scarf",
  tone: "warm",
};
export const initialStudent: StudentData = {
  tasks: [
    {
      id: "t1",
      title: "Finish the close-reading response",
      subject: "English",
      due: "2026-10-15",
      complete: false,
      notes: "Two paragraphs on imagery. Bring your annotated text.",
    },
    {
      id: "t2",
      title: "Quadratic equations · exercise 4B",
      subject: "Mathematics",
      due: "2026-10-15",
      complete: false,
      notes: "Questions 1–8. Show your working.",
    },
    {
      id: "t3",
      title: "Plan the ecology field report",
      subject: "Biology",
      due: "2026-10-16",
      complete: false,
      notes: "Outline your method and organise field notes.",
    },
    {
      id: "t4",
      title: "Pack hockey gear",
      subject: "Personal",
      due: "2026-10-14",
      complete: false,
      notes: "Stick, mouthguard, water bottle.",
    },
    {
      id: "t5",
      title: "Read the primary source extracts",
      subject: "History",
      due: "2026-10-14",
      complete: true,
      notes: "Highlight three useful pieces of evidence.",
    },
  ],
  memories: [
    {
      id: "m1",
      text: "My favourite sport is hockey.",
      approvedAt: "2026-10-12",
    },
    {
      id: "m2",
      text: "I like to break big assignments into small steps.",
      approvedAt: "2026-10-12",
    },
  ],
};
export const initialStaff: StaffData = {
  rooms: Array.from({ length: 12 }, (_, i) => ({
    id: `r${i + 1}`,
    number: `${i < 6 ? "1" : "2"}0${(i % 6) + 1}`,
    house: i < 6 ? "Kōwhai" : "Tōtara",
    residents: [
      "Alex R. · Jamie T.",
      "Sam W. · Luca P.",
      "Charlie M. · Finn D.",
      "Riley B. · Theo H.",
      "Jordan K. · Noah S.",
      "Casey L. · Max A.",
    ][i % 6],
    status: i < 5 ? "passed" : i === 5 || i === 8 ? "follow-up" : "unchecked",
    note:
      i === 5
        ? "Please return after breakfast to check the desk area."
        : i === 8
          ? "Wet towel on the chair. Drying space needed."
          : "",
    reason: i === 5 ? "Desk area" : i === 8 ? "Laundry" : "",
    updatedAt: i < 6 || i === 8 ? "2026-10-14T07:20:00+13:00" : undefined,
  })),
  detentions: [
    {
      id: "d1",
      student: "Jamie Taylor",
      house: "Kōwhai",
      reason: "Repeated late arrival to prep",
      session: "2026-10-15",
      status: "Scheduled",
      note: "Assigned by fictional duty staff. Check transport arrangements.",
    },
    {
      id: "d2",
      student: "Finn Davis",
      house: "Kōwhai",
      reason: "Missed sign-in",
      session: "2026-10-14",
      status: "Follow-up",
      note: "Staff review required before rescheduling.",
    },
    {
      id: "d3",
      student: "Noah Smith",
      house: "Tōtara",
      reason: "Disruption during prep",
      session: "2026-10-13",
      status: "Completed",
      note: "Attendance confirmed by fictional duty staff.",
    },
  ],
  tasks: [
    {
      id: "s1",
      title: "Confirm transport for Saturday’s fixture",
      complete: false,
    },
    {
      id: "s2",
      title: "Follow up on the laundry drying rack",
      complete: false,
    },
    { id: "s3", title: "Check evening prep cover", complete: true },
  ],
};
export const facts: SchoolFact[] = [
  {
    id: "uniform",
    schoolId: DEMO_SCHOOL.id,
    title: "Summer uniform",
    content:
      "In this demo: summer shirt, school shorts or skirt, and polished black shoes. Bring your blazer for assembly.",
    source: "Fictional demo uniform guide",
    updatedAt: "2026-10-12T09:00:00+13:00",
    demo: true,
  },
  {
    id: "routine",
    schoolId: DEMO_SCHOOL.id,
    title: "Your boarding rhythm",
    content:
      "Breakfast 7:00 · Room checks 7:30 · Dinner 18:00 · Evening prep 19:00–20:30 · Wind-down 21:00.",
    source: "Fictional demo boarding handbook",
    updatedAt: "2026-10-12T09:00:00+13:00",
    demo: true,
  },
  {
    id: "hockey",
    schoolId: DEMO_SCHOOL.id,
    title: "Hockey training",
    content:
      "Wednesday, 15:45–17:00 at the turf. Bring your water bottle and mouthguard.",
    source: "Fictional demo activities calendar",
    updatedAt: "2026-10-13T12:00:00+13:00",
    demo: true,
  },
  {
    id: "notice",
    schoolId: DEMO_SCHOOL.id,
    title: "A little time outdoors",
    content:
      "The community garden is open this Friday at 16:00. Come along to plant spring seedlings. No experience needed.",
    source: "Fictional demo house noticeboard",
    updatedAt: "2026-10-13T12:00:00+13:00",
    demo: true,
  },
];
const subjects = ["Mathematics", "English", "Biology", "History", "Art"];
const colours = ["blue", "apricot", "sage", "gold", "blue"];
export const weekdays = [
  "Monday",
  "Tuesday",
  "Wednesday",
  "Thursday",
  "Friday",
];
export function timetable(day: number): Lesson[] {
  return ["08:30", "09:30", "11:00", "12:00", "14:00"].map((time, i) => ({
    time,
    end: ["09:25", "10:25", "11:55", "12:55", "15:00"][i],
    subject: subjects[(i + day + 3) % 5],
    room: ["M12", "E04", "Science 2", "H06", "Studio 1"][(i + day + 3) % 5],
    teacher: ["Ms Chen", "Mr Wilson", "Dr Patel", "Ms Fraser", "Mr Reed"][
      (i + day + 3) % 5
    ],
    colour: colours[(i + day + 3) % 5],
  }));
}
export const routines = [
  { time: "07:00", title: "Breakfast", place: "Dining hall" },
  { time: "07:30", title: "Room check", place: "Your boarding house" },
  { time: "15:45", title: "Hockey training", place: "School turf" },
  { time: "18:00", title: "Dinner", place: "Dining hall" },
  { time: "19:00", title: "Evening prep", place: "House study room" },
  { time: "21:00", title: "Time to wind down", place: "Your own pace" },
];
