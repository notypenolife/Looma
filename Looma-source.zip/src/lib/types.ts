export type PetForm =
  | "sprout"
  | "pebble"
  | "pip"
  | "water"
  | "shadow"
  | "fiend"
  | "fire"
  | "electricity"
  | "twig"
  | "copper"
  | "silverling"
  | "plume"
  | "sol"
  | "facet"
  | "rubio"
  | "void"
  | "pumpkin"
  | "ghost"
  | "bat"
  | "witch"
  | "eclipse";
export type Expression =
  "happy" | "curious" | "thinking" | "sleepy" | "celebrating";
export type PetColour = "sage" | "apricot" | "blue" | "gold";
export type Accessory =
  | "none"
  | "scarf"
  | "glasses"
  | "satchel"
  | "bow"
  | "leafhat"
  | "starpin"
  | "headphones"
  | "crown"
  | "trailbow"
  | "dewbadge"
  | "mooncloak"
  | "rubytiara"
  | "diamondhalo"
  | "voidchains"
  | "pumpkinhat"
  | "stitchbow"
  | "candlehat"
  | "batcape"
  | "mooncrown";
export interface PetPreferences {
  name: string;
  form: PetForm;
  colour: PetColour;
  accessory: Accessory;
  tone: "warm" | "concise" | "playful";
}
export interface Task {
  id: string;
  title: string;
  subject: string;
  due: string;
  complete: boolean;
  notes: string;
}
export interface Memory {
  id: string;
  text: string;
  approvedAt: string;
}
export interface StudentData {
  tasks: Task[];
  memories: Memory[];
}
export type RoomStatus = "unchecked" | "passed" | "follow-up";
export interface Room {
  id: string;
  number: string;
  house: string;
  residents: string;
  status: RoomStatus;
  note: string;
  reason: string;
  updatedAt?: string;
}
export interface Detention {
  id: string;
  student: string;
  house: string;
  reason: string;
  session: string;
  status: "Scheduled" | "Completed" | "Follow-up";
  note: string;
}
export interface StaffData {
  rooms: Room[];
  detentions: Detention[];
  tasks: { id: string; title: string; complete: boolean }[];
}
export interface SchoolFact {
  id: string;
  schoolId: string;
  title: string;
  content: string;
  source: string;
  updatedAt: string;
  demo: true;
}
export interface Lesson {
  time: string;
  end: string;
  subject: string;
  room: string;
  teacher: string;
  colour: string;
}
export interface NotificationPreferences {
  homework: boolean;
  boarding: boolean;
  quiet: boolean;
}
