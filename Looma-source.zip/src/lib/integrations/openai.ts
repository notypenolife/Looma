import "server-only";
/** Deliberately disconnected until authenticated, rate-limited production chat exists. */
export function getOpenAIConfiguration() {
  return {
    model: process.env.OPENAI_MODEL,
    apiKey: process.env.OPENAI_API_KEY,
    configured: !!process.env.OPENAI_API_KEY && !!process.env.OPENAI_MODEL,
  };
}
export const productionChatRequirements = [
  "Verified Supabase Auth session and school membership",
  "Server-side input validation and bounded context",
  "Durable per-user and per-school rate limits",
  "Per-school token budgets and spend caps",
  "Age-appropriate safeguards and reviewed retention policy",
  "Approved, sourced school retrieval and explicit memory consent",
] as const;
