import type { Task, Memory, Room, SchoolFact } from "../types";
/** Production permissions must come from a verified server session, never demo navigation. */
export interface VerifiedSchoolSession {
  userId: string;
  schoolId: string;
  role: "student" | "staff";
  verified: true;
}
export interface StudentRepository {
  listTasks(session: VerifiedSchoolSession): Promise<Task[]>;
  saveTask(session: VerifiedSchoolSession, task: Task): Promise<void>;
  listApprovedMemories(session: VerifiedSchoolSession): Promise<Memory[]>;
}
export interface StaffRepository {
  listRooms(session: VerifiedSchoolSession): Promise<Room[]>;
  saveInspection(session: VerifiedSchoolSession, room: Room): Promise<void>;
}
export interface SchoolInformationRepository {
  listVerifiedFacts(schoolId: string): Promise<SchoolFact[]>;
}
export interface ChatRequest {
  message: string;
  schoolId: string;
}
export interface ChatProvider {
  reply(session: VerifiedSchoolSession, request: ChatRequest): Promise<string>;
}
