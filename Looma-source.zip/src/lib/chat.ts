import { personalityReaction } from "./personality";
import { facts, timetable } from "./data/mock";
import { openTasks, dueLabel } from "./utils";
import type { StudentData, PetPreferences } from "./types";
export function demoReply(
  message: string,
  student: StudentData,
  pet: PetPreferences,
): string {
  const q = message.toLowerCase();
  const tasks = openTasks(student.tasks);
  let reply: string;
  if (
    /dance|play|wave|snack|biscuit|rest|sleep|personality|who are you/.test(q)
  ) {
    const event = /snack|biscuit/.test(q)
      ? "snack"
      : /rest|sleep/.test(q)
        ? "rest"
        : /dance|play/.test(q)
          ? "play"
          : "hello";
    reply = personalityReaction(pet.form, event, 12).line;
  } else if (/uniform|wear|blazer/.test(q))
    reply = `${facts[0].content}\n\nThis is a sample guide, not a verified school requirement. Check your school’s current notice before heading out.`;
  else if (/remember|sport|hockey|memory/.test(q))
    reply = student.memories.length
      ? `Here’s what you’ve approved for me to remember:\n${student.memories.map((m) => `• ${m.text}`).join("\n")}\n\nYou can change or remove these in My Looma. I don’t save personal details from our chat automatically.`
      : "You haven’t approved any memories yet. Add a preference in My Looma if you’d like. You’re always in charge of what stays.";
  else if (/organis|organiz|plan|assignment/.test(q))
    reply = tasks.length
      ? `Let’s make a little room to think. Start with “${tasks[0].title}” (${dueLabel(tasks[0].due).toLowerCase()}).\n\n1. Spend 5 minutes reading what’s needed.\n2. Work on one small part for 20 minutes.\n3. Take a short break, then check what’s left.\n\nYou can add those steps as personal tasks in Homework.`
      : "Your task list is clear. Add an assignment in Homework, and we can break it into a few manageable steps.";
  else if (/homework|due|task|deadline/.test(q))
    reply = tasks.length
      ? `You have ${tasks.length} things on your list:\n${tasks.map((t) => `• ${t.title} — ${dueLabel(t.due).toLowerCase()}`).join("\n")}\n\nA small start now can make tonight feel easier.`
      : "Everything on your list is complete. A bit of breathing room! Add a task whenever you need to.";
  else if (/tonight|evening/.test(q))
    reply =
      "In our sample boarding routine, dinner is at 18:00 and prep runs from 19:00 to 20:30. Bring what you need for your first task, and leave a little time to pack for tomorrow. Wind-down starts at 21:00.\n\nSource: fictional demo boarding handbook.";
  else if (/today|happening|schedule|class/.test(q))
    reply = `Here’s your demo Wednesday: ${timetable(2)
      .slice(0, 3)
      .map((l) => `${l.subject} at ${l.time}`)
      .join(
        ", ",
      )}. Hockey is at 15:45, then dinner at 18:00.\n\n${tasks.length} tasks are still open. Shall we start with what’s due soon?\n\nSource: fictional demo timetable and activities calendar.`;
  else if (/hello|hey|hi\b/.test(q))
    reply = `${personalityReaction(pet.form, "hello", 12).line} Want to look at your timetable, sort out homework, or check the evening routine?`;
  else
    reply =
      "I don’t have a verified source for that in this demo. For school rules or a change to your plans, check with your house staff. I can help with your sample timetable, homework, uniform, evening routine, or approved memories.";
  if (pet.tone === "concise")
    return reply.split("\n\n").slice(0, 2).join("\n\n");
  if (pet.tone === "playful" && !/verified|uniform/.test(reply))
    return `One small step at a time. 🌱\n\n${reply}`;
  return reply;
}
