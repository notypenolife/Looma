import {
  initialCollection,
  validCollection,
  type CollectionState,
  type Rarity,
} from "./collection";
import type { Accessory, PetForm } from "./types";

export const chestTiers = [
  "wood",
  "bronze",
  "silver",
  "platinum",
  "gold",
  "ruby",
  "diamond",
  "void",
] as const;
export type ChestTier = (typeof chestTiers)[number];
export type StepKind = "check" | "submission" | "room";
export interface MissionStep {
  id: string;
  title: string;
  kind: StepKind;
}
export interface Mission {
  id: string;
  title: string;
  category: "Study" | "Activity" | "Boarding" | "Mixed";
  date: string;
  time: string;
  minutes: number;
  repeat: boolean;
  reward: number;
  kind?: "goal" | "reward";
  authorisedBy?: string;
  preset?: string;
  steps: MissionStep[];
}
export interface Submission {
  id: string;
  occurrence: string;
  stepId: string;
  day: string;
  title: string;
  subject: string;
  teacher: string;
  attachment?: { name: string; size: number; type: string };
  summary: string;
  status: "submitted" | "reviewed" | "needs-revision";
  staffNote: string;
}
export interface RoomRequest {
  id: string;
  occurrence: string;
  stepId: string;
  day: string;
  roomId: string;
  status: "ready" | "passed" | "follow-up";
  note: string;
}
export interface RewardEntry {
  label: string;
  kind: "currency" | "cosmetic" | "looma";
  item?: Accessory | PetForm;
  amount?: number;
  chance: number;
}
export interface ChestReward extends RewardEntry {
  duplicate: boolean;
  compensation: number;
}
export interface EarnedChest {
  id: string;
  occurrence: string;
  title: string;
  day: string;
  base: number;
  multiplier: number;
  expected: number;
  initialTier: ChestTier;
  tier: ChestTier;
  taps: number;
  upgradeRolls: number[];
  rewardRoll: number;
  lastTapAt: number;
  reward?: ChestReward;
  practice: boolean;
  tableVersion?: 1 | 2;
}
export interface JourneyState {
  day: string;
  clock: "live" | "demo";
  processedThrough: string;
  missions: Mission[];
  completedSteps: Record<string, string[]>;
  qualifiedDays: string[];
  protectedDays: string[];
  savers: number;
  chests: EarnedChest[];
  submissions: Submission[];
  rooms: RoomRequest[];
  approvals?: Record<
    string,
    { status: "pending" | "approved" | "follow-up"; note: string }
  >;
}
export interface WorldState {
  schema?: 3;
  collection: CollectionState;
  journey: JourneyState;
}
export const saverPrice = 120;
export const multipliers = [
  { days: 1, factor: 1 },
  { days: 3, factor: 1.1 },
  { days: 7, factor: 1.25 },
  { days: 14, factor: 1.5 },
  { days: 30, factor: 2 },
];
export const initialJourney: JourneyState = {
  day: "2026-10-24",
  clock: "live",
  processedThrough: "2026-10-23",
  savers: 0,
  completedSteps: {},
  qualifiedDays: [],
  protectedDays: [],
  chests: [],
  submissions: [],
  rooms: [],
  approvals: {},
  missions: [
    {
      id: "move-and-make",
      kind: "reward",
      authorisedBy: "Morgan Vale · Demo housemaster",
      preset: "group",
      title: "A little movement. A little progress.",
      category: "Mixed",
      date: "2026-10-24",
      time: "16:30",
      minutes: 90,
      repeat: true,
      reward: 100,
      steps: [
        { id: "gym", title: "Gym at 4:30 pm · one hour", kind: "check" },
        {
          id: "social",
          title: "Finish Social Studies homework",
          kind: "check",
        },
      ],
    },
    {
      id: "hand-it-in",
      kind: "reward",
      authorisedBy: "Ms Wren · Demo teacher",
      preset: "assignment",
      title: "One assignment, handed in.",
      category: "Study",
      date: "2026-10-24",
      time: "15:15",
      minutes: 15,
      repeat: true,
      reward: 50,
      steps: [
        {
          id: "submit",
          title: "Submit your sample assignment to a fictional teacher",
          kind: "submission",
        },
      ],
    },
    {
      id: "room-ready",
      kind: "reward",
      authorisedBy: "Morgan Vale · Demo housemaster",
      preset: "room",
      title: "A tidy little start.",
      category: "Boarding",
      date: "2026-10-24",
      time: "07:30",
      minutes: 10,
      repeat: true,
      reward: 25,
      steps: [
        {
          id: "room",
          title: "Mark Room 101 ready, then get a staff review",
          kind: "room",
        },
      ],
    },
  ],
};
export const initialWorld: WorldState = {
  schema: 3,
  collection: initialCollection,
  journey: initialJourney,
};
export function aucklandDay(now: Date) {
  const parts = new Intl.DateTimeFormat("en-NZ", {
    timeZone: "Pacific/Auckland",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).formatToParts(now);
  const part = (type: string) => parts.find((p) => p.type === type)!.value;
  return `${part("year")}-${part("month")}-${part("day")}`;
}
export function shiftDay(day: string, by: number) {
  const date = new Date(`${day}T12:00:00Z`);
  date.setUTCDate(date.getUTCDate() + by);
  return date.toISOString().slice(0, 10);
}
export function prettyDay(day: string) {
  return new Intl.DateTimeFormat("en-NZ", {
    day: "numeric",
    month: "long",
    weekday: "long",
    timeZone: "Pacific/Auckland",
  }).format(new Date(`${day}T00:00:00Z`));
}
export function occurrence(mission: Mission, day: string) {
  return `${day}/${mission.id}`;
}
export function isScheduled(mission: Mission, day: string) {
  return mission.repeat ? day >= mission.date : mission.date === day;
}
export function finished(
  journey: JourneyState,
  mission: Mission,
  day = journey.day,
) {
  const done = journey.completedSteps[occurrence(mission, day)] ?? [];
  return (
    isScheduled(mission, day) &&
    mission.steps.length > 0 &&
    mission.steps.every((s) => done.includes(s.id))
  );
}
export function streakCount(j: JourneyState, day = j.day) {
  let cursor = day,
    count = 0;
  if (!j.qualifiedDays.includes(cursor) && !j.protectedDays.includes(cursor))
    cursor = shiftDay(cursor, -1);
  for (let i = 0; i < 3660; i++) {
    if (j.qualifiedDays.includes(cursor)) count++;
    else if (!j.protectedDays.includes(cursor)) break;
    cursor = shiftDay(cursor, -1);
  }
  return count;
}
export function multiplier(count: number) {
  return [...multipliers].reverse().find((m) => count >= m.days)?.factor ?? 1;
}
export function settleDay(
  world: WorldState,
  day: string,
  clock: "live" | "demo" = world.journey.clock,
): WorldState {
  if (day === world.journey.day && clock === world.journey.clock) return world;
  let j = { ...world.journey, protectedDays: [...world.journey.protectedDays] };
  let cursor = shiftDay(j.processedThrough, 1);
  for (let i = 0; cursor < day && i < 3660; i++, cursor = shiftDay(cursor, 1)) {
    if (
      !j.qualifiedDays.includes(cursor) &&
      !j.protectedDays.includes(cursor) &&
      streakCount(j, cursor) > 0 &&
      j.savers > 0
    ) {
      j.protectedDays.push(cursor);
      j.savers--;
    }
    j.processedThrough = cursor;
  }
  j = { ...j, day, clock };
  return { ...world, journey: j };
}
function qualify(j: JourneyState, day: string) {
  return j.qualifiedDays.includes(day)
    ? j
    : { ...j, qualifiedDays: [...j.qualifiedDays, day] };
}
function finishStep(
  world: WorldState,
  key: string,
  stepId: string,
): WorldState {
  const day = key.slice(0, 10),
    mission = world.journey.missions.find((m) => occurrence(m, day) === key);
  if (
    !mission ||
    !mission.steps.some((s) => s.id === stepId) ||
    world.journey.chests.some((c) => c.occurrence === key)
  )
    return world;
  const done = world.journey.completedSteps[key] ?? [];
  if (done.includes(stepId)) return world;
  let j = {
    ...world.journey,
    completedSteps: {
      ...world.journey.completedSteps,
      [key]: [...done, stepId],
    },
  };
  if (rewardReady(j, mission, day)) j = qualify(j, day);
  return { ...world, journey: j };
}
export function completeCheck(
  world: WorldState,
  missionId: string,
  stepId: string,
) {
  const j = world.journey,
    m = j.missions.find((m) => m.id === missionId);
  if (
    !m ||
    !isScheduled(m, j.day) ||
    m.steps.find((s) => s.id === stepId)?.kind !== "check"
  )
    return world;
  return finishStep(world, occurrence(m, j.day), stepId);
}
export function saveMission(
  world: WorldState,
  mission: Mission,
  actor: "student" | "staff" = "student",
): WorldState {
  const previous = world.journey.missions.find((m) => m.id === mission.id);
  if (
    actor === "student" &&
    (mission.reward !== 0 ||
      mission.kind === "reward" ||
      mission.authorisedBy ||
      previous?.kind === "reward")
  )
    return world;
  if (
    actor === "staff" &&
    (mission.kind !== "reward" ||
      !mission.authorisedBy ||
      rewardPresets.find((p) => p.id === mission.preset)?.amount !==
        mission.reward)
  )
    return world;
  if (
    !mission.title.trim() ||
    mission.steps.length < 1 ||
    mission.steps.length > 8 ||
    !Number.isFinite(mission.reward) ||
    !Number.isFinite(mission.minutes) ||
    mission.minutes < 5 ||
    mission.minutes > 480 ||
    !/^[0-2][0-9]:[0-5][0-9]$/.test(mission.time) ||
    mission.steps.some(
      (s) =>
        !s.title.trim() || !["check", "submission", "room"].includes(s.kind),
    ) ||
    new Set(mission.steps.map((s) => s.id)).size !== mission.steps.length ||
    mission.reward < 0 ||
    mission.reward > 1200 ||
    !/^\d{4}-\d{2}-\d{2}$/.test(mission.date)
  )
    return world;
  const existing = world.journey.missions.find((m) => m.id === mission.id);
  if (
    existing &&
    (world.journey.completedSteps[occurrence(existing, world.journey.day)]
      ?.length ||
      world.journey.chests.some(
        (c) => c.occurrence === occurrence(existing, world.journey.day),
      ))
  )
    return world;
  return {
    ...world,
    journey: {
      ...world.journey,
      missions: existing
        ? world.journey.missions.map((m) => (m.id === mission.id ? mission : m))
        : [...world.journey.missions, mission],
    },
  };
}
export function submitAssignment(
  world: WorldState,
  submission: Submission,
): WorldState {
  const j = world.journey,
    m = j.missions.find((m) => occurrence(m, j.day) === submission.occurrence);
  if (
    !m ||
    m.steps.find((s) => s.id === submission.stepId)?.kind !== "submission" ||
    !submission.title.trim() ||
    !submission.teacher.trim() ||
    !submission.subject.trim() ||
    !isScheduled(m, j.day) ||
    j.submissions.some(
      (s) =>
        s.occurrence === submission.occurrence &&
        s.stepId === submission.stepId,
    )
  )
    return world;
  const next = {
    ...world,
    journey: {
      ...j,
      submissions: [
        {
          ...submission,
          status: "submitted" as const,
          staffNote: "",
          day: j.day,
        },
        ...j.submissions,
      ],
    },
  };
  return finishStep(next, submission.occurrence, submission.stepId);
}
export function requestRoom(
  world: WorldState,
  missionId: string,
  stepId: string,
): WorldState {
  const j = world.journey,
    m = j.missions.find((m) => m.id === missionId);
  if (
    !m ||
    !isScheduled(m, j.day) ||
    m.steps.find((s) => s.id === stepId)?.kind !== "room"
  )
    return world;
  const key = occurrence(m, j.day),
    existing = j.rooms.find((r) => r.occurrence === key && r.stepId === stepId);
  if (existing && existing.status !== "follow-up") return world;
  const request: RoomRequest = {
    id: `room:${key}:${stepId}`,
    occurrence: key,
    stepId,
    day: j.day,
    roomId: "r1",
    status: "ready",
    note: "Student marked Room 101 ready for a fictional staff review.",
  };
  return {
    ...world,
    journey: {
      ...j,
      rooms: existing
        ? j.rooms.map((r) => (r.id === existing.id ? request : r))
        : [request, ...j.rooms],
    },
  };
}
export function reviewRoom(
  world: WorldState,
  id: string,
  status: "passed" | "follow-up",
  note: string,
  actor: "student" | "staff" = "student",
): WorldState {
  if (actor !== "staff") return world;
  const request = world.journey.rooms.find((r) => r.id === id);
  if (!request || request.status === "passed") return world;
  const next = {
    ...world,
    journey: {
      ...world.journey,
      rooms: world.journey.rooms.map((r) =>
        r.id === id ? { ...r, status, note } : r,
      ),
    },
  };
  if (status !== "passed") return next;
  const done = finishStep(next, request.occurrence, request.stepId);
  const m = done.journey.missions.find(
    (m) => occurrence(m, request.day) === request.occurrence,
  );
  return m
    ? approveMission(done, m.id, request.day, "approved", note, "staff")
    : done;
}
export function buySaver(world: WorldState): WorldState {
  if (world.collection.balance < saverPrice || world.journey.savers >= 99)
    return world;
  return {
    ...world,
    collection: {
      ...world.collection,
      balance: world.collection.balance - saverPrice,
    },
    journey: { ...world.journey, savers: world.journey.savers + 1 },
  };
}
export function tierFor(amount: number): ChestTier {
  return amount >= 1200
    ? "void"
    : amount >= 700
      ? "diamond"
      : amount >= 400
        ? "ruby"
        : amount >= 250
          ? "gold"
          : amount >= 175
            ? "platinum"
            : amount >= 100
              ? "silver"
              : amount >= 50
                ? "bronze"
                : "wood";
}
export const tierRarity: Record<ChestTier, Rarity> = {
  wood: "common",
  bronze: "common",
  silver: "rare",
  platinum: "rare",
  gold: "epic",
  ruby: "legendary",
  diamond: "legendary",
  void: "mythical",
};
export const legacyRewardTables: Record<ChestTier, RewardEntry[]> = {
  wood: [{ kind: "currency", label: "25 Dewdrops", amount: 25, chance: 100 }],
  bronze: [
    { kind: "currency", label: "50 Dewdrops", amount: 50, chance: 90 },
    { kind: "cosmetic", label: "Trail ribbon", item: "trailbow", chance: 10 },
  ],
  silver: [
    { kind: "currency", label: "100 Dewdrops", amount: 100, chance: 85 },
    {
      kind: "cosmetic",
      label: "First light pin",
      item: "dewbadge",
      chance: 15,
    },
  ],
  platinum: [
    { kind: "currency", label: "180 Dewdrops", amount: 180, chance: 75 },
    {
      kind: "cosmetic",
      label: "Moonweave cloak",
      item: "mooncloak",
      chance: 15,
    },
    { kind: "looma", label: "Moth", item: "shadow", chance: 10 },
  ],
  gold: [
    { kind: "currency", label: "300 Dewdrops", amount: 300, chance: 70 },
    {
      kind: "cosmetic",
      label: "Moonweave cloak",
      item: "mooncloak",
      chance: 20,
    },
    { kind: "looma", label: "Ember", item: "fire", chance: 10 },
  ],
  ruby: [
    { kind: "currency", label: "500 Dewdrops", amount: 500, chance: 70 },
    { kind: "cosmetic", label: "Ruby Tiara", item: "rubytiara", chance: 20 },
    { kind: "looma", label: "Rubio", item: "rubio", chance: 10 },
  ],
  diamond: [
    { kind: "currency", label: "900 Dewdrops", amount: 900, chance: 65 },
    { kind: "cosmetic", label: "Prism halo", item: "diamondhalo", chance: 20 },
    { kind: "looma", label: "Rubio", item: "rubio", chance: 15 },
  ],
  void: [
    { kind: "currency", label: "1,500 Dewdrops", amount: 1500, chance: 60 },
    {
      kind: "cosmetic",
      label: "Whisper chains",
      item: "voidchains",
      chance: 20,
    },
    { kind: "looma", label: "Vesper", item: "void", chance: 20 },
  ],
};
export const rewardTables: Record<ChestTier, RewardEntry[]> = {
  wood: [
    { kind: "currency", label: "25 Dewdrops", amount: 25, chance: 90 },
    { kind: "looma", label: "Twill", item: "twig", chance: 10 },
  ],
  bronze: [
    { kind: "currency", label: "50 Dewdrops", amount: 50, chance: 80 },
    { kind: "cosmetic", label: "Trail ribbon", item: "trailbow", chance: 10 },
    { kind: "looma", label: "Rivet", item: "copper", chance: 10 },
  ],
  silver: [
    { kind: "currency", label: "100 Dewdrops", amount: 100, chance: 75 },
    {
      kind: "cosmetic",
      label: "First light pin",
      item: "dewbadge",
      chance: 15,
    },
    { kind: "looma", label: "Lilt", item: "silverling", chance: 10 },
  ],
  platinum: [
    { kind: "currency", label: "180 Dewdrops", amount: 180, chance: 75 },
    {
      kind: "cosmetic",
      label: "Moonweave cloak",
      item: "mooncloak",
      chance: 15,
    },
    { kind: "looma", label: "Purl", item: "plume", chance: 10 },
  ],
  gold: [
    { kind: "currency", label: "300 Dewdrops", amount: 300, chance: 70 },
    {
      kind: "cosmetic",
      label: "Moonweave cloak",
      item: "mooncloak",
      chance: 20,
    },
    { kind: "looma", label: "Marigold", item: "sol", chance: 10 },
  ],
  ruby: legacyRewardTables.ruby,
  diamond: [
    { kind: "currency", label: "900 Dewdrops", amount: 900, chance: 65 },
    { kind: "cosmetic", label: "Prism halo", item: "diamondhalo", chance: 20 },
    { kind: "looma", label: "Flick", item: "facet", chance: 15 },
  ],
  void: legacyRewardTables.void,
};
export const exclusiveByTier: Record<ChestTier, PetForm> = {
  wood: "twig",
  bronze: "copper",
  silver: "silverling",
  platinum: "plume",
  gold: "sol",
  ruby: "rubio",
  diamond: "facet",
  void: "void",
};
export function chestTable(chest: EarnedChest | undefined, tier: ChestTier) {
  return (chest?.tableVersion === 1 ? legacyRewardTables : rewardTables)[tier];
}
export function goodRolls(rolls: number[]) {
  return (
    rolls.length === 6 &&
    rolls.every((n) => Number.isFinite(n) && n >= 0 && n < 1)
  );
}
export function claimMission(
  world: WorldState,
  missionId: string,
  day: string,
  rolls: number[],
): WorldState {
  const m = world.journey.missions.find((m) => m.id === missionId);
  if (!m || !rewardReady(world.journey, m, day) || !goodRolls(rolls))
    return world;
  const key = occurrence(m, day);
  if (world.journey.chests.some((c) => c.occurrence === key)) return world;
  const factor = multiplier(streakCount(world.journey, day)),
    expected = Math.round(m.reward * factor),
    tier = tierFor(expected);
  const chest: EarnedChest = {
    id: `chest:${key}`,
    occurrence: key,
    title: m.title,
    day,
    base: m.reward,
    multiplier: factor,
    expected,
    initialTier: tier,
    tier,
    taps: 0,
    upgradeRolls: rolls.slice(0, 5),
    rewardRoll: rolls[5],
    lastTapAt: 0,
    practice: false,
    tableVersion: 2,
  };
  return {
    ...world,
    journey: { ...world.journey, chests: [chest, ...world.journey.chests] },
  };
}
export function practiceChest(
  world: WorldState,
  tier: ChestTier,
  rolls: number[],
): WorldState {
  if (!goodRolls(rolls) || !chestTiers.includes(tier)) return world;
  const id = `practice:${world.journey.day}:${tier}`;
  if (world.journey.chests.some((c) => c.id === id)) return world;
  const expected = rewardTables[tier][0].amount!;
  const chest: EarnedChest = {
    id,
    occurrence: id,
    title: `${tier} chest · demo sample`,
    day: world.journey.day,
    base: expected,
    multiplier: 1,
    expected,
    initialTier: tier,
    tier,
    taps: 0,
    upgradeRolls: rolls.slice(0, 5),
    rewardRoll: rolls[5],
    lastTapAt: 0,
    practice: true,
    tableVersion: 2,
  };
  return {
    ...world,
    journey: { ...world.journey, chests: [chest, ...world.journey.chests] },
  };
}
export function chestOutcome(chest: EarnedChest, tier: ChestTier): RewardEntry {
  let sum = 0;
  const entry = chestTable(chest, tier).find((r) => {
    sum += r.chance;
    return chest.rewardRoll * 100 < sum;
  })!;
  if (entry.kind === "currency") {
    const amount = Math.max(entry.amount!, chest.expected);
    return { ...entry, amount, label: `${amount.toLocaleString()} Dewdrops` };
  }
  return entry;
}
export function tapChest(
  world: WorldState,
  id: string,
  now: number,
): WorldState {
  const chest = world.journey.chests.find((c) => c.id === id);
  if (
    !chest ||
    chest.taps >= 5 ||
    chest.reward ||
    (chest.taps > 0 && now - chest.lastTapAt < 450)
  )
    return world;
  const index = chestTiers.indexOf(chest.tier),
    tier =
      chest.upgradeRolls[chest.taps] < 0.1
        ? chestTiers[Math.min(index + 1, 7)]
        : chest.tier;
  let next = { ...chest, tier, taps: chest.taps + 1, lastTapAt: now };
  let collection = world.collection;
  if (next.taps === 5) {
    const entry = chestOutcome(next, tier);
    const duplicate =
      entry.kind === "looma"
        ? collection.forms.includes(entry.item as PetForm)
        : entry.kind === "cosmetic"
          ? collection.accessories.includes(entry.item as Accessory)
          : false;
    const compensation = duplicate ? (entry.kind === "looma" ? 150 : 75) : 0;
    next = { ...next, reward: { ...entry, duplicate, compensation } };
    collection = {
      ...collection,
      balance: Math.min(
        1000000,
        collection.balance +
          (entry.kind === "currency" ? entry.amount! : compensation),
      ),
      forms:
        entry.kind === "looma" && !duplicate
          ? [...collection.forms, entry.item as PetForm]
          : collection.forms,
      accessories:
        entry.kind === "cosmetic" && !duplicate
          ? [...collection.accessories, entry.item as Accessory]
          : collection.accessories,
    };
  }
  return {
    ...world,
    collection,
    journey: {
      ...world.journey,
      chests: world.journey.chests.map((c) => (c.id === id ? next : c)),
    },
  };
}
export function validWorld(value: unknown): value is WorldState {
  try {
    const w = value as WorldState,
      j = w.journey;
    return (
      !!w &&
      validCollection(w.collection) &&
      !!j &&
      /^\d{4}-\d{2}-\d{2}$/.test(j.day) &&
      ["live", "demo"].includes(j.clock) &&
      typeof j.processedThrough === "string" &&
      Number.isInteger(j.savers) &&
      j.savers >= 0 &&
      j.savers <= 99 &&
      Array.isArray(j.missions) &&
      j.missions.every(
        (m) =>
          typeof m.id === "string" &&
          typeof m.title === "string" &&
          typeof m.date === "string" &&
          typeof m.time === "string" &&
          typeof m.repeat === "boolean" &&
          Number.isFinite(m.reward) &&
          Array.isArray(m.steps) &&
          m.steps.every(
            (s) =>
              typeof s.id === "string" &&
              typeof s.title === "string" &&
              ["check", "submission", "room"].includes(s.kind),
          ),
      ) &&
      !!j.completedSteps &&
      Object.values(j.completedSteps).every(
        (v) => Array.isArray(v) && v.every((s) => typeof s === "string"),
      ) &&
      Array.isArray(j.qualifiedDays) &&
      j.qualifiedDays.every((d) => typeof d === "string") &&
      Array.isArray(j.protectedDays) &&
      j.protectedDays.every((d) => typeof d === "string") &&
      Array.isArray(j.chests) &&
      j.chests.every(
        (c) =>
          typeof c.id === "string" &&
          chestTiers.includes(c.tier) &&
          chestTiers.includes(c.initialTier) &&
          Number.isInteger(c.taps) &&
          c.taps >= 0 &&
          c.taps <= 5 &&
          goodRolls([...c.upgradeRolls, c.rewardRoll]) &&
          (c.taps < 5 || !!c.reward),
      ) &&
      Array.isArray(j.submissions) &&
      j.submissions.every(
        (s) =>
          typeof s.id === "string" &&
          typeof s.title === "string" &&
          typeof s.teacher === "string" &&
          typeof s.subject === "string" &&
          typeof s.summary === "string" &&
          ["submitted", "reviewed", "needs-revision"].includes(s.status),
      ) &&
      Array.isArray(j.rooms) &&
      j.rooms.every(
        (r) =>
          typeof r.id === "string" &&
          typeof r.day === "string" &&
          typeof r.occurrence === "string" &&
          ["ready", "passed", "follow-up"].includes(r.status),
      )
    );
  } catch {
    return false;
  }
}

export const rewardPresets = [
  { id: "room", label: "Room ready · 25", amount: 25 },
  { id: "assignment", label: "Assignment · 50", amount: 50 },
  { id: "group", label: "Approved study & activity · 100", amount: 100 },
  { id: "extended", label: "Extended effort · 175", amount: 175 },
  { id: "project", label: "Project milestone · 250", amount: 250 },
  { id: "major", label: "Major project · 400", amount: 400 },
  { id: "term", label: "Term contribution · 700", amount: 700 },
  { id: "milestone", label: "Exceptional milestone · 1,200", amount: 1200 },
];
export function reviewComplete(j: JourneyState, m: Mission, day = j.day) {
  const key = occurrence(m, day);
  return m.steps.every((step) =>
    step.kind === "submission"
      ? j.submissions.some(
          (s) =>
            s.occurrence === key &&
            s.stepId === step.id &&
            s.status === "reviewed",
        )
      : step.kind === "room"
        ? j.rooms.some(
            (r) =>
              r.occurrence === key &&
              r.stepId === step.id &&
              r.status === "passed",
          )
        : true,
  );
}
export function rewardReady(j: JourneyState, m: Mission, day = j.day) {
  return (
    m.kind === "reward" &&
    !!m.authorisedBy &&
    m.reward > 0 &&
    finished(j, m, day) &&
    reviewComplete(j, m, day) &&
    j.approvals?.[occurrence(m, day)]?.status === "approved"
  );
}
export function requestApproval(w: WorldState, missionId: string): WorldState {
  const j = w.journey,
    m = j.missions.find((m) => m.id === missionId);
  if (
    !m ||
    m.kind !== "reward" ||
    !finished(j, m) ||
    j.approvals?.[occurrence(m, j.day)]?.status === "approved"
  )
    return w;
  const key = occurrence(m, j.day);
  return {
    ...w,
    journey: {
      ...j,
      approvals: {
        ...j.approvals,
        [key]: {
          status: "pending",
          note: "Requested by the fictional student.",
        },
      },
    },
  };
}
export function approveMission(
  w: WorldState,
  id: string,
  day: string,
  status: "approved" | "follow-up",
  note: string,
  actor: "student" | "staff" = "student",
): WorldState {
  const m = w.journey.missions.find((m) => m.id === id),
    key = m ? occurrence(m, day) : "";
  if (
    actor !== "staff" ||
    !m ||
    m.kind !== "reward" ||
    !finished(w.journey, m, day) ||
    w.journey.chests.some((c) => c.occurrence === key) ||
    (status === "approved" && !reviewComplete(w.journey, m, day))
  )
    return w;
  let j: JourneyState = {
    ...w.journey,
    approvals: { ...w.journey.approvals, [key]: { status, note } },
  };
  if (status === "approved") j = qualify(j, day);
  return { ...w, journey: j };
}
export function reviewHandIn(
  w: WorldState,
  id: string,
  status: Submission["status"],
  staffNote: string,
  actor: "student" | "staff" = "student",
): WorldState {
  if (actor !== "staff") return w;
  const sub = w.journey.submissions.find((s) => s.id === id);
  if (!sub) return w;
  const next = {
    ...w,
    journey: {
      ...w.journey,
      submissions: w.journey.submissions.map((s) =>
        s.id === id ? { ...s, status, staffNote } : s,
      ),
    },
  };
  const m = next.journey.missions.find(
    (m) => occurrence(m, sub.day) === sub.occurrence,
  );
  return m && status === "reviewed"
    ? approveMission(next, m.id, sub.day, "approved", staffNote, "staff")
    : next;
}
export function migrateWorld(w: WorldState): WorldState {
  if (w.schema === 3) return w;
  const missions = w.journey.missions.map((m) => {
    const seed = initialJourney.missions.find(
      (s) =>
        s.id === m.id &&
        s.title === m.title &&
        s.reward === m.reward &&
        JSON.stringify(s.steps) === JSON.stringify(m.steps),
    );
    return seed
      ? {
          ...m,
          kind: "reward" as const,
          authorisedBy: seed.authorisedBy,
          preset: seed.preset,
        }
      : {
          ...m,
          kind: "goal" as const,
          reward: 0,
          authorisedBy: undefined,
          preset: undefined,
        };
  });
  return {
    ...w,
    schema: 3,
    journey: {
      ...w.journey,
      missions,
      approvals: w.journey.approvals ?? {},
      chests: w.journey.chests.map((c) => ({
        ...c,
        tableVersion: c.tableVersion ?? 1,
      })),
    },
  };
}
