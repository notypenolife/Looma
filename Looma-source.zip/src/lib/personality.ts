import type { PetForm } from "./types";
import type { PetEvent } from "./collection";
import { performances } from "./behaviours";
import { eventPerformance, presence } from "./embodiment";
export function personalityReaction(
  form: PetForm,
  event: PetEvent,
  hour: number,
  variant = 0,
) {
  const action = eventPerformance(
    form,
    event,
    Math.abs(variant),
    performances(form),
  );
  return {
    expression: action.expression,
    line:
      event === "hello" && (hour >= 21 || hour < 6)
        ? presence[form].rest
        : action.line,
    animation: action.motion,
  };
}
