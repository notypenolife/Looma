import { DEMO_DATE } from "./data/mock";
import type { Room, Task } from "./types";
export function dueLabel(date: string) {
  const days = Math.round(
    (Date.parse(`${date}T12:00:00Z`) - Date.parse(`${DEMO_DATE}T12:00:00Z`)) /
      86400000,
  );
  return days === 0
    ? "Today"
    : days === 1
      ? "Tomorrow"
      : days < 0
        ? "Overdue"
        : new Intl.DateTimeFormat("en-NZ", {
            weekday: "short",
            day: "numeric",
            month: "short",
            timeZone: "Pacific/Auckland",
          }).format(new Date(`${date}T00:00:00Z`));
}
export function roomSummary(rooms: Room[]) {
  return {
    total: rooms.length,
    passed: rooms.filter((r) => r.status === "passed").length,
    followUp: rooms.filter((r) => r.status === "follow-up").length,
    unchecked: rooms.filter((r) => r.status === "unchecked").length,
    checked: rooms.filter((r) => r.status !== "unchecked").length,
  };
}
export function openTasks(tasks: Task[]) {
  return tasks
    .filter((t) => !t.complete)
    .sort((a, b) => a.due.localeCompare(b.due));
}
export function uid() {
  return crypto.randomUUID();
}
