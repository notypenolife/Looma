/** Browser-local DEMO adapter. Never import this into a production reward endpoint.
 * Core operations retain evidence/staff checks. Real approvals require a verified
 * server role and transaction; the demo actor below is explicitly simulated. */
import {
  approveMission,
  claimMission,
  finished,
  occurrence,
  reviewHandIn,
  reviewRoom,
  type WorldState,
} from "./journey";
export const demoApprovalNote =
  "Demo auto-approved · simulated acceptance only. Nothing was sent to staff.";
export function acceptDemoCompletion(
  world: WorldState,
  missionId: string,
  rolls: number[],
): WorldState {
  const m = world.journey.missions.find((m) => m.id === missionId);
  if (!m) return world;
  const key = occurrence(m, world.journey.day);
  let next = world;
  for (const s of world.journey.submissions.filter(
    (s) => s.occurrence === key && s.status === "submitted",
  ))
    next = reviewHandIn(next, s.id, "reviewed", demoApprovalNote, "staff");
  for (const r of world.journey.rooms.filter(
    (r) => r.occurrence === key && r.status === "ready",
  ))
    next = reviewRoom(next, r.id, "passed", demoApprovalNote, "staff");
  if (m.kind !== "reward" || !m.authorisedBy || !finished(next.journey, m))
    return next;
  next = approveMission(
    next,
    m.id,
    next.journey.day,
    "approved",
    demoApprovalNote,
    "staff",
  );
  return claimMission(next, m.id, next.journey.day, rolls);
}
