import type { PetForm, Expression } from "./types";
import type { PetEvent } from "./collection";
import type { Motion, Performance, Prop } from "./behaviours";
interface Presence {
  eyes: "round" | "almond" | "droop" | "wide";
  brow: number;
  gaze: number;
  hello: string;
  play: string;
  rest: string;
  snack: string;
  focus: string;
  achievement: string;
  surprise: string;
}
/** Individual acting notes and first-person speech, independent of academic records. */
export const presence: Record<PetForm, Presence> = {
  sprout: {
    eyes: "round",
    brow: 0,
    gaze: -1,
    hello: "I’m checking the light. A good day for little beginnings.",
    play: "I can hop over one imaginary seed. Watch my leaves!",
    rest: "I’m folding my leaves. I’ll grow quietly for a bit.",
    snack: "I brought a leaf-sized biscuit. That’s my kind of harvest.",
    focus: "I’m drawing a tiny plan. Let’s grow one idea at a time.",
    achievement: "I grew a little grin for that. A good bit of work.",
    surprise: "I found something new to investigate. Is it a seed?",
  },
  pebble: {
    eyes: "droop",
    brow: 1,
    gaze: 0,
    hello: "I was being stationary. I’m rather good at it.",
    play: "I’m attempting a small hop. Please contain your astonishment.",
    rest: "I’ll sit here while you finish that last bit. Eyes closed, naturally.",
    snack: "I’ll have one biscuit. I believe in steady crunching.",
    focus: "I’m reading the useful sentence. There’s usually one.",
    achievement: "I nodded. That was my entire parade.",
    surprise: "I raised an eyebrow. I’m impressed, quietly.",
  },
  pip: {
    eyes: "round",
    brow: -2,
    gaze: 2,
    hello: "I took the scenic route to hello. I’m here now!",
    play: "I’m taking off! I’ve checked which way is up.",
    rest: "I’m tucking my wings in. No more detours for a moment.",
    snack: "I saved a crumb for the road. Where was the road?",
    focus: "I’m studying my little map. We can find a clear route.",
    achievement: "I found the right direction. Look at you go!",
    surprise: "I didn’t put that on the map. I’d better look.",
  },
  water: {
    eyes: "wide",
    brow: -3,
    gaze: 2,
    hello: "I’m watching a bubble. Oh! I found you instead.",
    play: "I can make a little splash without getting your homework wet!",
    rest: "I’m becoming a very quiet puddle. Just a little rest.",
    snack: "I’m nibbling a dewdrop biscuit. Crunch, then splash.",
    focus: "I’m following one little idea downstream. Want to try?",
    achievement: "I did a tiny ripple of applause for you!",
    surprise: "I’ve got approximately six questions about that.",
  },
  fire: {
    eyes: "almond",
    brow: -4,
    gaze: 1,
    hello: "I’m warming up my toes. Ready for a little start?",
    play: "I’ve got one warm-up jump left in me. Here goes!",
    rest: "I’m turning down my flame. Warm toes, quiet eyes.",
    snack: "I toasted my biscuit exactly right. Mostly.",
    focus: "I’m keeping one small idea warm. Let’s begin there.",
    achievement: "I’m doing my little victory bounce. You finished it!",
    surprise: "I wasn’t expecting that. My flame did a double take!",
  },
  electricity: {
    eyes: "wide",
    brow: -5,
    gaze: 3,
    hello: "I counted three ideas before you arrived. I’ll pick one.",
    play: "I’m charging my toes for a jump. Three, two—boing!",
    rest: "I’m switching to quiet mode. Even my ears need a pause.",
    snack: "I’m testing this biscuit for crunch potential.",
    focus: "I’m putting my extra ideas in a queue. One at a time.",
    achievement: "I’m buzzing about that finish. A very tiny buzz!",
    surprise: "I think my ears noticed before I did!",
  },
  shadow: {
    eyes: "almond",
    brow: 2,
    gaze: -2,
    hello: "I saved your place. Want to read for a bit?",
    play: "I’ll put my bookmark in first. One shy little hop.",
    rest: "I’m closing my book and curling up beside it.",
    snack: "I keep my biscuit away from the pages. Mostly.",
    focus: "I’m turning to a clear page. I’ll read quietly with you.",
    achievement: "I made you a bookmark that says ‘done’. I’m smiling.",
    surprise: "I’m peeking over my book. That deserves a closer look.",
  },
  fiend: {
    eyes: "almond",
    brow: -5,
    gaze: 3,
    hello: "I was absolutely not hiding your pencil. Hello, though.",
    play: "I’m practising my innocent landing. Nothing suspicious here!",
    rest: "I’m closing my eyes. My tiny pranks can wait.",
    snack: "I borrowed this biscuit. From my own biscuit tin, obviously.",
    focus:
      "I’m reading my harmless prank ledger. Today’s prank: being organised.",
    achievement: "I was absolutely not hiding your pencil. Anyway—nice work.",
    surprise: "I didn’t summon that. I’m checking the packaging.",
  },
  twig: {
    eyes: "round",
    brow: 1,
    gaze: -1,
    hello: "I’m sorting my little twigs. I saved a straight one.",
    play: "I’m hopping over my twig pile. I measured it twice.",
    rest: "I’m nestling into my shavings. Soft little corners.",
    snack: "I’m tasting a woodsmoke biscuit. No actual wood involved.",
    focus: "I’m sketching a tiny shelf. One piece at a time.",
    achievement: "I carved a little tick for that. I’m keeping it.",
    surprise: "I’m checking the grain. That’s a curious little find.",
  },
  copper: {
    eyes: "round",
    brow: -1,
    gaze: 1,
    hello: "I’m testing my tiny gears. All accounted for!",
    play: "I’ve tightened my imaginary bolts. Time for a spring test!",
    rest: "I’m parking my feet and letting the gears go quiet.",
    snack: "I’m having a biscuit break. No crumbs in the gears.",
    focus: "I’m checking the diagram. We can build this in small steps.",
    achievement: "I made a little click of approval. Everything fits.",
    surprise: "I’d like to inspect that mechanism. Carefully.",
  },
  silverling: {
    eyes: "wide",
    brow: -2,
    gaze: -1,
    hello: "I’m humming a small hello. Can you hear my bell?",
    play: "I’m trying a hop in three-four time. Ding, step, land!",
    rest: "I’m letting my last little note fade into a nap.",
    snack: "I’m making a very quiet biscuit crunch. Almost musical.",
    focus: "I’m counting a slow rhythm. We can work to that.",
    achievement: "I saved three bright notes for you. Ding, ding, done!",
    surprise: "I heard a new little note in that discovery.",
  },
  plume: {
    eyes: "almond",
    brow: 1,
    gaze: -2,
    hello: "I’m straightening my little labels. Hello, lovely timing.",
    play: "I’m demonstrating a carefully arranged hop. Mind the curl.",
    rest: "I’m setting my treasures down and curling up neatly.",
    snack: "I put my biscuit on a very small saucer.",
    focus: "I’m organising one page. Then perhaps another.",
    achievement: "I’m giving that my considered nod. Nicely finished.",
    surprise: "I’m making a little space in my collection for that.",
  },
  sol: {
    eyes: "round",
    brow: -2,
    gaze: 1,
    hello: "I’m setting out my imaginary picnic. I remembered the napkins!",
    play: "I’m hopping over the picnic blanket. No crumbs left behind!",
    rest: "I’m folding my petals for a sunny little nap.",
    snack: "I packed a biscuit and a spare. I’m having the spare.",
    focus: "I’m laying out one good idea. We’ll make room for the rest.",
    achievement: "I brought a little picnic cheer. You finished a good bit!",
    surprise: "I didn’t pack that. I’m delighted to have a look.",
  },
  rubio: {
    eyes: "almond",
    brow: -3,
    gaze: 2,
    hello: "I’m checking my reflection. A tiny entrance deserves care.",
    play: "I’m rehearsing a royal leap. Please admire the landing.",
    rest: "I’m putting my crown on quiet duty. Royal nap time.",
    snack: "I’m sampling this biscuit with excellent manners.",
    focus: "I’m drafting a very small decree: one task at a time.",
    achievement: "I’m giving you my most splendid bow. Well finished.",
    surprise: "I believe that deserves a royal inspection.",
  },
  facet: {
    eyes: "wide",
    brow: -4,
    gaze: 2,
    hello: "I’m following a little patch of light. Oh, there you are!",
    play: "I’m trying a prism jump. Watch where the light lands!",
    rest: "I’m folding the bright bits away for a cool little nap.",
    snack: "I’m testing the sparkle-to-crunch ratio of this biscuit.",
    focus: "I’m lining up the angles. One clear thought next.",
    achievement: "I caught a glint for you. I thought that was brilliant.",
    surprise: "I’m looking at that from every little angle.",
  },
  void: {
    eyes: "almond",
    brow: -2,
    gaze: -2,
    hello: "I’m guarding a very tiny mystery. It might be a biscuit.",
    play: "I’m practising my dramatic leap. My chains know the choreography.",
    rest: "I’m folding my wings into a pocket of quiet.",
    snack: "I found a midnight biscuit. I’m investigating thoroughly.",
    focus: "I’m reading the footnotes of a small mystery. Quiet company?",
    achievement: "I give that my solemn nod. I’m secretly rather pleased.",
    surprise: "I’m peering into the unknown. It looks surprisingly friendly.",
  },
  pumpkin: {
    eyes: "round",
    brow: -1,
    gaze: 1,
    hello: "I’m checking my little lantern. A warm hello for you.",
    play: "I’m bouncing over an imaginary pumpkin patch!",
    rest: "I’m dimming my lantern and tucking my toes in.",
    snack: "I brought a pumpkin biscuit. I’m a little predictable.",
    focus: "I’m keeping a lantern on our next small step.",
    achievement: "I’m glowing a little brighter. You finished it!",
    surprise: "I’m lighting up the corners for a closer look.",
  },
  ghost: {
    eyes: "wide",
    brow: 2,
    gaze: -2,
    hello: "I was practising a very gentle boo. Hello is easier.",
    play: "I’m trying a soft little float-jump. Boo, but politely!",
    rest: "I’m becoming a sleepy little blanket. No haunting scheduled.",
    snack: "I’m making this biscuit disappear. A useful ghost skill.",
    focus: "I’m reading quietly. I won’t float across your page.",
    achievement: "I’m holding up a small hooray. You can see it, right?",
    surprise: "I surprised myself. I’d better take another look.",
  },
  bat: {
    eyes: "almond",
    brow: -3,
    gaze: 2,
    hello: "I’m unfolding one wing to say hello. Two felt excessive.",
    play: "I’m practising a soft landing. Watch my wings catch me!",
    rest: "I’m wrapping my wings round my toes. A tidy little nap.",
    snack: "I’m nibbling upside down in spirit. This way is less crumbly.",
    focus: "I’m checking a little night map. We can find a path.",
    achievement: "I’m offering two approving wingbeats. Nicely done.",
    surprise: "I heard something interesting. I’m tilting both ears.",
  },
  witch: {
    eyes: "almond",
    brow: -4,
    gaze: 1,
    hello: "I’m brewing a cup of ordinary tea. Mysteriously ordinary.",
    play: "I’m attempting a hop without losing my hat. An advanced spell!",
    rest: "I’m putting my wand away and stirring up a small nap.",
    snack: "I baked a biscuit. I promise it stays a biscuit.",
    focus: "I’m reading the instructions before the spell. Sensible, really.",
    achievement: "I made a little flourish for you. No homework was enchanted.",
    surprise: "I’m checking whether that needs a label or a tiny spell.",
  },
  eclipse: {
    eyes: "almond",
    brow: 0,
    gaze: -1,
    hello: "I’m balancing a little moonlight. Hello from the quiet side.",
    play: "I’m hopping between patches of imaginary light.",
    rest: "I’m closing the day into a little crescent of sleep.",
    snack: "I’m sharing a biscuit with my shadow. More for me, technically.",
    focus: "I’m keeping a clear patch of night for one small thought.",
    achievement: "I’m raising a quiet star for you. A lovely little finish.",
    surprise: "I’m turning toward the light for a better look.",
  },
};
export function performanceLine(
  form: PetForm,
  motion: Motion,
  prop: Prop,
  category: Performance["category"],
  variant = 0,
) {
  const p = presence[form];
  if (motion === "doze") return p.rest;
  if (prop === "crumb" || motion === "eat") return p.snack;
  if (category === "achievement") return p.achievement;
  if (category === "surprise") return p.surprise;
  if (category === "entrance") return p.hello;
  if (motion === "read") return p.focus;
  const activities: Partial<Record<Prop, string>> = {
    book: "I’m turning a little page.",
    note: "I’m checking my little note.",
    leaf: "I’m taking a closer look at this leaf.",
    pencil: "I’m sketching a little plan.",
    stone: "I’m inspecting a very small stone.",
    gear: "I’m checking a tiny gear.",
    bell: "I’m listening for a small note.",
    gem: "I’m looking for a glint in this little gem.",
    cup: "I’m taking a quiet sip.",
    star: "I’m following this little star.",
    wand: "I’m practising a harmless flourish.",
    lantern: "I’m checking my little light.",
  };
  const gestures: Partial<Record<Motion, string>> = {
    stretch: "I’m stretching my little sides. That’s better.",
    fidget: "I’m adjusting a little detail. Nearly right.",
    wave: p.hello,
    nod: "I’m practising my smallest nod.",
    bow: "I’m trying a very small bow.",
    sneak: p.hello,
    peek: p.surprise,
    inspect: p.surprise,
    spin: "I’m looking this way. And now that way.",
    flap: "I’m testing my little take-off muscles.",
    float: "I’m drifting a little closer for a look.",
    sway: "I’m finding my balance. A little to the left.",
    hop: p.play,
    skid: p.play,
  };
  return `${activities[prop] ?? gestures[motion] ?? (variant % 2 ? p.hello : p.rest)} ${category === "idle" && prop !== "none" ? p.hello.split(". ")[0] + "." : ""}`.trim();
}
export function eventPerformance(
  form: PetForm,
  event: PetEvent,
  variant: number,
  actions: Performance[],
): Performance {
  const category =
    event === "task" || event === "play"
      ? "achievement"
      : event === "crate"
        ? "surprise"
        : event === "rest" || event === "focus"
          ? "focus"
          : "entrance";
  const pool = actions.filter((p) => p.category === category),
    base = pool[variant % pool.length];
  const p = presence[form];
  const motion: Motion =
    event === "play"
      ? "hop"
      : event === "rest"
        ? "doze"
        : event === "snack"
          ? "eat"
          : event === "focus"
            ? "read"
            : base.motion;
  const expression: Expression =
    event === "rest" ? "sleepy" : event === "snack" ? "happy" : base.expression;
  return {
    ...base,
    motion,
    expression,
    prop:
      event === "rest" || event === "play"
        ? "none"
        : event === "snack"
          ? "crumb"
          : event === "focus"
            ? "book"
            : base.prop,
    duration:
      event === "play"
        ? 2100
        : event === "snack"
          ? 3300
          : event === "rest"
            ? 6500
            : base.duration,
    line:
      event === "play"
        ? p.play
        : event === "rest"
          ? p.rest
          : event === "snack"
            ? p.snack
            : event === "focus"
              ? p.focus
              : event === "hello"
                ? p.hello
                : base.line,
  };
}
