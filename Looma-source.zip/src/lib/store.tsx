"use client";
import {
  createContext,
  useContext,
  useMemo,
  useSyncExternalStore,
  useCallback,
  useEffect,
  useState,
} from "react";
import { defaultPet, initialStudent, initialStaff } from "./data/mock";
import type {
  PetPreferences,
  StudentData,
  StaffData,
  NotificationPreferences,
} from "./types";
import {
  validCollection,
  validForms,
  validAccessories,
  purchaseCrate,
  type CollectionState,
  type PetEvent,
  type CrateKind,
} from "./collection";
import {
  initialWorld,
  initialJourney,
  validWorld,
  aucklandDay,
  settleDay,
  completeCheck,
  saveMission,
  submitAssignment,
  requestRoom,
  reviewRoom,
  buySaver,
  claimMission,
  tapChest,
  practiceChest,
  finished,
  rewardReady,
  migrateWorld,
  approveMission,
  requestApproval,
  reviewHandIn,
  occurrence,
  type Mission,
  type Submission,
  type ChestTier,
} from "./journey";
import { acceptDemoCompletion } from "./demo-acceptance";
import { clearLoomaStorage } from "./reset-demo";
const event = "looma:storage";
const fallbackMemory = new Map<string, string>();
const storageErrors = new Set<() => void>();
let storageUnavailable = false;
function subscribe(callback: () => void) {
  window.addEventListener("storage", callback);
  window.addEventListener(event, callback);
  return () => {
    window.removeEventListener("storage", callback);
    window.removeEventListener(event, callback);
  };
}
function read(key: string) {
  if (fallbackMemory.has(key)) return fallbackMemory.get(key)!;
  try {
    const raw = window.localStorage.getItem(key);
    if (raw === null && key === "looma:v2:world") {
      const legacy = window.localStorage.getItem("looma:v1:collection");
      if (legacy) {
        const collection: unknown = JSON.parse(legacy);
        if (validCollection(collection))
          return JSON.stringify({ collection, journey: initialJourney });
      }
    }
    if (raw && key === "looma:v2:world") {
      const parsed: unknown = JSON.parse(raw);
      if (validWorld(parsed)) return JSON.stringify(migrateWorld(parsed));
    }
    return raw;
  } catch {
    return null;
  }
}
function write(key: string, value: unknown) {
  const raw = JSON.stringify(value);
  try {
    window.localStorage.setItem(key, raw);
    fallbackMemory.delete(key);
  } catch {
    fallbackMemory.set(key, raw);
    storageUnavailable = true;
    storageErrors.forEach((fn) => fn());
  }
  window.dispatchEvent(new Event(event));
}
function validPet(value: unknown): value is PetPreferences {
  const v = value as PetPreferences;
  return (
    !!v &&
    typeof v.name === "string" &&
    v.name.length > 0 &&
    v.name.length <= 24 &&
    validForms.includes(v.form) &&
    ["sage", "apricot", "blue", "gold"].includes(v.colour) &&
    validAccessories.includes(v.accessory) &&
    ["warm", "concise", "playful"].includes(v.tone)
  );
}
function validStudent(value: unknown): value is StudentData {
  const v = value as StudentData;
  return (
    !!v &&
    Array.isArray(v.tasks) &&
    Array.isArray(v.memories) &&
    v.tasks.every(
      (t) =>
        typeof t.id === "string" &&
        typeof t.title === "string" &&
        typeof t.subject === "string" &&
        typeof t.notes === "string" &&
        /^\d{4}-\d{2}-\d{2}$/.test(t.due) &&
        typeof t.complete === "boolean",
    ) &&
    v.memories.every(
      (m) =>
        typeof m.id === "string" &&
        typeof m.text === "string" &&
        typeof m.approvedAt === "string",
    )
  );
}
function validStaff(value: unknown): value is StaffData {
  const v = value as StaffData;
  return (
    !!v &&
    Array.isArray(v.rooms) &&
    Array.isArray(v.detentions) &&
    Array.isArray(v.tasks) &&
    v.rooms.every(
      (r) =>
        typeof r.id === "string" &&
        typeof r.number === "string" &&
        typeof r.house === "string" &&
        typeof r.residents === "string" &&
        typeof r.note === "string" &&
        typeof r.reason === "string" &&
        ["unchecked", "passed", "follow-up"].includes(r.status),
    ) &&
    v.detentions.every(
      (d) =>
        typeof d.id === "string" &&
        typeof d.student === "string" &&
        typeof d.reason === "string" &&
        typeof d.house === "string" &&
        typeof d.session === "string" &&
        typeof d.note === "string" &&
        ["Scheduled", "Completed", "Follow-up"].includes(d.status),
    ) &&
    v.tasks.every(
      (t) =>
        typeof t.id === "string" &&
        typeof t.title === "string" &&
        typeof t.complete === "boolean",
    )
  );
}
function usePersistent<T>(
  key: string,
  initial: T,
  validate: (v: unknown) => v is T,
) {
  const raw = useSyncExternalStore(
    subscribe,
    () => read(key),
    () => null,
  );
  const value = useMemo(() => {
    if (!raw) return initial;
    try {
      const parsed: unknown = JSON.parse(raw);
      return validate(parsed) ? parsed : initial;
    } catch {
      return initial;
    }
  }, [raw, initial, validate]);
  const set = useCallback(
    (next: T | ((v: T) => T)) => {
      let current = initial;
      try {
        const saved = read(key);
        const parsed: unknown = saved ? JSON.parse(saved) : null;
        if (validate(parsed)) current = parsed;
      } catch {
        /* Invalid saved state falls back to fictional defaults. */
      }
      write(
        key,
        typeof next === "function" ? (next as (v: T) => T)(current) : next,
      );
    },
    [key, initial, validate],
  );
  return [value, set] as const;
}
const notifications: NotificationPreferences = {
  homework: true,
  boarding: true,
  quiet: true,
};
function validNotifications(v: unknown): v is NotificationPreferences {
  const n = v as NotificationPreferences;
  return (
    !!n &&
    typeof n.homework === "boolean" &&
    typeof n.boarding === "boolean" &&
    typeof n.quiet === "boolean"
  );
}
function useDemoValue() {
  const [pet, setPet] = usePersistent(
    "looma:v1:companion",
    defaultPet,
    validPet,
  );
  const [student, setStudent] = usePersistent(
    "looma:v1:student",
    initialStudent,
    validStudent,
  );
  const [staff, setStaff] = usePersistent(
    "looma:v1:staff",
    initialStaff,
    validStaff,
  );
  const [preferences, setPreferences] = usePersistent(
    "looma:v1:notifications",
    notifications,
    validNotifications,
  );
  const persistenceError = useSyncExternalStore(
    (fn) => {
      storageErrors.add(fn);
      return () => storageErrors.delete(fn);
    },
    () => storageUnavailable,
    () => false,
  );
  const [world, setWorld] = usePersistent(
    "looma:v2:world",
    initialWorld,
    validWorld,
  );
  const { collection, journey } = world;
  const [resetVersion, setResetVersion] = useState(0);
  const [resetNotice, setResetNotice] = useState(false);
  const [celebration, setCelebration] = useState<{
    id: string;
    title: string;
    event: PetEvent;
  } | null>(null);
  const [feedback, setFeedback] = useState<{
    id: string;
    title: string;
    event: PetEvent;
    target?: string;
  } | null>(null);
  const celebrate = useCallback(
    (title: string, event: PetEvent = "task", target?: string) =>
      setFeedback({ id: crypto.randomUUID(), title, event, target }),
    [],
  );
  const dismissCelebration = useCallback(() => setCelebration(null), []);
  const setCollection = (
    next: CollectionState | ((c: CollectionState) => CollectionState),
  ) =>
    setWorld((w) => ({
      ...w,
      collection: typeof next === "function" ? next(w.collection) : next,
    }));
  const entropy = () =>
    Array.from(
      crypto.getRandomValues(new Uint32Array(6)),
      (n) => n / 4294967296,
    );
  useEffect(() => {
    const sync = () =>
      setWorld((w) =>
        w.journey.clock === "live"
          ? settleDay(w, aucklandDay(new Date()), "live")
          : w,
      );
    sync();
    const timer = setInterval(sync, 60000);
    window.addEventListener("focus", sync);
    return () => {
      clearInterval(timer);
      window.removeEventListener("focus", sync);
    };
  }, [setWorld]);
  const openCrate = (kind: CrateKind, id: string) => {
    const rolls = entropy();
    setCollection((c) => purchaseCrate(c, kind, rolls[0], rolls[1], id));
  };
  const completeMissionStep = (missionId: string, stepId: string) => {
    const m = journey.missions.find((m) => m.id === missionId);
    const wasFinished = m && finished(journey, m);
    const rolls = entropy();
    setWorld((w) =>
      acceptDemoCompletion(
        completeCheck(w, missionId, stepId),
        missionId,
        rolls,
      ),
    );
    if (
      m &&
      !wasFinished &&
      m.steps.every(
        (s) =>
          s.id === stepId ||
          (journey.completedSteps[occurrence(m, journey.day)] ?? []).includes(
            s.id,
          ),
      )
    )
      celebrate(
        m.kind === "reward"
          ? "Demo auto-approved. Your chest is ready."
          : "A little goal, finished.",
        "task",
        m.id,
      );
  };
  const claimMissionChest = (missionId: string, day = journey.day) => {
    const m = journey.missions.find((m) => m.id === missionId);
    if (
      !m ||
      !rewardReady(journey, m, day) ||
      journey.chests.some((c) => c.occurrence === occurrence(m, day))
    )
      return;
    const rolls = entropy();
    setWorld((w) => claimMission(w, missionId, day, rolls));
    celebrate(
      "Chest collected. Unwrap it whenever you like.",
      "crate",
      missionId,
    );
  };
  const tapEarnedChest = (id: string) => {
    const chest = journey.chests.find((c) => c.id === id),
      now = Date.now();
    if (
      !chest ||
      chest.taps >= 5 ||
      (chest.taps > 0 && now - chest.lastTapAt < 450)
    )
      return;
    setWorld((w) => tapChest(w, id, now));
    if (chest.taps === 4) {
      const result = tapChest(
        { collection, journey, schema: 3 },
        id,
        now,
      ).journey.chests.find((c) => c.id === id)?.reward;
      if (result) celebrate("Something lovely, just unwrapped.", "crate", id);
    }
  };
  const submitDemo = (submission: Submission) => {
    const rolls = entropy();
    setWorld((w) => {
      const next = submitAssignment(w, submission);
      const m = next.journey.missions.find(
        (m) => occurrence(m, next.journey.day) === submission.occurrence,
      );
      return m ? acceptDemoCompletion(next, m.id, rolls) : next;
    });
    celebrate("Handed in. A little breathing room.");
  };
  const reviewRoomRequest = (
    id: string,
    status: "passed" | "follow-up",
    note: string,
  ) => {
    const request = journey.rooms.find((r) => r.id === id);
    if (!request || request.status === "passed") return;
    setWorld((w) => reviewRoom(w, id, status, note, "staff"));
    setStaff((s) => ({
      ...s,
      rooms: s.rooms.map((r) =>
        r.id === request.roomId
          ? {
              ...r,
              status,
              note,
              reason: status === "follow-up" ? "Shared space" : "",
              updatedAt: new Date().toISOString(),
            }
          : r,
      ),
    }));
  };
  const reset = () => {
    try {
      clearLoomaStorage(window.localStorage);
      clearLoomaStorage(window.sessionStorage);
    } catch {
      storageUnavailable = true;
      storageErrors.forEach((fn) => fn());
    }
    for (const key of fallbackMemory.keys())
      if (key.startsWith("looma:")) fallbackMemory.delete(key);
    setWorld(
      settleDay(structuredClone(initialWorld), aucklandDay(new Date()), "live"),
    );
    setCelebration(null);
    setFeedback(null);
    setPet(defaultPet);
    setStudent(initialStudent);
    setStaff(initialStaff);
    setPreferences(notifications);
    setResetNotice(true);
    setResetVersion((n) => n + 1);
  };
  return {
    resetVersion,
    resetNotice,
    acknowledgeReset: () => setResetNotice(false),
    journey,
    feedback,
    celebration,
    celebrate,
    dismissCelebration,
    completeMissionStep,
    claimMissionChest,
    tapEarnedChest,
    celebrateMythical: (id: string) => {
      const current = read("looma:v2:world");
      const latest = current ? JSON.parse(current) : null;
      const c = (validWorld(latest) ? latest.journey : journey).chests.find(
        (c) => c.id === id,
      );
      if (
        c?.reward?.kind === "looma" &&
        !c.reward.duplicate &&
        ["void", "eclipse"].includes(c.reward.item as string)
      )
        setCelebration({
          id: crypto.randomUUID(),
          title: "A mythical little first.",
          event: "crate",
        });
    },
    submitDemo,
    reviewRoomRequest,
    saveMission: (mission: Mission) =>
      setWorld((w) => saveMission(w, mission, "student")),
    saveStaffMission: (mission: Mission) =>
      setWorld((w) => saveMission(w, mission, "staff")),
    requestMissionReview: (id: string) => {
      const rolls = entropy();
      setWorld((w) => acceptDemoCompletion(requestApproval(w, id), id, rolls));
    },
    reviewMission: (
      id: string,
      day: string,
      status: "approved" | "follow-up",
      note: string,
    ) => setWorld((w) => approveMission(w, id, day, status, note, "staff")),
    requestRoom: (missionId: string, stepId: string) => {
      const rolls = entropy();
      setWorld((w) =>
        acceptDemoCompletion(
          requestRoom(w, missionId, stepId),
          missionId,
          rolls,
        ),
      );
      setStaff((s) => ({
        ...s,
        rooms: s.rooms.map((r) =>
          r.id === "r1"
            ? {
                ...r,
                status: "passed",
                note: "Demo auto-approved · simulated room-ready check.",
                reason: "",
                updatedAt: new Date().toISOString(),
              }
            : r,
        ),
      }));
      celebrate("Demo auto-approved. A tidy little start.", "task", missionId);
    },
    buySaver: () => setWorld(buySaver),
    setJourneyDay: (day: string, clock: "live" | "demo" = "demo") =>
      setWorld((w) => settleDay(w, day, clock)),
    addPracticeChest: (tier: ChestTier) => {
      const rolls = entropy();
      setWorld((w) => practiceChest(w, tier, rolls));
    },
    reviewSubmission: (
      id: string,
      status: Submission["status"],
      staffNote: string,
    ) => setWorld((w) => reviewHandIn(w, id, status, staffNote, "staff")),
    collection,
    setCollection,
    openCrate,
    pet,
    setPet,
    student,
    setStudent,
    staff,
    setStaff,
    preferences,
    setPreferences,
    reset,
    persistenceError,
  };
}
export const DemoContext = createContext<ReturnType<
  typeof useDemoValue
> | null>(null);
export function DemoProvider({ children }: { children: React.ReactNode }) {
  const value = useDemoValue();
  return (
    <DemoContext.Provider value={value}>
      <ResetBoundary key={value.resetVersion}>{children}</ResetBoundary>
    </DemoContext.Provider>
  );
}
function ResetBoundary({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}
export function useDemo() {
  const context = useContext(DemoContext);
  if (!context) throw new Error("DemoProvider is required");
  return context;
}
