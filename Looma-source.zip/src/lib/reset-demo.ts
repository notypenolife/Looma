/** Remove only this application's data, including obsolete Looma versions. */
export function clearLoomaStorage(
  storage: Pick<Storage, "length" | "key" | "removeItem">,
) {
  const keys = Array.from({ length: storage.length }, (_, i) =>
    storage.key(i),
  ).filter((k): k is string => !!k && k.startsWith("looma:"));
  for (const key of keys) storage.removeItem(key);
}
