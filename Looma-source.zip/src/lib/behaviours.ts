import { performanceLine } from "./embodiment";
import type { Expression, PetForm } from "./types";
export type BehaviourCategory =
  "entrance" | "idle" | "achievement" | "surprise" | "focus";
export type Prop =
  | "none"
  | "book"
  | "note"
  | "leaf"
  | "pencil"
  | "stone"
  | "gear"
  | "bell"
  | "gem"
  | "cup"
  | "star"
  | "crumb"
  | "wand"
  | "lantern";
export type Motion =
  | "nod"
  | "hop"
  | "sway"
  | "bow"
  | "peek"
  | "sneak"
  | "read"
  | "flap"
  | "spin"
  | "stretch"
  | "inspect"
  | "doze"
  | "skid"
  | "fidget"
  | "wave"
  | "float"
  | "eat";
export interface Performance {
  id: string;
  character: PetForm;
  category: BehaviourCategory;
  label: string;
  motion: Motion;
  prop: Prop;
  expression: Expression;
  line: string;
  duration: number;
  cooldown: number;
  weight: number;
  amplitude: number;
  tilt: number;
  tempo: number;
}
interface CharacterSpec {
  temperament: string;
  voice: string;
  phrase: string;
  snack: string;
  entrances: [string, string, string];
  idles: [string, string, string, string, string, string];
  achievements: [string, string, string];
  surprises: [string, string];
  focus: [string, string];
  greetings: [string, string, string];
  cheers: [string, string, string];
  discoveries: [string, string];
  quiet: [string, string];
  amplitude: number;
  tilt: number;
  tempo: number;
}
// Every named character has its own authored routines, speech and performance direction.
export const characterSheets: Record<PetForm, CharacterSpec> = {
  sprout: {
    temperament: "Patient gardener who notices small beginnings",
    voice: "gentle, concrete, quietly hopeful",
    phrase: "A little room to grow.",
    snack: "A leaf-sized biscuit. That’s a good harvest.",
    entrances: [
      "Unfurl a new leaf|stretch|leaf",
      "Check the morning light|inspect|leaf",
      "A small two-handed wave|wave|none",
    ],
    idles: [
      "Polish a leaf|fidget|leaf",
      "Watch an imaginary seed|peek|stone",
      "Count new shoots|inspect|pencil",
      "Catch a drifting leaf|sway|leaf",
      "A gardener’s stretch|stretch|none",
      "Sip rainwater|nod|cup",
    ],
    achievements: [
      "Offer a new leaf|nod|leaf",
      "A seedling-sized hop|hop|none",
      "Hold up a growing note|wave|note",
    ],
    surprises: [
      "Inspect a new seed|inspect|stone",
      "Catch a little surprise|peek|leaf",
    ],
    focus: [
      "Plan the next little patch|read|book",
      "Rest in a sunny corner|doze|leaf",
    ],
    greetings: [
      "Hello. There’s room for one small start.",
      "A fresh little leaf of a day.",
      "I found a quiet spot to begin.",
    ],
    cheers: [
      "One more little thing grown.",
      "That’s progress. Roots and all.",
      "A small leaf-shaped hooray.",
    ],
    discoveries: [
      "Something new to plant in the collection.",
      "A little treasure. Let’s see how it grows.",
    ],
    quiet: [
      "One thing at a time. Like watering a seed.",
      "Rest is part of growing too.",
    ],
    amplitude: 5,
    tilt: 4,
    tempo: 1.3,
  },
  pebble: {
    temperament: "Unhurried observer with gloriously dry humour",
    voice: "short, understated, almost motionless",
    phrase: "Quite nice, that.",
    snack: "A crumb. Excellent size. No assembly required.",
    entrances: [
      "One approving blink|nod|none",
      "Slowly notice the visitor|peek|stone",
      "A wave with minimum effort|wave|none",
    ],
    idles: [
      "Consider a very small stone|inspect|stone",
      "Settle into the floor|doze|none",
      "Count exactly one pebble|nod|stone",
      "Read half a sentence|read|book",
      "A nearly invisible stretch|stretch|none",
      "Watch a crumb go nowhere|peek|crumb",
    ],
    achievements: [
      "A single approving nod|nod|none",
      "Hold a deadpan hooray|peek|note",
      "The world’s smallest bounce|hop|stone",
    ],
    surprises: [
      "Raise one eyebrow|peek|none",
      "Inspect the packaging|inspect|stone",
    ],
    focus: ["Hold the quiet|doze|stone", "Read the useful sentence|read|book"],
    greetings: [
      "Oh. Hello. I was being stationary.",
      "You’re here. Quite nice, that.",
      "I saved a pause. Very low maintenance.",
    ],
    cheers: [
      "Done. A tasteful amount of applause.",
      "Hooray. Internally, it’s very loud.",
      "I nodded. That was the parade.",
    ],
    discoveries: [
      "A box. Excellent structural integrity.",
      "Quite nice. I may blink twice.",
    ],
    quiet: ["Steady does it.", "A pause. No performance required."],
    amplitude: 2,
    tilt: 2,
    tempo: 1.8,
  },
  pip: {
    temperament: "Breezy wandering bird with a terrible sense of direction",
    voice: "airy, wandering but helpful",
    phrase: "This way. Probably.",
    snack: "A crumb for the road. Where was the road?",
    entrances: [
      "Land slightly off course|skid|leaf",
      "Flutter into the room|flap|none",
      "Look for the right page|peek|note",
    ],
    idles: [
      "Fold a tiny route map|read|note",
      "Test a wing|flap|none",
      "Follow a floating leaf|sway|leaf",
      "Turn the map upside down|spin|note",
      "Perch and ponder|doze|stone",
      "Peck a crumb|inspect|crumb",
    ],
    achievements: [
      "Two triumphant wingbeats|flap|none",
      "Point in the right direction|wave|note",
      "A victory landing|skid|leaf",
    ],
    surprises: [
      "Circle the discovery|spin|gem",
      "A curious head tilt|inspect|none",
    ],
    focus: ["Find a clear route|read|note", "Rest the wings|doze|leaf"],
    greetings: [
      "Found you. This way. Probably.",
      "A little breeze brought me here.",
      "I took the scenic route to hello.",
    ],
    cheers: [
      "One less detour. Lovely!",
      "That went in the right direction!",
      "A little flutter of applause.",
    ],
    discoveries: [
      "A new stop on the little map.",
      "What a splendid thing to land beside.",
    ],
    quiet: ["One clear patch of sky at a time.", "Wings down. A little rest."],
    amplitude: 7,
    tilt: 9,
    tempo: 0.9,
  },
  water: {
    temperament: "Ripple is a curious collector of questions",
    voice: "bright, inquisitive, gently splashy",
    phrase: "What happens if…?",
    snack: "A dewdrop biscuit? Splendidly splashy.",
    entrances: [
      "Bubble up to say hello|hop|none",
      "Peek around a ripple|peek|cup",
      "Slide in with a splash|skid|leaf",
    ],
    idles: [
      "Inspect a dewdrop|inspect|gem",
      "Balance a floating leaf|sway|leaf",
      "Count the little ripples|nod|cup",
      "Read a question backwards|read|note",
      "Investigate a crumb boat|peek|crumb",
      "A liquid stretch|stretch|none",
    ],
    achievements: [
      "A tiny splash dance|hop|leaf",
      "Hold up a solved question|wave|note",
      "A delighted ripple|sway|gem",
    ],
    surprises: [
      "Lean all the way in|inspect|gem",
      "A bubble of surprise|hop|cup",
    ],
    focus: [
      "Follow one thought downstream|read|note",
      "Settle into still water|doze|leaf",
    ],
    greetings: [
      "Hello! What shall we find out first?",
      "I have one question. Maybe three.",
      "What happens if we start small?",
    ],
    cheers: [
      "Question answered. Tiny splash!",
      "A whole task finished. How did that feel?",
      "That deserves at least three ripples.",
    ],
    discoveries: [
      "Ooh. What’s inside this little discovery?",
      "I have questions about the shiny thing.",
    ],
    quiet: ["Let’s follow one thought.", "Even a ripple gets to settle."],
    amplitude: 7,
    tilt: 5,
    tempo: 1,
  },
  shadow: {
    temperament: "Moth is a shy bookworm, not a generic spooky creature",
    voice: "soft, thoughtful, literary",
    phrase: "I kept your place.",
    snack: "A biscuit between chapters. No crumbs in the binding.",
    entrances: [
      "Peek over the open book|read|book",
      "Mark a page and look up|peek|book",
      "A shy half-wave|wave|book",
    ],
    idles: [
      "Turn a delicate page|read|book",
      "Trace a sentence|inspect|pencil",
      "Hide a smile in the book|peek|book",
      "Keep a place with a leaf|fidget|leaf",
      "Watch a quiet star|float|star",
      "A sleepy chapter break|doze|book",
    ],
    achievements: [
      "Lift a tiny congratulatory bookmark|nod|note",
      "Look up with a shy smile|peek|book",
      "Close the chapter with care|bow|book",
    ],
    surprises: [
      "Peer over the margin|peek|book",
      "Inspect a new bookmark|inspect|leaf",
    ],
    focus: [
      "Read beside the student|read|book",
      "A little moonlit rest|doze|star",
    ],
    greetings: [
      "Oh, hello. I kept your place.",
      "Just one more sentence. There. Hello.",
      "A quiet chapter for us to start with.",
    ],
    cheers: [
      "A good ending to that little chapter.",
      "I made you a bookmark that says ‘done’.",
      "A quiet smile. That was lovely work.",
    ],
    discoveries: [
      "That belongs in the interesting-things chapter.",
      "May I look over the edge of the box?",
    ],
    quiet: [
      "We can read the first line together.",
      "The book can wait while you rest.",
    ],
    amplitude: 3,
    tilt: 4,
    tempo: 1.7,
  },
  fiend: {
    temperament:
      "Misch is cheeky, naughty and spectacularly bad at acting innocent",
    voice: "quick jokes, playful mock conspiracies",
    phrase: "Definitely wasn’t me.",
    snack: "A biscuit? I definitely didn’t hide a spare behind this wing.",
    entrances: [
      "Sneak in, then pretend innocence|sneak|crumb",
      "An exaggerated innocent wink|peek|none",
      "A cheeky sideways hop|skid|leaf",
    ],
    idles: [
      "Hide a crumb, badly|sneak|crumb",
      "Peek around the screen edge|peek|none",
      "Practise an innocent face|fidget|note",
      "Poke a drifting leaf|inspect|leaf",
      "Try a very tiny prank|skid|pencil",
      "Stifle a cheeky giggle|sway|none",
    ],
    achievements: [
      "Pretend the victory was inevitable|bow|none",
      "Reveal a mischievous well-done note|sneak|note",
      "A wonky victory shuffle|skid|crumb",
    ],
    surprises: [
      "Pretend not to have peeked|peek|none",
      "A startled innocent hop|hop|crumb",
    ],
    focus: [
      "Park the mischief for five minutes|nod|pencil",
      "Nap beside the hidden biscuit|doze|crumb",
    ],
    greetings: [
      "Hello. Definitely wasn’t me.",
      "Nothing suspicious here. Just a very normal tiny fiend.",
      "I moved one pencil. For dramatic reasons.",
    ],
    cheers: [
      "You did the work. I supplied the suspicious grin.",
      "Another task defeated. Definitely wasn’t me.",
      "I made a tiny prank: the list is shorter now.",
    ],
    discoveries: [
      "I only peeked a little. Allegedly.",
      "A shiny thing? My completely innocent face is ready.",
    ],
    quiet: [
      "Mischief parked. Pencil ready.",
      "Even tiny troublemakers take a breather.",
    ],
    amplitude: 8,
    tilt: 11,
    tempo: 0.85,
  },
  fire: {
    temperament: "Ember is a cheerful, slightly overprepared motivator",
    voice: "warm, brisk, encouraging without shouting",
    phrase: "A tiny spark is plenty.",
    snack: "Toasty crumbs. My favourite kind.",
    entrances: [
      "A warm little spring|hop|none",
      "Offer a toasty hello|wave|cup",
      "Stretch the flame|stretch|none",
    ],
    idles: [
      "Warm an imaginary mug|sway|cup",
      "Read a small checklist|read|note",
      "Fan a friendly spark|flap|leaf",
      "Toast one crumb|inspect|crumb",
      "Bounce on tiny feet|hop|none",
      "Count down a good idea|nod|pencil",
    ],
    achievements: [
      "A flame-shaped victory hop|hop|star",
      "Offer a warm congratulatory mug|wave|cup",
      "A bright little double nod|nod|note",
    ],
    surprises: [
      "Flare with interest|stretch|gem",
      "A surprised spark|hop|none",
    ],
    focus: [
      "Keep one little light steady|inspect|lantern",
      "Cool down with a quiet pause|doze|cup",
    ],
    greetings: [
      "A tiny spark is plenty. Ready?",
      "Hello! I warmed up the good ideas.",
      "One warm little start, coming up.",
    ],
    cheers: [
      "That’s the spark! One thing finished.",
      "Warm applause. Very small hands.",
      "A little fuel for your breathing room.",
    ],
    discoveries: [
      "A new little spark of something!",
      "Ooh. Toasty treasure energy.",
    ],
    quiet: [
      "One steady spark, one steady step.",
      "A warm pause is still a good pause.",
    ],
    amplitude: 8,
    tilt: 5,
    tempo: 0.9,
  },
  electricity: {
    temperament: "Zip is an easily distracted inventor learning to park ideas",
    voice: "fast little bursts, comic self-corrections",
    phrase: "Idea! Wait. One thing first.",
    snack: "Biscuit fuel. I calculated this. Mostly.",
    entrances: [
      "Skid in with an idea|skid|gear",
      "A wonky electric wave|wave|pencil",
      "Pop up behind an invention|hop|gear",
    ],
    idles: [
      "Test a tiny cog|inspect|gear",
      "Scribble an impossible plan|fidget|pencil",
      "Park an idea on paper|read|note",
      "Follow a little glint|skid|gem",
      "Spin a spare gear|spin|gear",
      "Count three sparks|nod|star",
    ],
    achievements: [
      "A zigzag victory skid|skid|gear",
      "Present an invention labelled done|wave|note",
      "An excited half-spin|spin|star",
    ],
    surprises: [
      "An electric double take|peek|gear",
      "Bounce into a new idea|hop|pencil",
    ],
    focus: ["Park the spare ideas|read|note", "Recharge quietly|doze|gear"],
    greetings: [
      "Idea! Wait. Hello first.",
      "I brought fourteen plans. We only need one.",
      "A little bzz and a fresh page.",
    ],
    cheers: [
      "Bzz! Finished! My calculations say hooray.",
      "One task down. Thirteen ideas safely parked.",
      "That deserves a completely unnecessary little skid.",
    ],
    discoveries: [
      "I can probably build something with this!",
      "New data! Shiny data!",
    ],
    quiet: [
      "Idea parked. Focus switched on. Mostly.",
      "Recharging. Quietly, for once.",
    ],
    amplitude: 10,
    tilt: 7,
    tempo: 0.7,
  },
  rubio: {
    temperament: "A theatrical gem who treats small work as opening night",
    voice: "affectionate theatrical flourish",
    phrase: "Places, everyone.",
    snack: "An exquisite crumb. Compliments to the imaginary chef.",
    entrances: [
      "Take the tiny stage|bow|gem",
      "Polish the ruby then wave|fidget|gem",
      "A red-carpet turn|spin|none",
    ],
    idles: [
      "Polish a little ruby|inspect|gem",
      "Rehearse a bow|bow|none",
      "Read an imaginary review|read|note",
      "Adjust a dramatic accessory|fidget|star",
      "Hold an elegant pose|sway|none",
      "Sip between performances|nod|cup",
    ],
    achievements: [
      "An extravagant little bow|bow|gem",
      "Present a five-star review|wave|note",
      "A theatrical pirouette|spin|star",
    ],
    surprises: [
      "Clutch the imaginary pearls|peek|gem",
      "Inspect the spotlight|inspect|star",
    ],
    focus: ["Read the next act|read|book", "A graceful interval|doze|cup"],
    greetings: [
      "Places, everyone. Our little day begins.",
      "Darling, you brought the plan. I brought the ruby.",
      "A grand entrance for a very ordinary lovely day.",
    ],
    cheers: [
      "A triumph in one extremely small act!",
      "Take a bow. The audience is me.",
      "Five tiny stars. Excellent ending.",
    ],
    discoveries: [
      "The suspense! The exquisite reveal!",
      "This treasure deserves a little red carpet.",
    ],
    quiet: [
      "One scene at a time.",
      "Even the grandest performance has an interval.",
    ],
    amplitude: 6,
    tilt: 13,
    tempo: 1.15,
  },
  void: {
    temperament:
      "Vesper is a deadpan archivist of absurdly forbidden knowledge",
    voice: "dry, ceremonial, secretly tender",
    phrase: "The archive approves.",
    snack: "The forbidden biscuit recipe was surprisingly straightforward.",
    entrances: [
      "Look up from the forbidden index|read|book",
      "A chain-jingling solemn nod|nod|none",
      "Peer around a dramatic footnote|peek|book",
    ],
    idles: [
      "Read the forbidden biscuit index|read|book",
      "Trace an ancient footnote|inspect|pencil",
      "Jingle one loose chain|fidget|gem",
      "Float a bookmark into place|float|note",
      "Review a profoundly ordinary crumb|inspect|crumb",
      "A solemn page-side nap|doze|book",
    ],
    achievements: [
      "Stamp the archive’s approval|nod|note",
      "A deeply understated little bow|bow|book",
      "Raise the forbidden well-done sign|peek|note",
    ],
    surprises: [
      "Consult the suspicious index|read|book",
      "A very slight antimatter wobble|sway|gem",
    ],
    focus: [
      "Catalogue one small thought|read|book",
      "Rest between the footnotes|doze|none",
    ],
    greetings: [
      "The archive is open. Please mind the biscuit footnotes.",
      "Ah. A visitor. I was reading something terribly ordinary.",
      "The forbidden book says we should start small.",
    ],
    cheers: [
      "The archive approves. Quietly, but with conviction.",
      "A task vanquished. I have filed the paperwork.",
      "The prophecy mentioned a shorter to-do list.",
    ],
    discoveries: [
      "A new entry for the extremely important shiny-things index.",
      "The seal is broken. Finally, stationery.",
    ],
    quiet: [
      "One footnote at a time.",
      "The universe can wait for a page break.",
    ],
    amplitude: 3,
    tilt: 5,
    tempo: 1.8,
  },
  pumpkin: {
    temperament:
      "Pipkin is a sunny host who brings enough snacks for everybody",
    voice: "welcoming, practical picnic chatter",
    phrase: "I brought the napkins.",
    snack: "A picnic crumb! I brought enough imaginary ones for everyone.",
    entrances: [
      "Arrive carrying a picnic cup|wave|cup",
      "A roly-poly hello|sway|leaf",
      "Check everyone has a seat|peek|note",
    ],
    idles: [
      "Count picnic napkins|read|note",
      "Offer a little crumb|wave|crumb",
      "Polish a pumpkin leaf|fidget|leaf",
      "Set down a mug|bow|cup",
      "Look for a picnic patch|inspect|stone",
      "Rest after hosting|doze|leaf",
    ],
    achievements: [
      "Offer a celebratory picnic|wave|cup",
      "A happy pumpkin wobble|sway|leaf",
      "Present the napkin of victory|nod|note",
    ],
    surprises: [
      "Peek inside the picnic basket|peek|crumb",
      "A delighted host’s hop|hop|cup",
    ],
    focus: [
      "Arrange the little plan|read|note",
      "A picnic blanket pause|doze|leaf",
    ],
    greetings: [
      "Hello! I brought the napkins.",
      "There’s a little seat for you here.",
      "A fresh page and a picnic-sized plan.",
    ],
    cheers: [
      "One task finished. Picnic committee approves!",
      "I packed an extra little hooray.",
      "A fine reason to unfold the good napkins.",
    ],
    discoveries: [
      "Something for our little picnic!",
      "I saved a place for this treasure.",
    ],
    quiet: [
      "Let’s set out one thing at a time.",
      "The picnic can wait while you breathe.",
    ],
    amplitude: 5,
    tilt: 8,
    tempo: 1.2,
  },
  ghost: {
    temperament:
      "Boo practises surprises in a whisper and apologises to furniture",
    voice: "whispery, shy, gently funny",
    phrase: "A very small boo.",
    snack: "A ghost-sized crumb. Almost see-through.",
    entrances: [
      "Peek out with a whisper|peek|none",
      "Float in and wave apologetically|float|note",
      "Practise the tiniest boo|stretch|star",
    ],
    idles: [
      "Practise a quiet surprise|peek|note",
      "Float around one crumb|float|crumb",
      "Read a gentle mystery|read|book",
      "Wave to the furniture|wave|none",
      "Watch a moonbeam|inspect|star",
      "Fold into a quiet nap|doze|none",
    ],
    achievements: [
      "Hold up a whispered hooray|peek|note",
      "Float a little higher|float|star",
      "A shy congratulatory wave|wave|none",
    ],
    surprises: [
      "Surprise the self instead|hop|none",
      "Hide behind a tiny note|peek|note",
    ],
    focus: [
      "Read a soft little clue|read|book",
      "A near-invisible rest|doze|star",
    ],
    greetings: [
      "A very small boo. Hello.",
      "Was that too quiet? Hello again.",
      "I floated over. Carefully.",
    ],
    cheers: [
      "Boo— I mean, hooray.",
      "A quiet victory. I saw it.",
      "I made a little sign because cheering is loud.",
    ],
    discoveries: [
      "Oh! The box surprised me first.",
      "May I peek? Very quietly?",
    ],
    quiet: ["A gentle first line is enough.", "You can be still here."],
    amplitude: 4,
    tilt: 4,
    tempo: 1.65,
  },
  bat: {
    temperament: "Button is a delighted night explorer with upside-down ideas",
    voice: "bouncy, exploratory, slightly disoriented",
    phrase: "Looks better upside down.",
    snack: "A midnight crumb. Right-side up this time.",
    entrances: [
      "Flutter in from the wrong angle|flap|none",
      "A slightly upside-down hello|spin|star",
      "Land on an imaginary branch|skid|stone",
    ],
    idles: [
      "Stretch one little wing|flap|none",
      "Read an upside-down map|read|note",
      "Investigate a moon crumb|inspect|crumb",
      "Hang at a silly angle|sway|leaf",
      "Count night lights|peek|star",
      "Fold wings for a pause|doze|none",
    ],
    achievements: [
      "A happy wing flutter|flap|star",
      "An almost upside-down victory|spin|none",
      "Hold up a night-explorer badge|wave|note",
    ],
    surprises: [
      "A startled wingbeat|flap|gem",
      "Lean towards a glimmer|inspect|star",
    ],
    focus: [
      "Turn the plan right-side up|read|note",
      "Fold the wings and wait|doze|leaf",
    ],
    greetings: [
      "Hello! Looks better upside down.",
      "I found the page. The landing was optional.",
      "A little night explorer, reporting in.",
    ],
    cheers: [
      "That deserves a loop round the imaginary moon!",
      "One task down. Wings up!",
      "I applauded with both wings. Very aerodynamic.",
    ],
    discoveries: [
      "A glimmer worth investigating!",
      "Ooh! An excellent reason to land.",
    ],
    quiet: [
      "One clear route. Then a little flutter.",
      "Wings folded. A quiet pause.",
    ],
    amplitude: 8,
    tilt: 16,
    tempo: 0.85,
  },
  witch: {
    temperament:
      "Hexley is a conscientious scholar whose spells do very ordinary jobs",
    voice: "earnest mock-academic precision",
    phrase: "According to my notes…",
    snack: "The crumb potion is mostly just a biscuit.",
    entrances: [
      "Consult the greeting notes|read|book",
      "A careful hat-adjusting bow|bow|wand",
      "Wave the very ordinary wand|wave|wand",
    ],
    idles: [
      "Annotate a tiny potion recipe|read|book",
      "Check a pencil spell|inspect|pencil",
      "Adjust the excellent hat|fidget|none",
      "Test an imaginary teacup charm|sway|cup",
      "File a leaf-shaped note|nod|leaf",
      "Nap beside the reference book|doze|book",
    ],
    achievements: [
      "A congratulatory wand flourish|wave|wand",
      "Present a scholarly well-done note|nod|note",
      "A precise little victory turn|spin|book",
    ],
    surprises: [
      "Consult the appendix|read|book",
      "Test the mysterious glimmer|inspect|gem",
    ],
    focus: [
      "One footnote, carefully read|read|book",
      "A scholar’s tea break|doze|cup",
    ],
    greetings: [
      "According to my notes, hello.",
      "The greeting spell is just a wave. Excellent.",
      "I prepared a small plan and a large hat.",
    ],
    cheers: [
      "A practical application of getting things done!",
      "The notes clearly say: well done.",
      "No spell required. You did that.",
    ],
    discoveries: [
      "I shall consult the surprisingly sparkly appendix.",
      "A new research topic!",
    ],
    quiet: [
      "One useful line from the notes.",
      "Even scholarly hats need a tea break.",
    ],
    amplitude: 4,
    tilt: 9,
    tempo: 1.35,
  },
  eclipse: {
    temperament: "Solune is a cosmic poet who sees ordinary little wonders",
    voice: "dreamy but specific, gently lyrical",
    phrase: "A small constellation.",
    snack: "A crescent-shaped crumb. Astronomically delicious.",
    entrances: [
      "Drift into a sunbeam|float|star",
      "Bow to an imaginary moon|bow|none",
      "Trace a small orbit|spin|gem",
    ],
    idles: [
      "Map a tiny constellation|inspect|star",
      "Read a pocket poem|read|note",
      "Balance a moonbeam|sway|gem",
      "Follow a slow orbit|float|stone",
      "Polish a little sunset|fidget|star",
      "Doze between stars|doze|none",
    ],
    achievements: [
      "Offer a finished-task star|wave|star",
      "A little orbit of approval|spin|note",
      "A slow celestial bow|bow|gem",
    ],
    surprises: [
      "Watch a new star arrive|peek|star",
      "Tilt towards the rainbow|inspect|gem",
    ],
    focus: [
      "Draw one bright line|read|note",
      "A moonlit little stillness|doze|star",
    ],
    greetings: [
      "A small constellation brought me here.",
      "Hello. There’s a little light to begin by.",
      "A quiet orbit around a fresh page.",
    ],
    cheers: [
      "One finished thing. A new little star.",
      "A small constellation of progress.",
      "That deserves a tiny sunset bow.",
    ],
    discoveries: [
      "Something lovely entered our little orbit.",
      "A new point of light for the collection.",
    ],
    quiet: [
      "One bright line at a time.",
      "The stars are patient. You can rest.",
    ],
    amplitude: 4,
    tilt: 10,
    tempo: 1.7,
  },
  twig: {
    temperament: "Twill is an earnest carpenter with a pencil behind the leaf",
    voice: "practical, modest, cheerfully precise",
    phrase: "Measure small. Start smaller.",
    snack: "A sawdust-free biscuit. I checked the measurements.",
    entrances: [
      "Measure the welcome mat|inspect|pencil",
      "Wave with a crooked twig|wave|leaf",
      "A carpenter’s careful nod|nod|stone",
    ],
    idles: [
      "Measure an imaginary shelf|inspect|pencil",
      "Straighten a little twig|fidget|leaf",
      "Sketch a tiny plan|read|note",
      "Tap a pebble into place|nod|stone",
      "Test a wooden wobble|sway|none",
      "Rest beside the blueprint|doze|note",
    ],
    achievements: [
      "Present a well-built tick|wave|note",
      "A sturdy little bounce|hop|stone",
      "A craftsman’s modest bow|bow|pencil",
    ],
    surprises: [
      "Measure the discovery|inspect|gem",
      "Peek over the blueprint|peek|note",
    ],
    focus: [
      "Read one line of the plan|read|note",
      "Put the tools down gently|doze|pencil",
    ],
    greetings: [
      "Measure small. Start smaller.",
      "Hello. I made a little room on the workbench.",
      "The plan is only three pencil lines.",
    ],
    cheers: [
      "A well-built little finish.",
      "That fits neatly in the done column.",
      "Measure twice. Celebrate once. Tiny hop.",
    ],
    discoveries: [
      "A useful little thing for the workbench.",
      "Let’s see how this fits.",
    ],
    quiet: ["One pencil line is a start.", "Tools down. Shoulders soft."],
    amplitude: 4,
    tilt: 5,
    tempo: 1.3,
  },
  copper: {
    temperament: "Rivet is a patient tinkerer who enjoys wonky solutions",
    voice: "clicks, practical curiosity, quiet delight",
    phrase: "Ah. That clicks.",
    snack: "A biscuit cog. Surprisingly edible.",
    entrances: [
      "Look up from a tiny gear|inspect|gear",
      "A coppery half-turn|spin|none",
      "Wave a wonky invention|wave|pencil",
    ],
    idles: [
      "Test a bronze cog|inspect|gear",
      "Tighten an imaginary screw|fidget|pencil",
      "Read a repair note|read|note",
      "Listen for the right click|peek|gear",
      "Rock a spare part|sway|stone",
      "A workbench tea pause|doze|cup",
    ],
    achievements: [
      "Click the finished cog into place|nod|gear",
      "A satisfied mechanic’s bounce|hop|none",
      "Present a working little note|wave|note",
    ],
    surprises: [
      "Inspect the mechanism|inspect|gem",
      "A delighted double take|peek|gear",
    ],
    focus: [
      "One moving part at a time|read|note",
      "An unhurried recharge|doze|gear",
    ],
    greetings: [
      "Ah. That clicks. Hello.",
      "A slightly wonky invention brought me here.",
      "I kept a little space on the workbench.",
    ],
    cheers: [
      "That clicks. Very satisfying.",
      "One less loose screw on the list.",
      "A small, mechanically sound hooray.",
    ],
    discoveries: [
      "A new part for the curiosity drawer.",
      "I wonder what makes it tick.",
    ],
    quiet: [
      "One little adjustment first.",
      "No repairs needed during a pause.",
    ],
    amplitude: 4,
    tilt: 7,
    tempo: 1.2,
  },
  silverling: {
    temperament: "Lilt collects quiet tunes in tiny silver bells",
    voice: "soft musical metaphors, never sings endlessly",
    phrase: "Three quiet notes.",
    snack: "A crisp little crumb. Excellent acoustics.",
    entrances: [
      "Ring a silent greeting bell|wave|bell",
      "Listen, then look up|peek|none",
      "A soft musical sway|sway|bell",
    ],
    idles: [
      "Polish a silver bell|fidget|bell",
      "Read three little notes|read|note",
      "Listen for a tiny echo|peek|cup",
      "Rock to a quiet rhythm|sway|none",
      "Trace a musical line|inspect|pencil",
      "Rest between notes|doze|bell",
    ],
    achievements: [
      "Three quiet victory notes|nod|bell",
      "A little conductor’s wave|wave|pencil",
      "Hold up a musical well done|peek|note",
    ],
    surprises: [
      "Listen to a new glimmer|inspect|gem",
      "A surprised little trill|stretch|bell",
    ],
    focus: [
      "Keep one calm rhythm|sway|bell",
      "A rest in the little score|doze|note",
    ],
    greetings: [
      "Three quiet notes. Hello.",
      "I found a little tune for starting.",
      "A soft beginning sounds just right.",
    ],
    cheers: [
      "A tidy little ending. Three quiet notes.",
      "That task found its final note.",
      "A small silver-bell hooray.",
    ],
    discoveries: [
      "That glimmer has a lovely little rhythm.",
      "Something new for the quiet-tune collection.",
    ],
    quiet: ["One note, then the next.", "A rest is part of the music."],
    amplitude: 3,
    tilt: 6,
    tempo: 1.6,
  },
  plume: {
    temperament:
      "Purl is a fastidious curator who secretly loves imperfect things",
    voice: "considered, exact, gently approving",
    phrase: "An excellent little detail.",
    snack: "A carefully catalogued crumb. Deliciously irregular.",
    entrances: [
      "Straighten the welcome label|fidget|note",
      "A precise curator’s nod|nod|stone",
      "Look over a display card|peek|note",
    ],
    idles: [
      "Catalogue a smooth stone|inspect|stone",
      "Straighten a tiny label|fidget|note",
      "Read the little collection log|read|book",
      "Polish a pearl glint|inspect|gem",
      "Consider an uneven leaf|sway|leaf",
      "A very orderly pause|doze|cup",
    ],
    achievements: [
      "A considered nod of approval|nod|none",
      "Present the neatly labelled tick|wave|note",
      "A curator’s restrained bow|bow|stone",
    ],
    surprises: [
      "Inspect every little facet|inspect|gem",
      "Peek at the provenance label|peek|note",
    ],
    focus: [
      "One well-considered detail|read|book",
      "Put the labels aside|doze|none",
    ],
    greetings: [
      "An excellent little detail: you’re here.",
      "I straightened the welcome label.",
      "A little room in the catalogue for today.",
    ],
    cheers: [
      "A finish worth carefully labelling.",
      "Consider this my highly considered nod.",
      "A lovely imperfect bit of progress.",
    ],
    discoveries: [
      "A new entry. Excellent little details.",
      "May I examine the tiny label?",
    ],
    quiet: [
      "One useful detail is enough.",
      "The collection will keep while you rest.",
    ],
    amplitude: 2,
    tilt: 5,
    tempo: 1.5,
  },
  sol: {
    temperament:
      "Marigold organises sunlit picnics with gently comic efficiency",
    voice: "warm, practical, a little ceremonious",
    phrase: "I saved the sunny spot.",
    snack: "A golden crumb. The picnic quality inspector approves.",
    entrances: [
      "Offer the sunny seat|wave|leaf",
      "A welcoming petal stretch|stretch|none",
      "Arrive with a small mug|sway|cup",
    ],
    idles: [
      "Count the golden petals|inspect|leaf",
      "Set a tiny picnic place|bow|cup",
      "Read the snack list|read|note",
      "Wave at a drifting crumb|wave|crumb",
      "Polish a sunny little pebble|fidget|stone",
      "Doze in the warm spot|doze|leaf",
    ],
    achievements: [
      "Unfold the victory napkin|wave|note",
      "A golden petal wiggle|sway|leaf",
      "A warm little host’s bow|bow|cup",
    ],
    surprises: [
      "Make room at the picnic|peek|leaf",
      "Inspect a sunny glimmer|inspect|gem",
    ],
    focus: [
      "Set out one useful thing|read|note",
      "Rest in the saved sunny spot|doze|leaf",
    ],
    greetings: [
      "I saved the sunny spot.",
      "Hello! The picnic plan is beautifully small.",
      "A warm seat and one little next step.",
    ],
    cheers: [
      "A finish fit for the good napkins.",
      "I reserved a sunny little hooray.",
      "One task down. Picnic table clear.",
    ],
    discoveries: [
      "A little golden addition to the picnic.",
      "There’s room in the sunny spot for that.",
    ],
    quiet: [
      "One little place-setting at a time.",
      "I’ll keep the sunny seat while you rest.",
    ],
    amplitude: 5,
    tilt: 8,
    tempo: 1.25,
  },
  facet: {
    temperament:
      "Flick investigates reflections and is continually delighted by them",
    voice: "precise questions followed by surprised delight",
    phrase: "Look at that angle!",
    snack: "A crystalline crumb? No. A biscuit. Good.",
    entrances: [
      "Skid towards a glimmer|skid|gem",
      "Tilt into the light|inspect|gem",
      "A prismatic little turn|spin|none",
    ],
    idles: [
      "Inspect a new angle|inspect|gem",
      "Trace a rainbow line|fidget|pencil",
      "Peek through a crystal|peek|gem",
      "Read a tiny reflection map|read|note",
      "Balance a little glint|sway|star",
      "Rest out of the spotlight|doze|none",
    ],
    achievements: [
      "A delighted crystalline skid|skid|gem",
      "Present a reflective well done|wave|note",
      "A tiny prismatic pirouette|spin|star",
    ],
    surprises: [
      "A dramatic curious tilt|inspect|gem",
      "Skid back for another look|skid|none",
    ],
    focus: [
      "Find one clear facet|read|note",
      "Let the reflections settle|doze|gem",
    ],
    greetings: [
      "Look at that angle! Oh, hello.",
      "A new little reflection to investigate.",
      "I tilted the light just right for starting.",
    ],
    cheers: [
      "A brilliantly clear little finish!",
      "Look at that angle: it says done.",
      "That deserves a completely delighted skid.",
    ],
    discoveries: [
      "A new glint! I need at least two looks.",
      "The collection just got a little more prismatic.",
    ],
    quiet: ["One clear facet first.", "Even reflections can settle."],
    amplitude: 8,
    tilt: 12,
    tempo: 0.95,
  },
};
const categories: BehaviourCategory[] = [
  "entrance",
  "idle",
  "achievement",
  "surprise",
  "focus",
];
export function performances(form: PetForm): Performance[] {
  const s = characterSheets[form];
  return categories.flatMap((category) => {
    const entries =
      category === "entrance"
        ? s.entrances
        : category === "idle"
          ? s.idles
          : category === "achievement"
            ? s.achievements
            : category === "surprise"
              ? s.surprises
              : s.focus;
    return entries.map((entry, i) => {
      const [label, motion, prop] = entry.split("|");
      return {
        id: `${form}:${category}:${i}`,
        character: form,
        category,
        label,
        motion: motion as Motion,
        prop: prop as Prop,
        expression: (motion === "doze"
          ? "sleepy"
          : category === "achievement" &&
              ["hop", "flap", "spin", "skid"].includes(motion)
            ? "celebrating"
            : motion === "read"
              ? "thinking"
              : motion === "inspect" || motion === "peek"
                ? "curious"
                : "happy") as Expression,
        line: performanceLine(
          form,
          motion as Motion,
          prop as Prop,
          category,
          i,
        ),
        duration: Math.round(
          (category === "idle" ? 4200 : category === "entrance" ? 2600 : 3200) *
            s.tempo,
        ),
        cooldown: category === "idle" ? 60000 + i * 3500 : 12000,
        weight: category === "idle" ? (i === 0 ? 3 : i === 5 ? 1 : 2) : 1,
        amplitude: s.amplitude,
        tilt: s.tilt,
        tempo: s.tempo,
      };
    });
  });
}
export function choosePerformance(
  form: PetForm,
  category: BehaviourCategory,
  now: number,
  recent: Record<string, number>,
  last: string | undefined,
  roll: number,
  hour = 12,
): Performance | null {
  const eligible = performances(form).filter(
    (p) =>
      p.category === category &&
      p.id !== last &&
      (recent[p.id] === undefined || now - recent[p.id] >= p.cooldown),
  );
  if (!eligible.length) return null;
  const weight = (p: Performance) =>
    p.weight *
    ((hour >= 21 || hour < 6) && (p.motion === "read" || p.motion === "doze")
      ? 2
      : 1);
  const total = eligible.reduce((n, p) => n + weight(p), 0);
  let cursor = Math.max(0, Math.min(0.999999, roll)) * total;
  return (
    eligible.find((p) => {
      cursor -= weight(p);
      return cursor < 0;
    }) ?? eligible[eligible.length - 1]
  );
}
