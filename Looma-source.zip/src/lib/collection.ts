import type { Accessory, Expression, PetColour, PetForm } from "./types";

export type Rarity = "common" | "rare" | "epic" | "legendary" | "mythical";
export type CrateKind =
  "cosmetic" | "looma" | "halloween-cosmetic" | "halloween-looma";
export type ItemSource = "elemental" | "halloween" | "reward";
export interface LoomaSpecies {
  id: PetForm;
  name: string;
  element: string;
  personality: string;
  description: string;
  colour: PetColour;
  rarity: Rarity;
  starter?: boolean;
  source?: ItemSource;
}
export const species: LoomaSpecies[] = [
  {
    id: "sprout",
    name: "Sprout",
    element: "Earth",
    personality: "Gentle optimist",
    description:
      "Collects little joys. Unfurls its leaves for a good morning stretch.",
    colour: "sage",
    rarity: "common",
    starter: true,
  },
  {
    id: "pebble",
    name: "Pebble",
    element: "Stone",
    personality: "Quiet daydreamer",
    description:
      "Slow blinks, steady company. Believes a small pause can fix a busy day.",
    colour: "apricot",
    rarity: "common",
    starter: true,
  },
  {
    id: "water",
    name: "Ripple",
    element: "Water",
    personality: "Curious explorer",
    description:
      "A tiny tide of questions. Bubbles with excitement at anything new.",
    colour: "blue",
    rarity: "common",
    starter: true,
  },
  {
    id: "fire",
    name: "Ember",
    element: "Fire",
    personality: "Cheerful go-getter",
    description:
      "A warm little flame. Celebrates the smallest finished task with a wiggle.",
    colour: "apricot",
    rarity: "rare",
  },
  {
    id: "electricity",
    name: "Zip",
    element: "Electricity",
    personality: "Restless inventor",
    description:
      "Has fourteen ideas before breakfast. Loves a puzzle and a silly dance.",
    colour: "gold",
    rarity: "rare",
  },
  {
    id: "shadow",
    name: "Moth",
    element: "Shadow",
    personality: "Shy night owl",
    description:
      "Soft-spoken and starry-eyed. Perks up as the evening gets quiet.",
    colour: "blue",
    rarity: "epic",
  },
  {
    id: "fiend",
    name: "Misch",
    element: "Fiend",
    personality: "Lovable mischief-maker",
    description:
      "Tiny horns. Enormous curiosity. A harmless prank is its love language.",
    colour: "apricot",
    rarity: "legendary",
  },
  {
    id: "twig",
    name: "Twill",
    element: "Wood",
    personality: "Earnest little carpenter",
    description:
      "Measures twice. Nibbles the pencil once. Builds the tiniest plans.",
    colour: "sage",
    rarity: "common",
    source: "reward",
  },
  {
    id: "copper",
    name: "Rivet",
    element: "Bronze",
    personality: "Pocket-sized tinkerer",
    description:
      "Listens for the click that means an idea works. Loves a perfectly wonky invention.",
    colour: "apricot",
    rarity: "common",
    source: "reward",
  },
  {
    id: "silverling",
    name: "Lilt",
    element: "Silver",
    personality: "Soft-spoken music collector",
    description:
      "Hums little tunes into silver bells. A finished task earns three quiet notes.",
    colour: "blue",
    rarity: "rare",
    source: "reward",
  },
  {
    id: "plume",
    name: "Purl",
    element: "Platinum",
    personality: "Meticulous little curator",
    description:
      "Collects smooth stones and straightens tiny labels. A considered nod is high praise.",
    colour: "sage",
    rarity: "rare",
    source: "reward",
  },
  {
    id: "sol",
    name: "Marigold",
    element: "Gold",
    personality: "Warm picnic organiser",
    description:
      "Sets out an imaginary picnic for every small victory. Remembers the napkins.",
    colour: "gold",
    rarity: "epic",
    source: "reward",
  },
  {
    id: "facet",
    name: "Flick",
    element: "Diamond",
    personality: "Dazzled little investigator",
    description:
      "Tilts every crystal towards the light. Celebrates a discovery with a surprised little skid.",
    colour: "blue",
    rarity: "legendary",
    source: "reward",
  },
  {
    id: "rubio",
    name: "Rubio",
    element: "Ruby",
    personality: "Dramatic little darling",
    description:
      "Treats every small achievement like opening night. Polishes its little gem before taking a bow.",
    colour: "apricot",
    rarity: "legendary",
    source: "reward",
  },
  {
    id: "void",
    name: "Vesper",
    element: "Void",
    personality: "Deadpan bookworm",
    description:
      "Keeper of the extremely forbidden biscuit recipe. Tiny horns, loose golden chains, enormous dry wit.",
    colour: "gold",
    rarity: "mythical",
    source: "reward",
  },
  {
    id: "pumpkin",
    name: "Pipkin",
    element: "Harvest",
    personality: "Sunny little host",
    description:
      "Brings the snacks. Invites absolutely everyone to the pumpkin picnic.",
    colour: "apricot",
    rarity: "common",
    source: "halloween",
  },
  {
    id: "ghost",
    name: "Boo",
    element: "Mist",
    personality: "Shy surprise enthusiast",
    description:
      "Practises saying boo in a whisper. Likes quiet victories and soft landings.",
    colour: "blue",
    rarity: "rare",
    source: "halloween",
  },
  {
    id: "bat",
    name: "Button",
    element: "Dusk",
    personality: "Bouncy night explorer",
    description:
      "A teaspoon-sized bat with a pocketful of ideas. Frequently upside down.",
    colour: "blue",
    rarity: "epic",
    source: "halloween",
  },
  {
    id: "witch",
    name: "Hexley",
    element: "Wonder",
    personality: "Earnest tiny scholar",
    description:
      "Studies the ancient art of remembering where the pencils went. Excellent hat. Questionable potions.",
    colour: "sage",
    rarity: "legendary",
    source: "halloween",
  },
  {
    id: "eclipse",
    name: "Solune",
    element: "Eclipse",
    personality: "Dreamy cosmic poet",
    description:
      "A little moon with a warm sunset heart. Thinks your finished homework deserves a constellation.",
    colour: "gold",
    rarity: "mythical",
    source: "halloween",
  },
];
export const legacyPip: LoomaSpecies = {
  id: "pip",
  name: "Pip",
  element: "Cloud",
  personality: "Breezy wanderer",
  description: "A small cloud with somewhere to be.",
  colour: "blue",
  rarity: "common",
  starter: true,
};
export function getSpecies(form: PetForm) {
  return species.find((s) => s.id === form) ?? legacyPip;
}
export const cosmetics: {
  id: Accessory;
  name: string;
  rarity: Rarity;
  description: string;
  source?: ItemSource;
}[] = [
  {
    id: "scarf",
    name: "Cosy scarf",
    rarity: "common",
    description: "A little warmth, tied just right.",
  },
  {
    id: "glasses",
    name: "Round specs",
    rarity: "common",
    description: "For very important daydreaming.",
  },
  {
    id: "satchel",
    name: "Little satchel",
    rarity: "common",
    description: "Mostly full of interesting pebbles.",
  },
  {
    id: "bow",
    name: "Ribbon bow",
    rarity: "rare",
    description: "Dressed for an ordinary lovely day.",
  },
  {
    id: "leafhat",
    name: "Rainy-day leaf",
    rarity: "rare",
    description: "One leaf. Excellent coverage.",
  },
  {
    id: "starpin",
    name: "Moonlit pin",
    rarity: "epic",
    description: "A little piece of the night sky.",
  },
  {
    id: "headphones",
    name: "Cloud headphones",
    rarity: "epic",
    description: "A soundtrack for small adventures.",
  },
  {
    id: "crown",
    name: "Sunflower crown",
    rarity: "legendary",
    description: "Royalty of the windowsill.",
  },
  {
    id: "trailbow",
    name: "Trail ribbon",
    rarity: "common",
    description: "For taking the scenic route.",
    source: "reward",
  },
  {
    id: "dewbadge",
    name: "First light pin",
    rarity: "rare",
    description: "A small badge for a small beginning.",
    source: "reward",
  },
  {
    id: "mooncloak",
    name: "Moonweave cloak",
    rarity: "epic",
    description: "A little evening wrapped around your shoulders.",
    source: "reward",
  },
  {
    id: "rubytiara",
    name: "Ruby Tiara",
    rarity: "legendary",
    description: "A tiny crown for a very grand entrance.",
    source: "reward",
  },
  {
    id: "diamondhalo",
    name: "Prism halo",
    rarity: "legendary",
    description: "A ring of pocket-sized rainbows.",
    source: "reward",
  },
  {
    id: "voidchains",
    name: "Whisper chains",
    rarity: "mythical",
    description: "Loose little golden links. Full of mysterious jingles.",
    source: "reward",
  },
  {
    id: "pumpkinhat",
    name: "Pumpkin bonnet",
    rarity: "common",
    description: "Autumn's tiniest good idea.",
    source: "halloween",
  },
  {
    id: "stitchbow",
    name: "Patchwork ribbon",
    rarity: "rare",
    description: "A little crooked. A lot of character.",
    source: "halloween",
  },
  {
    id: "candlehat",
    name: "Candle cap",
    rarity: "epic",
    description: "An imaginary flame for real daydreams.",
    source: "halloween",
  },
  {
    id: "batcape",
    name: "Midnight cape",
    rarity: "legendary",
    description: "Perfect for a dramatic snack break.",
    source: "halloween",
  },
  {
    id: "mooncrown",
    name: "Eclipse coronet",
    rarity: "mythical",
    description: "Sunshine on one side, moonlight on the other.",
    source: "halloween",
  },
];
export const rarityOdds: { rarity: Rarity; chance: number }[] = [
  { rarity: "common", chance: 60 },
  { rarity: "rare", chance: 25 },
  { rarity: "epic", chance: 12 },
  { rarity: "legendary", chance: 3 },
];
export const cratePrices: Record<CrateKind, number> = {
  cosmetic: 100,
  looma: 150,
  "halloween-cosmetic": 125,
  "halloween-looma": 175,
};
export interface CollectionState {
  balance: number;
  forms: PetForm[];
  accessories: Accessory[];
  history: {
    id: string;
    kind: CrateKind;
    item: string;
    rarity: Rarity;
    duplicate: boolean;
    refund: number;
  }[];
}
export const initialCollection: CollectionState = {
  balance: 500,
  forms: ["sprout", "pebble", "water"],
  accessories: ["none", "scarf", "glasses", "satchel"],
  history: [],
};
export const validForms: PetForm[] = [...species.map((s) => s.id), "pip"];
export const validAccessories: Accessory[] = [
  "none",
  ...cosmetics.map((c) => c.id),
];
export function validCollection(value: unknown): value is CollectionState {
  if (!value || typeof value !== "object") return false;
  const v = value as CollectionState;
  return (
    Number.isSafeInteger(v.balance) &&
    v.balance >= 0 &&
    v.balance <= 1000000 &&
    Array.isArray(v.forms) &&
    v.forms.every((f) => validForms.includes(f)) &&
    Array.isArray(v.accessories) &&
    v.accessories.every((a) => validAccessories.includes(a)) &&
    Array.isArray(v.history) &&
    v.history.length <= 30 &&
    v.history.every(
      (h) =>
        h &&
        typeof h.id === "string" &&
        ["looma", "cosmetic", "halloween-looma", "halloween-cosmetic"].includes(
          h.kind,
        ) &&
        typeof h.item === "string" &&
        ["common", "rare", "epic", "legendary", "mythical"].includes(
          h.rarity,
        ) &&
        typeof h.duplicate === "boolean" &&
        Number.isFinite(h.refund),
    )
  );
}
export function rollCrate(
  kind: CrateKind,
  rarityRoll: number,
  itemRoll: number,
) {
  if (
    ![rarityRoll, itemRoll].every((n) => Number.isFinite(n) && n >= 0 && n < 1)
  )
    throw new Error("Rolls must be in [0, 1).");
  let total = 0;
  const rarity = oddsForCrate(kind).find((r) => {
    total += r.chance;
    return rarityRoll * 100 < total;
  })!.rarity;
  const pool = crateItems(kind).filter((s) => s.rarity === rarity);
  const selected = pool[Math.floor(itemRoll * pool.length)];
  return { item: selected.id, name: selected.name, rarity };
}
export function purchaseCrate(
  state: CollectionState,
  kind: CrateKind,
  rarityRoll: number,
  itemRoll: number,
  id: string,
): CollectionState {
  if (
    state.balance < cratePrices[kind] ||
    state.history.some((h) => h.id === id)
  )
    return state;
  const roll = rollCrate(kind, rarityRoll, itemRoll);
  const duplicate = isLoomaCrate(kind)
    ? state.forms.includes(roll.item as PetForm)
    : state.accessories.includes(roll.item as Accessory);
  const refund = duplicate ? (isLoomaCrate(kind) ? 50 : 30) : 0;
  return {
    balance: state.balance - cratePrices[kind] + refund,
    forms:
      isLoomaCrate(kind) && !duplicate
        ? [...state.forms, roll.item as PetForm]
        : state.forms,
    accessories:
      !isLoomaCrate(kind) && !duplicate
        ? [...state.accessories, roll.item as Accessory]
        : state.accessories,
    history: [
      { id, kind, item: roll.item, rarity: roll.rarity, duplicate, refund },
      ...state.history,
    ].slice(0, 30),
  };
}
export type PetEvent =
  "hello" | "snack" | "play" | "focus" | "rest" | "task" | "crate";
const voices: Partial<Record<PetForm, [string, string, string]>> = {
  sprout: [
    "A little light. A little stretch. Hello!",
    "A picnic-sized adventure? Count me in.",
    "One small step. That’s how things grow.",
  ],
  pebble: [
    "Oh, hello. I saved you a quiet moment.",
    "That was my very fastest wiggle.",
    "Steady does it. Let’s do one thing.",
  ],
  water: [
    "Hello! Have you noticed anything interesting today?",
    "Tiny splash! Big discovery!",
    "Let’s follow one thought and see where it goes.",
  ],
  fire: [
    "Morning! I’ve got a warm little feeling about today.",
    "Wiggle first, victory dance second!",
    "A tiny spark is plenty to get started.",
  ],
  electricity: [
    "Hello! New idea: we start with a stretch!",
    "Bzz! That dance needs at least three more spins.",
    "Idea parked. Focus switched on. Mostly.",
  ],
  shadow: [
    "Psst. Hello. It’s nice in this little patch of shade.",
    "A secret moonwalk. Just for the fun of it.",
    "Quiet helps. Let’s make a little space.",
  ],
  fiend: [
    "Hello! I definitely did not hide your pencil. Probably.",
    "A tiny prank: I swapped my serious face for this one.",
    "Mischief can wait. You’ve got a plan to make.",
  ],
  pip: [
    "A fresh breeze. Hello there!",
    "A little hop, a little flutter!",
    "Let’s find a clear patch of sky.",
  ],
};
export function petReaction(
  form: PetForm,
  event: PetEvent,
  hour: number,
): { expression: Expression; line: string; animation: string } {
  const voice = voices[form] ?? [
    `Hello! ${getSpecies(form).name} reporting for a little adventure.`,
    "A tiny celebration, with surprisingly good footwork.",
    "A small plan. A little space. Let’s begin.",
  ];
  if (event === "task")
    return {
      expression: "celebrating",
      line:
        form === "pebble"
          ? "A very quiet hooray. That’s one thing done."
          : "One thing finished! Tiny victory dance?",
      animation: "dance",
    };
  if (event === "crate")
    return {
      expression: "curious",
      line:
        form === "fiend"
          ? "I promise I didn’t peek. Well…"
          : "Something small and lovely. What’s inside?",
      animation: "wiggle",
    };
  if (event === "rest")
    return {
      expression: "sleepy",
      line:
        form === "shadow"
          ? "I’ll watch the little stars. You take a breather."
          : "A little pause. Nothing needs doing right now.",
      animation: "rest",
    };
  if (event === "snack")
    return {
      expression: "happy",
      line:
        form === "water"
          ? "A dewdrop biscuit? Splendidly splashy."
          : form === "fire"
            ? "Toasty crumbs. My favourite kind."
            : "A tiny biscuit. A very good moment.",
      animation: "nibble",
    };
  if (event === "play")
    return {
      expression: "celebrating",
      line: voice[1],
      animation:
        form === "pebble"
          ? "wiggle"
          : form === "shadow"
            ? "float"
            : form === "electricity"
              ? "zip"
              : form === "fiend"
                ? "mischief"
                : "dance",
    };
  if (event === "focus")
    return { expression: "thinking", line: voice[2], animation: "focus" };
  if (hour >= 21 || hour < 6)
    return {
      expression: form === "shadow" ? "curious" : "sleepy",
      line:
        form === "shadow"
          ? "The moon’s up. My favourite quiet hour."
          : "A soft landing for the day. No rush here.",
      animation: "rest",
    };
  return {
    expression:
      form === "water" || form === "electricity" ? "curious" : "happy",
    line: voice[0],
    animation: "wave",
  };
}

export function isLoomaCrate(kind: CrateKind) {
  return kind === "looma" || kind === "halloween-looma";
}
export const halloweenOdds: { rarity: Rarity; chance: number }[] = [
  { rarity: "common", chance: 50 },
  { rarity: "rare", chance: 28 },
  { rarity: "epic", chance: 15 },
  { rarity: "legendary", chance: 6 },
  { rarity: "mythical", chance: 1 },
];
export function oddsForCrate(kind: CrateKind) {
  return kind.startsWith("halloween") ? halloweenOdds : rarityOdds;
}
export function crateItems(kind: CrateKind) {
  const source = kind.startsWith("halloween") ? "halloween" : "elemental";
  const items = isLoomaCrate(kind) ? species : cosmetics;
  return items.filter((item) => (item.source ?? "elemental") === source);
}
export function sourceLabel(source?: ItemSource) {
  return source === "reward"
    ? "Earned chests only"
    : source === "halloween"
      ? "Halloween shop crates"
      : "Elemental shop crates";
}
