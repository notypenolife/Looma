import type { Metadata } from "next";
import "@fontsource/dm-sans/400.css";
import "@fontsource/dm-sans/500.css";
import "@fontsource/dm-sans/600.css";
import "@fontsource/dm-sans/700.css";
import "@fontsource/fraunces/400.css";
import "@fontsource/fraunces/500.css";
import "./globals.css";
import "./assistant-theme.css";
import "./collection.css";
import "./journey.css";
import "./refinements.css";
import "./living.css";
import { DemoProvider } from "@/lib/store";
export const metadata: Metadata = {
  title: { default: "Looma — A little room to grow", template: "%s · Looma" },
  description:
    "A thoughtful companion for boarding life. Explore the fictional student and staff demonstrations.",
  robots: { index: false, follow: false },
};
export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en-NZ" data-scroll-behavior="smooth">
      <body>
        <DemoProvider>{children}</DemoProvider>
      </body>
    </html>
  );
}
