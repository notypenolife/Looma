import { Suspense } from "react";
import { notFound } from "next/navigation";
import { Chat } from "@/components/student/Chat";
import { Homework } from "@/components/student/Homework";
import { Schedule } from "@/components/student/Schedule";
import { Customise } from "@/components/student/Customise";
import { Settings } from "@/components/Settings";
import { Shop } from "@/components/student/Shop";
import { Missions } from "@/components/student/Missions";
import { Chests } from "@/components/student/Chests";
import { CharacterStudio } from "@/components/student/CharacterStudio";
import { UhOh } from "@/components/ui/UhOh";
export function generateStaticParams() {
  return [
    "chat",
    "homework",
    "schedule",
    "looma",
    "settings",
    "shop",
    "workshop",
    "missions",
    "chests",
    "studio",
  ].map((section) => ({ section }));
}
export default async function Page({
  params,
}: {
  params: Promise<{ section: string }>;
}) {
  const { section } = await params;
  switch (section) {
    case "chat":
      return <Chat />;
    case "homework":
      return <Homework />;
    case "schedule":
      return <Schedule />;
    case "looma":
      return <Customise />;
    case "settings":
      return <Settings role="student" />;
    case "shop":
      return <Shop />;
    case "missions":
      return <Missions />;
    case "chests":
      return (
        <Suspense
          fallback={<p role="status">Finding your little treasures…</p>}
        >
          <Chests />
        </Suspense>
      );
    case "studio":
      return <CharacterStudio />;
    case "workshop":
      return <UhOh unfinished />;
    default:
      notFound();
  }
}
