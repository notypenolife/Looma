import { StudentDashboard } from "@/components/student/Dashboard";
export default function Page() {
  return <StudentDashboard />;
}
