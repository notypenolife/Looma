import Link from "next/link";
import {
  ArrowUpRight,
  ArrowRight,
  BookOpen,
  ClipboardCheck,
  Leaf,
  MessageCircle,
  Check,
  HeartHandshake,
} from "lucide-react";
import { Logo } from "@/components/ui/shared";
import { LoomaPet } from "@/components/pets/LoomaPet";
export default function LandingPage() {
  return (
    <div className="landing">
      <a href="#landing-main" className="skip-link">
        Skip to content
      </a>
      <header className="landing-nav">
        <Logo />
        <nav aria-label="Main navigation">
          <a href="#how-it-helps">How it helps</a>
          <a href="#companions">Meet your Looma</a>
          <Link href="/staff" className="staff-link">
            For boarding staff <ArrowUpRight size={15} />
          </Link>
        </nav>
        <Link href="/student" className="button button-dark button-small">
          Explore the demo <ArrowRight size={16} />
        </Link>
      </header>
      <main id="landing-main">
        <section className="landing-hero">
          <div className="hero-copy">
            <div className="hero-tag">
              <span />A THOUGHTFUL COMPANION FOR BOARDING LIFE
            </div>
            <h1>
              A little less juggling.
              <br />A little more <em>you.</em>
            </h1>
            <p>
              Your day, your plans, your own little companion.
              <br className="desktop-break" /> Looma makes room for the things
              that matter.
            </p>
            <div className="hero-actions">
              <Link href="/student" className="button button-dark">
                Step into student life <ArrowUpRight size={18} />
              </Link>
              <Link href="/staff" className="button button-outline">
                Explore staff tools <ArrowUpRight size={18} />
              </Link>
            </div>
            <div className="hero-footnote">
              <span className="tiny-pets">
                <LoomaPet animate={false} />
                <LoomaPet form="pebble" colour="apricot" animate={false} />
                <LoomaPet form="pip" colour="blue" animate={false} />
              </span>
              <span>
                Made for everyday boarding life.
                <br />
                <strong>Imagined first for Auckland, Aotearoa.</strong>
              </span>
            </div>
          </div>
          <div className="hero-illustration">
            <div className="hero-orbit orbit-one" />
            <div className="hero-orbit orbit-two" />
            <span className="illustration-leaf leaf-one">
              <Leaf size={37} />
            </span>
            <span className="illustration-leaf leaf-two">
              <Leaf size={25} />
            </span>
            <div className="hero-note">
              <span className="note-pin" />
              <p>
                Morning, Alex.
                <br />
                Let’s take today
                <br />
                <em>one thing at a time.</em>
              </p>
              <span className="note-signature">— Fern</span>
            </div>
            <div className="hero-pet">
              <LoomaPet accessory="scarf" />
            </div>
            <div className="hero-task">
              <span className="task-check">
                <Check size={15} />
              </span>
              <div>
                <small>A LITTLE HEADS-UP</small>
                <strong>Hockey at 3:45. You’re all set.</strong>
              </div>
            </div>
            <span className="pet-caption">
              Meet Fern. Your day, with a little company.
            </span>
            <svg viewBox="0 0 100 60" className="hand-arrow" aria-hidden="true">
              <path
                d="M5 10Q70 0 85 45M67 36L87 48L91 27"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
              />
            </svg>
          </div>
        </section>
        <div className="landing-strip">
          <span>A calmer morning.</span>
          <span>A clearer plan.</span>
          <span>A companion that feels like yours.</span>
          <Leaf size={18} />
        </div>
        <section className="landing-features" id="how-it-helps">
          <div className="landing-section-intro">
            <p className="eyebrow">A GOOD DAY STARTS WITH A LITTLE CLARITY</p>
            <h2>
              School life has a lot of moving parts.
              <br />
              <em>Let’s bring them together.</em>
            </h2>
          </div>
          <div className="feature-pair">
            <article className="feature-student">
              <span className="feature-icon">
                <BookOpen size={24} />
              </span>
              <p className="eyebrow">FOR STUDENTS</p>
              <h3>Your day, made a little simpler.</h3>
              <p>
                Know what to wear, where to be, and what’s due. Talk things
                through with Looma, then get on with your day.
              </p>
              <div className="mini-timetable">
                <div>
                  <span className="subject-dot blue" />
                  <strong>Mathematics</strong>
                  <span>08:30</span>
                </div>
                <div>
                  <span className="subject-dot apricot" />
                  <strong>English</strong>
                  <span>09:30</span>
                </div>
                <div>
                  <span className="subject-dot sage" />
                  <strong>Biology</strong>
                  <span>11:00</span>
                </div>
              </div>
              <Link href="/student" className="text-link">
                Explore the student space <ArrowUpRight size={17} />
              </Link>
            </article>
            <article className="feature-staff">
              <span className="feature-icon">
                <ClipboardCheck size={24} />
              </span>
              <p className="eyebrow">FOR BOARDING STAFF</p>
              <h3>Less paperwork. More presence.</h3>
              <p>
                Room checks, follow-ups, notices, and daily duties in one
                considered workspace. Clear records, with people at the centre.
              </p>
              <div className="mini-progress">
                <div>
                  <strong>Morning room checks</strong>
                  <span>7 of 12 checked</span>
                </div>
                <div className="progress-track">
                  <span style={{ width: "58%" }} />
                </div>
                <p>
                  <span className="status-dot passed" />5 passed{" "}
                  <span className="status-dot follow-up" />2 to follow up
                </p>
              </div>
              <Link href="/staff" className="text-link">
                Explore the staff workspace <ArrowUpRight size={17} />
              </Link>
            </article>
          </div>
        </section>
        <section id="companions" className="companions-section">
          <div>
            <p className="eyebrow">
              A SMALL COMPANION. A DISTINCT PERSONALITY.
            </p>
            <h2>A Looma of your own.</h2>
            <p>
              Choose a form, find your colour, add a little character.
              <br />A gentle presence that’s always happy to see you.
            </p>
            <Link href="/student/looma" className="button button-outline">
              Meet your companion <ArrowUpRight size={17} />
            </Link>
          </div>
          <div className="companion-lineup">
            <div>
              <LoomaPet form="sprout" colour="sage" />
              <h3>Sprout</h3>
              <p>A little room to grow.</p>
            </div>
            <div>
              <LoomaPet form="pebble" colour="apricot" accessory="glasses" />
              <h3>Pebble</h3>
              <p>Steady, soft, and curious.</p>
            </div>
            <div>
              <LoomaPet form="pip" colour="blue" accessory="satchel" />
              <h3>Pip</h3>
              <p>A fresh perspective.</p>
            </div>
          </div>
        </section>
        <section className="care-section">
          <HeartHandshake size={28} strokeWidth={1.4} />
          <div>
            <h3>Personal, with thoughtful boundaries.</h3>
            <p>
              You choose what Looma remembers. Companion conversations stay
              separate from staff records. This prototype uses fictional
              information throughout.
            </p>
          </div>
          <span className="badge badge-sage">Built with care</span>
        </section>
        <section className="landing-cta">
          <span className="eyebrow">COME ON IN</span>
          <h2>There’s a little room for you here.</h2>
          <Link href="/student" className="button button-dark">
            Explore Looma <ArrowRight size={18} />
          </Link>
        </section>
      </main>
      <footer className="landing-footer">
        <Logo />
        <p>A little room to grow.</p>
        <span>
          Independent prototype · Willowmere Academy is a fictional school
        </span>
        <Link href="/student/chat" aria-label="Try Looma chat">
          <MessageCircle size={20} />
        </Link>
      </footer>
    </div>
  );
}
