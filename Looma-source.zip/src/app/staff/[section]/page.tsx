import { Suspense } from "react";
import { notFound } from "next/navigation";
import { Inspections } from "@/components/staff/Inspections";
import { Detentions } from "@/components/staff/Detentions";
import { StaffTasks, StaffNotices } from "@/components/staff/TasksNotices";
import { Submissions } from "@/components/staff/Submissions";
import { RewardMissions } from "@/components/staff/RewardMissions";
import { Settings } from "@/components/Settings";
export function generateStaticParams() {
  return [
    "inspections",
    "detentions",
    "tasks",
    "notices",
    "settings",
    "submissions",
    "missions",
  ].map((section) => ({ section }));
}
export default async function Page({
  params,
}: {
  params: Promise<{ section: string }>;
}) {
  const { section } = await params;
  switch (section) {
    case "inspections":
      return (
        <Suspense fallback={<p role="status">Opening the morning round…</p>}>
          <Inspections />
        </Suspense>
      );
    case "detentions":
      return <Detentions />;
    case "tasks":
      return <StaffTasks />;
    case "notices":
      return <StaffNotices />;
    case "submissions":
      return <Submissions />;
    case "missions":
      return <RewardMissions />;
    case "settings":
      return <Settings role="staff" />;
    default:
      notFound();
  }
}
