import { AppShell } from "@/components/AppShell";
export default function StaffLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <AppShell role="staff">{children}</AppShell>;
}
