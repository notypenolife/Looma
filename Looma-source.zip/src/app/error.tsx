"use client";
import { UhOh } from "@/components/ui/UhOh";
export default function ErrorPage({
  retry,
  reset,
}: {
  error: Error & { digest?: string };
  retry?: () => void;
  reset?: () => void;
}) {
  return <UhOh retry={retry ?? reset ?? (() => window.location.reload())} />;
}
