"use client";
import { LoomaPet } from "@/components/pets/LoomaPet";
export default function GlobalError({
  retry,
  reset,
}: {
  error: Error;
  retry?: () => void;
  reset?: () => void;
}) {
  return (
    <html lang="en">
      <style>{`.pet-wipe{transform-origin:195px 178px;animation:wipe 2.6s ease-in-out infinite}@keyframes wipe{0%,35%,100%{transform:rotate(0)}50%,75%{transform:rotate(-12deg)}}@media(prefers-reduced-motion:reduce){.pet-wipe{animation:none}}`}</style>
      <body
        style={{
          margin: 0,
          background: "#fafaf8",
          color: "#273443",
          fontFamily: "system-ui",
          textAlign: "center",
          padding: "48px 20px",
        }}
      >
        <div style={{ width: 220, margin: "auto" }}>
          <LoomaPet form="sprout" construction expression="thinking" />
        </div>
        <h1>Uh oh. A little repair needed.</h1>
        <p>Hard hat on. Tiny toolkit ready. Let’s try again.</p>
        <button
          style={{ padding: "14px 24px", borderRadius: 12, cursor: "pointer" }}
          onClick={retry ?? reset ?? (() => window.location.reload())}
        >
          Try again
        </button>
        <p>
          <a href="/Looma/">Back to Looma</a>
        </p>
      </body>
    </html>
  );
}
