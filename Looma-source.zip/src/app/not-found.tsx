import { UhOh } from "@/components/ui/UhOh";
export default function NotFound() {
  return <UhOh unfinished />;
}
